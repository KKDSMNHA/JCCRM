<?php
    version_compare(PHP_VERSION, '5.5.0', '<') && die('require PHP > 5.5.0 !');
    // version_compare(PHP_VERSION, '5.7.0', '>=') && die('require PHP < 5.7.0 !');
    define ('APP_NAME','App');
    define ('APP_PATH','./App/');
    define ('UPLOAD_PATH','./Uploads/');
    require APP_PATH."/Conf/app_debug.php";
    require 'Base/ThinkPHP.php';
