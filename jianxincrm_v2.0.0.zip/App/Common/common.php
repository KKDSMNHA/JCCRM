<?php
/**
 * @author JianXin dev team
 * @param $dir
 */
function deldir($dir) {
    $dh = opendir($dir);
    while ($file = readdir($dh)) {
        if ($file != "." && $file != "..") {
            $fullpath = $dir . "/" . $file;
            if (!is_dir($fullpath)) {
                @unlink($fullpath);
            } else {
                @deldir($fullpath);
            }
        }
    }
    closedir($dh);
}

/**
 * 取得文件后缀
 * @author JianXin dev team
 * @param $filename
 * @return bool|string
 */
function getExtension($filename){
    $mytext = substr($filename, strrpos($filename, '.')+1);
    return $mytext;
}

/**
 * 图片格式 进行图片格式的判断
 * @author JianXin dev team
 * @return array
 */
function imgFormat(){
    return array('jpg','png','jpeg','gif');
}

/**
 * 根据 后缀显示图标 函数
 * @author JianXin dev team
 * @param $file_name
 * @return string
 */
function show_picture($file_name){
	$houzhui = getExtension($file_name);
	switch ($houzhui) {
		case 'doc':
			$pic = 'doc.png';
			break;
		case 'docx':
			$pic = 'doc.png';
			break;
		case 'pptx':
			$pic = 'ppt.png';
			break;
		case 'ppt':
			$pic = 'ppt.png';
			break;
		case 'xls':
			$pic = 'excel.png';
			break;
		case 'zip':
			$pic = 'zip.png';
			break;
		case 'zip':
			$pic = 'zip.png';
			break;
		case 'pdf':
			$pic = 'pdf.png';
			break;
		case 'png':
			$pic = 'pic.png';
			break;
		case 'jpg':
			$pic = 'pic.png';
			break;
		case 'jpeg':
			$pic = 'pic.png';
			break;
		case 'gif':
			$pic = 'pic.png';
			break;
		default:
			$pic = 'unknown.png';
			break;
	}
	return $pic;
}

/**
 * 手机端选择负责人
 * @author JianXin dev team
 * @param $role_id
 * @return string
 */
function owner_name_select($role_id){
	$d_role_view = D('RoleView');

	$all_role = M('role')->where('user_id <> 0')->select();
	$below_role = getSubRole(session('role_id'), $all_role);

	$below_ids[] = session('role_id');
	foreach ($below_role as $key=>$value) {
		$below_ids[] = $value['role_id'];
	}
	$where['role.role_id'] = array('in',implode(',',$below_ids));
	$where['user.status'] = 1;
	$role_list = $d_role_view->where($where)->order('department_id ASC,position_id ASC')->field('role_id,user_name,department_name,role_name')->select();

	$string = '<select id="owner_role_id" name="owner_role_id">';
	if(is_array($role_list)){
		$string .= '<option value="0">--请选择--</option>';
		foreach($role_list as $v){
			if($role_id && $role_id == $v['role_id']){
				$string .= '<option selected="selected" value="'.$v['role_id'].'">'.$v['user_name'].'</option>';
			}else{
				$string .= '<option value="'.$v['role_id'].'">'.$v['user_name'].'</option>';
			}
		}
	}
	$string .= '</select>';
	return $string;
}

/**
 * 高级搜索生成where条件
 * @author JianXin dev team
 * @param $search
 * @param string $condition
 * @return array
 */
function field($search, $condition=''){
	switch ($condition) {
		case "is" : $where = array('eq',$search);break;
		case "isnot" :  $where = array('neq',$search);break;
		case "contains" :  $where = array('like','%'.$search.'%');break;
		case "not_contain" :  $where = array('notlike','%'.$search.'%');break;
		case "start_with" :  $where = array('like',$search.'%');break;
		case "not_start_with" :  $where = array('notlike',$search.'%');break;
		case "end_with" :  $where = array('like','%'.$search);break;
		case "is_empty" :  $where = array('eq','');break;
		case "is_not_empty" :  $where = array('neq','');break;
		case "gt" :  $where = array('gt',$search);break;
		case "egt" :  $where = array('egt',$search);break;
		case "lt" :  
				if (strtotime($search) !== false && strtotime($search) != -1) {
					$where = array('lt',strtotime($search));
				} else {
					$where = array('lt',$search);
				}
				break;
		case "elt" :  $where = array('elt',$search);break;
		case "eq" : $where = array('eq',$search);break;
		case "neq" : $where = array('neq',$search);break;
		case "between" : $where = array('between',array(strtotime($search)-1,strtotime($search)+86400));break;
		case "nbetween" : $where = array('not between',array(strtotime($search),strtotime($search)+86399));break;
		case "tgt" :  $where = array('gt',strtotime($search)+86400);break;
		case 'in':
			$where = array('IN', $search);
			break;
		case 'not_in':
			$where = array('NOT IN', $search);
			break;
		default : $where = array('eq',$search);
	}
	return $where;
}

/**
 * @author JianXin dev team
 * @param $num
 * @return float
 */
function format_price($num){
	$num = round($num, 0);
	$s_num = strval($num);
	$len = strlen($s_num)-1;
	$result = round($num, -$len);
	return $result;
}

/**获取首页需要显示的列名字符串
 * @author JianXin dev team
 * @param $model
 * @param $status
 * @return bool|false|mixed|PDOStatement|string|\think\Collection
 */
function getIndexFields($model, $status = 0){
    if(!$model) return false;
	$m_model = M($model);
	$where['in_index'] = 1;
	$where['model'] = $model;
	if ($model == 'examine') {
		$where['status'] = $status;
	}
	$model_fields = M('Fields')->where($where)->order('order_id ASC')->select();
	return $model_fields;
}

/**
 * 获取主表字段 用于搜索
 * @author JianXin dev team
 * @param $model
 * @param $status
 * @return bool|false|mixed|PDOStatement|string|\think\Collection
 */
function getMainFields($model, $status = 0){
	if(!$model) return false;
	$m_model = M($model);
	$where['is_main'] = 1;
	$where['model'] = $model;
	if ($model == 'examine') {
		$where['status'] = $status;
	}
	$model_fields = M('Fields')->where($where)->order('order_id ASC')->select();
	return $model_fields;
}

/**
 * 记录操作日志
 * @author JianXin dev team
 * @param $id 操作对象id
 * @param string $param_name 参数
 * @param string $text
 * @return bool
 */
function actionLog($id,$param_name='',$text=''){
    $role_id = session('role_id');
    $user = M('user')->where(array('user_id'=>session('user_id')))->find();
    $category = $user['category_id'] == 1 ? L('ADMIN') : L('USER');
    $data['role_id'] = $role_id;
	$action_name = strtolower(ACTION_NAME);
	if($action_name == 'mylog_add'){
		$module_name = 'log';
	} else {
		$module_name = strtolower(MODULE_NAME);
	}
	$data['module_name'] = $module_name;
	if($action_name == 'addajax'){
		$data['action_name'] = 'add';
	}elseif($action_name == 'editajax'){
		$data['action_name'] = 'edit';
	}elseif($action_name == 'del'){
		$data['action_name'] = 'delete';
	}else{
		$data['action_name'] = strtolower(ACTION_NAME);
	}
	if(!empty($param_name)){
		$data['param_name'] = strtolower($param_name);
	}
    $data['create_time'] = time();
    $data['action_id'] = $id;
    $data['content'] = L('ACTIONLOG',array($category,$user['full_name'],date('Y-m-d H:i:s'),L($data['action_name']),$id,L($module_name),$text));
    $actionLog = M('actionLog');
    $actionLog->create($data);
    if($actionLog->add()){
		//如果是删除操作，设置action_delete = 1
		if(strtolower($data['action_name']) == 'delete' || strtolower($data['action_name']) == 'completedelete' || strtolower($data['action_name']) == 'log_delete' || strtolower($data['action_name']) == 'del'){
			$actionLog->where('module_name = "%s" and action_id = %d', strtolower($module_name), $id)->setField('action_delete',1);
		}
		return true;
	}else{
		return false;
	}
}

/**
 * @author JianXin dev team
 * @param $str
 * @param int $start
 * @param $length
 * @param string $charset
 * @param bool $suffix
 * @return string
 */
function msubstr($str, $start=0, $length, $charset="utf-8", $suffix=true) {
    if(function_exists("mb_substr"))
        $slice = mb_substr($str, $start, $length, $charset);
    elseif(function_exists('iconv_substr')) {
        $slice = iconv_substr($str,$start,$length,$charset);
        if(false === $slice) {
            $slice = '';
        }
    }else{
        $re['utf-8']   = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
        $re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
        $re['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
        $re['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
        preg_match_all($re[$charset], $str, $match);
        $slice = join("",array_slice($match[0], $start, $length));
    }
	if(utf8_strlen($str) < $length) $suffix = false;
    return $suffix ? $slice.'...' : $slice;
}

/**
 * @author JianXin dev team
 * @param null $string
 * @return int
 */
function utf8_strlen($string = null) {
	preg_match_all("/./us", $string, $match);
	return count($match[0]);
}

/**
 * @author JianXin dev team
 * @param $model
 * @return bool
 */
function getDateTime($model){
	$user = M('User')->where('role_id = %d',session('role_id'))->field('user_id,last_read_time')->find();
	if($user['last_read_time']){		
		$last_read_time = json_decode($user['last_read_time'],true);
	}
	$last_read_time[$model] = time();
	$last_read_time = json_encode($last_read_time);
	M('User')->where('user_id = %d',$user['user_id'])->setField('last_read_time',$last_read_time);
	return true;
}

/**
 * @author JianXin dev team
 * @param $category_id
 * @param $category
 * @param $separate
 * @return array
 */
function getSubCategory($category_id, $category, $separate) {
	$array = array();
	foreach($category AS $value) {
		if ($category_id == $value['parent_id']) {
			$array[] = array('category_id' => $value['category_id'], 'name' => $separate.$value['name'],'description'=>$value['description']);
			$array = array_merge($array, getSubCategory($value['category_id'], $category, $separate.'--'));
		}
	}
	return $array;
}

/**
 * 不包括自己所在部门
 * @author JianXin dev team
 * @param $department_id
 * @param $department
 * @param $separate
 * @param $no_separater
 * @return array
 */
function getSubDepartment($department_id = 0, $department = [], $separate = '', $no_separater = '') {
	$array = array();
	if($no_separater){
		foreach($department AS $value) {
			if ($department_id == $value['parent_id']) {
				$array[] = array('department_id' => $value['department_id'], 'name' => $separate.$value['name'],'description'=>$value['description']);
				$array = array_merge($array, getSubDepartment($value['department_id'], $department, $separate, 1));
			}
		}
	}else{
		foreach($department AS $value) {
			if ($department_id == $value['parent_id']) {
				$array[] = array('department_id' => $value['department_id'], 'name' => $separate.$value['name'],'description'=>$value['description']);
				$array = array_merge($array, getSubDepartment($value['department_id'], $department, $separate.'--'));
			}
		}
	}
	return $array;
}

/**
 * 包括自己所在部门
 * @author JianXin dev team
 * @param $department_id
 * @param $department
 * @param int $first
 * @return array
 */
function getSubDepartment2($department_id, $department, $first=0) {
	$array = array();
	$m_department =  M('role_department');
	if($first == 1){
		$depart = $m_department->where('department_id = %d', session('department_id'))->find();
		$array[] = array('department_id'=>$depart['department_id'],'name'=>$depart['name'], 'description'=>$depart['description']);
	}
	foreach($department AS $value) {
		if ($department_id == $value['parent_id']) {
			$array[] = array('department_id' => $value['department_id'], 'name' => $separate.$value['name'],'description'=>$value['description']);
			$array = array_merge($array, getSubDepartment2($value['department_id'], $department, '--'));
		}
	}
	return $array;
}

/**
 * @author JianXin dev team
 * @param $department_id
 * @param int $first
 * @return string
 */
function getSubDepartmentTreeCode($department_id, $first=0) {
	$string = "";
	$department_list = M('roleDepartment')->where('parent_id = %d', $department_id)->select();

	if ($department_list) {

		$string = "<ul>";

		foreach($department_list AS $value) {
			if($department_id == $value['department_id']){
				$name = '<a href="'.U('user/department','department_id='.$value['department_id']).'" class="control_dep dep1 jstree-clicked">'.$value['name'].'</a>';
			}else{
				$name = '<a href="'.U('user/department','department_id='.$value['department_id']).'" onclick="javascript:window.location.href=\''.U('user/department','department_id='.$value['department_id']).'\'" class="control_dep dep1">'.$value['name'].'</a>';
			}
			$string .="<li class='jstree-open' rel='".$value['department_id']."'>".$name.getSubDepartmentTreeCode($value['department_id'])."</li>";
		}
		$string .= "</ul>";
	}

	return $string;
}

/**
 * @author JianXin dev team
 * @param $position_id
 * @param int $first
 * @param int $type type == 1获取授权完整树形图,type == 2获取选择授权树形图
 * @param $department_id
 * @return string
 */
function getSubPositionTreeCode($position_id, $first=0, $type=1, $department_id) {
	$string = "";
	$position_list = M('position')->where('parent_id = %d', $position_id)->select();
	$m_role_department = M('RoleDepartment');
	$d_role = D('RoleView');
	if($department_id){
		if($first){
			$position_list = M('position')->where('position_id = %d and department_id = %d', $position_id, $department_id)->select();
		}else{
			$position_list = M('position')->where('parent_id = %d and department_id = %d', $position_id, $department_id)->select();
		}
	}else{
		if($first && $department_id){
			$position_list = M('position')->where('position_id = %d', $position_id)->select();
		}else{
			$position_list = M('position')->where('parent_id = %d', $position_id)->select();
		}
	}
	
	if ($position_list) {
		if ($first) {
			if($type == 1)
				$string = '<ul class="position_browser filetree" style="margin-left:25px;">';
			else
				$string = '<ul class="filetree">';
		} else {
			$string = "<ul id='del'>";
		}
		foreach($position_list AS $value) {
			$department_name = $m_role_department->where('department_id = %d', $value['department_id'])->getField('name');
			$user_list = $d_role->where('position.position_id = %d', $value['position_id'])->select();
			$user_str = '';
			$user_count = 0;
			foreach($user_list as $v){
				$name = '';
				$name = $v['user_name'] ? $v['user_name'] : '无';
				if($v['status'] == '3'){
					$username = $name.'-未激活';
				}elseif($v['status'] == '1'){
					$username = $name;
				}
				if($v['status'] != '2'){
					$user_count++;
					$user_str .= $username.'、';
				}
			}
			// if(mb_strlen($user_str, 'UTF-8') > 30){
			// 	$user_str = mb_substr($user_str, 0, 30, 'UTF-8').'.....';
			// } 
			$user_str = mb_substr($user_str, 0, mb_strlen($user_str, 'UTF-8')-1, 'UTF-8');
			if($user_str) {
				$user_str = '&nbsp;'.$user_str.'&nbsp;';
			}
			
			$string .= "<li class='jstree-open'><a class='control_dep dep2' rel='".$value['position_id']."' href='javascript:void(0);'>".$value['name']." - ".$department_name."<span style='margin-left:20px;'>【".$user_count."名员工】".$user_str."</span></a>&nbsp;".$link_str.getSubPositionTreeCode($value['position_id'], 0, $type, $department_id)."</li>";
		}
		$string .= "</ul>";
	}
	return $string;
}

/**
 * @author JianXin dev team
 * @param bool $self
 * @param int $role_id $role_id = 0 为当前人下属roleid,$role_id = 1 为获得所有人roleid
 * @return array
 */
function getSubRoleId($self = true, $role_id=0){
	$all_role = M('role')->where('user_id <> 0')->select();
	if(!$role_id){
		$role_id = session('role_id');
		$below_role = getSubRole($role_id, $all_role);
	}else{
		$below_role = getSubRole(0, $all_role);
	}
	$below_ids = array();
	if ($self) {
		$below_ids[] = $role_id;
	}
	foreach ($below_role as $key=>$value) {
		$below_ids[] = $value['role_id'];
	}
	return array_map('intval', array_unique($below_ids));
}

/**
 * 手机端getSubRoleId 此方法弃用，使用 getSubRole
 * @author JianXin dev team
 * @param $role_id
 * @param bool $self
 * @return array
 */
function getSubRoleByRole($role_id, $self = true){
	$all_role = M('role')->where('user_id <> 0')->select();
	$below_role = getSubRole($role_id, $all_role);
	$below_ids = array();
	if ($self) {
		$below_ids[] = $role_id;
	}
	foreach ($below_role as $key=>$value) {
		if($value['role_id'] != session('role_id')){
			$below_ids[] = $value['role_id'];
		}
	}
	return $below_ids;
}

/**
 * @author JianXin dev team
 * @param $role_id
 * @param $role_list
 * @param $separate
 * @return array
 */
function getSubRole1($role_id, $role_list, $separate) {
	$search_disable_user = M('Config')->where('name="search_disable_user"')->getField('value');
	if ($search_disable_user) {
		$where_search_disable_user = ' && user.status != 3 ';
	} else {
		$where_search_disable_user = ' && user.status = 1 ';
	}
	$d_role = D('RoleView');
	if($d_role->where('role.role_id = %d', $role_id)->find()){
		$position_id = $d_role->where('role.role_id = %d', $role_id)->getField('position_id');
	}else{
		$position_id  = 0;
	}
	$sub_position = getPositionSub($position_id ,true, true);

	foreach($sub_position AS $position_id) {
		$son_role = $d_role->where('role.position_id = %d'.$where_search_disable_user, $position_id['position_id'])->select();
		foreach($son_role as $val){
			$array[] = array('role_id' => $val['role_id'],'user_id' => $val['user_id'], 'parent_id' => $val['parent_id'], 'name' => $separate . $val['department_name'] . ' | ' . $val['role_name']);
		}
	}
	return $array;
}

/**
 * @author JianXin dev team
 * @param $role_id
 * @param $role_list
 * @param $separate
 * @return array
 */
function getSubRole($role_id, $role_list, $separate = '') {
	$d_role = D('RoleView');
	if($d_role->where('role.role_id = %d', $role_id)->find()){
		$position_id = $d_role->where('role.role_id = %d', $role_id)->getField('position_id');
	}else{
		$position_id  = 0;
	}
	$sub_position = getPositionSub($position_id ,true, true);

	foreach($sub_position AS $position_id) {
		$son_role = $d_role->where('role.position_id = %d', $position_id['position_id'])->select();
		foreach($son_role as $val){
			$array[] = array('role_id' => $val['role_id'],'user_id' => $val['user_id'], 'parent_id' => $val['parent_id'], 'name' => $separate . $val['department_name'] . ' | ' . $val['role_name']);
		}
	}
	return $array;
}

/**
 * @author JianXin dev team
 * @param $position_id
 * @param bool $sub
 * @param bool $self_flag 为true时表示不包含自己岗位
 * @return array|false|mixed|PDOStatement|string|\think\Collection
 */
function getPositionSub($position_id , $sub = false, $self_flag = false){
	$sub_position = M('position')->where('parent_id = %d', $position_id)->select();
	
	$array = $sub_position;
	if($sub){
		if($sub_position){
			foreach($sub_position as $value){
				$son_position = getPositionSub($value['position_id'] ,$sub);
				if(!empty($son_position)){
					$array = array_merge($array, $son_position);
				}
			}
		}else{
			if(!$self_flag)	{
				$sub_position = M('position')->where('position_id = %d', $position_id)->find();
				$array[] = $sub_position;
			}
		}
	}
	return $array;
}


/**
 * @author JianXin dev team
 * @param $position_id
 * @param $position
 * @param $separate
 * @return array
 */
function getSubPosition($position_id, $position, $separate) {
	$array = array();
	foreach($position AS $key=> $value) {
		if ($position_id == $value['parent_id']) {
			$m_department = M('RoleDepartment');
			$department_name = $m_department->where('department_id = %d', $value['department_id'])->getField('name');
			$array[] = array('position_id' => $value['position_id'], 'name' => $separate . $department_name . ' | ' . $value['name'],'description'=>$value['description']);
			$array = array_merge($array, getSubPosition($value['position_id'], $position, $separate.' -- '));
		}
	}
	return $array;
}

/**
 * @author JianXin dev team
 * @param int $role_id
 */
function getSubDepartmentByRole($role_id = 0){
	if($role_id <= 0) $role_id = session('role_id');
	$department_id = M('Role')->where('role_id = %d', $role_id)->getField('department_id');
	//未完成方法
}

/**
 * 通过部门id获取该部门员工
 * @author JianXin dev team
 * @param $department_id
 * @param bool $sub false为下属范围  true为部门所有人
 * @return array|false|mixed|PDOStatement|string|\think\Collection
 */
function getRoleByDepartmentId($department_id, $sub=false){
	$id_array = array($department_id);
	$departments = M('roleDepartment')->select($department_id);
	$where['position.department_id'] = $department_id;
	if(!$sub) $where['role.role_id'] = array('in', getSubRoleId());
	$roleList = D('RoleView')->where($where)->select();
	foreach($departments AS $value) {
		if ($department_id == $value['parent_id']) {
			$id_array[] = $value['department_id'];
			$role_list = getRoleByDepartmentId($value['department_id']);
			if(!$roleList){
				$roleList = $role_list;
			}
			if(!empty($role_list)){
				$roleList = array_merge($roleList, $role_list);
			}
		}
	}
	$result=array();
    for($i=0;$i<count($roleList);$i++){
        $source=$roleList[$i];
        if(array_search($source,$roleList)==$i && $source<>"" ){
            $result[]=$source;
        }
    }
	// return array_unique($roleList, SORT_REGULAR);
	return $roleList;
}

/**
 * Warning提示信息
 * @param string $type 提示类型 默认支持success, error, info
 * @param string $msg 提示信息
 * @param string $url 跳转的URL地址
 * @param string $time 信息提示时间
 * @return void
 */
function alert($type='info', $msg='', $url='', $time=1000) {
    //多行URL地址支持
    $url        = str_replace(array("\n", "\r"), '', $url);
	$alert = unserialize(stripslashes(cookie('alert')));
    if (!empty($msg)) {
        $alert[$type][] = $msg;
		cookie('alert', serialize($alert));
	}
	cookie('alerttime', $time);
	
    if (empty($url)) {
		$url = U('index/index'); //定义无URL时的跳转地址
	}
	if (!headers_sent()) {
		header('Location: ' . $url);
		exit();
	} else {
		$str    = "<meta http-equiv='Refresh' content='0;URL={$url}'>";
		exit($str);
	}
	return $alert;
}

/**
 * @author JianXin dev team
 * @return mixed
 */
function parseAlert() {
	$alert['content'] = unserialize(stripslashes(cookie('alert')));
	$alert['time'] = cookie('alerttime');
	cookie('alert', null);

	return $alert;
}

/**
 * @author JianXin dev team
 * @param $role_id
 * @return array|false|mixed|PDOStatement|string|\think\Model
 */
function getUserByRoleId($role_id){
	$role = D('RoleView')->where('role.role_id = %d', $role_id)->find();
	$role['img'] = headPathHandle($role['img']);
	$role['thumb_path'] = headPathHandle($role['thumb_path']);
	return $role;
}

/**
 * 根据role_id获取员工信息
 * @author JianXin dev team
 * @param array $idArray
 * @return array
 */
function getUserByRoleIdArray($idArray = array())
{
	$roleList = array();
	$search_disable_user = M('Config')->where('name="search_disable_user"')->getField('value');
	foreach((array) $idArray as $roleId){
		if ($roleId == 0) continue;
		$user_info = getUserByRoleId($roleId);
		if ($search_disable_user) {
			$roleList[$roleId] = $user_info;
		} elseif ($user_info['status'] != 2) {
			$roleList[$roleId] = $user_info;
		}
	}
	return $roleList;
}

/**
 * @author JianXin dev team
 * @param $url
 * @param array $params
 * @param array $headers
 * @return mixed
 */
function sendRequest($url, $params = array() , $headers = array()) {
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
	if (!empty($params)) {
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
	}
	if (!empty($headers)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	}
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$txt = curl_exec($ch);
	if (curl_errno($ch)) {
        $array[0] = 0;
        $array[1] = L("CONNECT TO A SERVER ERROR");
        $array[2] = -1;
		$return = $array;
	} else {
		$return = json_decode($txt, true);
		if (!$return) {
            $array[0] = 0;
            $array[1] = L("THE SERVER RETURNS DATA ANOMALIES");
            $array[2] = -1;
			$return = $array;
		}
	}

	return $return;
}

/**
 * 生成评论提醒标题
 * @author JianXin dev team
 * @param $module
 * @param $module_id
 * @return mixed|string|void
 */
function createCommentAlertInfo($module, $module_id){
	$author = D('RoleView')->where('role.role_id = %d', session('role_id'))->find();
	if($module == 'log'){
		$log = M('log')->where('log_id = %d', $module_id)->find();
		$title = L('LOG COMMENT TITLE',array($log['subject'],$author['user_name'],$author['department_name'],$author['role_name']));
	}
	return $title;
}

/**
 * @author JianXin dev team
 * @param $id
 * @param $content
 * @param int $sysMessage 1 为系统消息
 * @param $send_type 1 为文本格式 2 附件格式
 * @return bool|mixed
 */
function sendMessage($id, $content, $sysMessage=0, $send_type = 0){
	if(!$id) return false;
	if(!$content) return false;
	$m_message = M('message');
	$m_config = M('Config');
	if($sysMessage == 0) $data['from_role_id'] = session('role_id');
	$data['to_role_id'] = $id;
	if($send_type == 2){
		$data['file_id'] = $content;
		$data['content'] = '';
		$content = '附件格式';
	}else{
		$data['content'] = $content ? str_replace('/vue.php?','/index.php?',$content) : '';
	}
	//推送过滤html代码
	$appcontent = strip_tags($content);
	$appcontent = str_replace('&nbsp;', ' ', $appcontent);
	$num_id = $m_config->where('name = "num_id"')->getField('value');
	$data['read_time'] = 0;
	$data['send_time'] = time();
	return $m_message->add($data);
}


/**
 * @author JianXin dev team
 * @return bool
 */
function isMobile(){

    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    $mobile_agents = Array("240x320","acer","acoon","acs-","abacho","ahong","airness","alcatel","amoi","android","anywhereyougo.com","applewebkit/525","applewebkit/532","asus","audio","au-mic","avantogo","becker","benq","bilbo","bird","blackberry","blazer","bleu","cdm-","compal","coolpad","danger","dbtel","dopod","elaine","eric","etouch","fly ","fly_","fly-","go.web","goodaccess","gradiente","grundig","haier","hedy","hitachi","htc","huawei","hutchison","inno","ipad","ipaq","ipod","jbrowser","kddi","kgt","kwc","lenovo","lg ","lg2","lg3","lg4","lg5","lg7","lg8","lg9","lg-","lge-","lge9","longcos","maemo","mercator","meridian","micromax","midp","mini","mitsu","mmm","mmp","mobi","mot-","moto","nec-","netfront","newgen","nexian","nf-browser","nintendo","nitro","nokia","nook","novarra","obigo","palm","panasonic","pantech","philips","phone","pg-","playstation","pocket","pt-","qc-","qtek","rover","sagem","sama","samu","sanyo","samsung","sch-","scooter","sec-","sendo","sgh-","sharp","siemens","sie-","softbank","sony","spice","sprint","spv","symbian","tablet","talkabout","tcl-","teleca","telit","tianyu","tim-","toshiba","tsm","up.browser","utec","utstar","verykool","virgin","vk-","voda","voxtel","vx","wap","wellco","wig browser","wii","windows ce","wireless","xda","xde","zte");

    $is_mobile = false;

    foreach ($mobile_agents as $device) {
        if (stristr($user_agent, $device)) {
            $is_mobile = true;
            break;
        }
    }

    return $is_mobile;
}

/**
 * @author JianXin dev team
 * @param $liehuo_net
 * @return bool
 */
function is_utf8($liehuo_net){
	if (preg_match("/^([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}/",$liehuo_net) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){1}$/",$liehuo_net) == true || preg_match("/([".chr(228)."-".chr(233)."]{1}[".chr(128)."-".chr(191)."]{1}[".chr(128)."-".chr(191)."]{1}){2,}/",$liehuo_net) == true)
	{
		return true;
	}
	else
	{
		return false;
	}
}

/**
 * 验重二维数组排序  $arr 数组 $keys比较的键值
 * @author JianXin dev team
 * @param $arr
 * @param $keys
 * @param string $type
 * @return array
 */
function array_sort($arr, $keys, $type='asc'){
	$keysvalue = $new_array = array();
	foreach ($arr as $k=>$v){
		$keysvalue[$k] = $v[$keys];
	}
	if($type == 'asc'){
		asort($keysvalue);
	}else{
		arsort($keysvalue);
	}
	reset($keysvalue);
	$i = 0;
	foreach ($keysvalue as $k=>$v){
		if($i < 8 && $arr[$k][search] > 0){
			$new_array[] = $arr[$k]['value'];
			$i++;
		}

	}
	return $new_array;
}

/**
 * function	对二位数组进行指定规则的排序
 * return	排序后的二维数组
 * @arr 	传入要排序的数组
 * @keys	要排序的字段
 * @type	排序规则
 **/
function array_sorts($arr,$keys,$type='asc'){
	$keysvalue = $new_array = array();
	foreach ($arr as $k=>$v){
		$keysvalue[$k] = $v[$keys];
	}
	if($type == 'asc'){
		asort($keysvalue);
	}else{
		arsort($keysvalue);
	}
	reset($keysvalue);
	foreach ($keysvalue as $k=>$v){
		$new_array[$k] = $arr[$k];
	}
	return $new_array;
}

/**
 *自定义字段html输出 
 *$field为特殊验重字段，$d_module=($ModuelView)，$special为contacts时，用于客户添加时的联系人字段名处理
 *$status 自定义审批类型
**/
function field_list_html($type="add",$module="",$d_module=array(),$special='',$status=0){
	if ($type == "add") {
		if($module == 'customer'){
			$field_list = M('Fields')->where(array('model'=>$module,'in_add'=>1))->order('order_id')->select();
		}else{
			$where_field = array();
			$where_field['model'] = $module;
			$where_field['in_add'] = 1;
			$where_field['status'] = $status;
			$field_list = M('Fields')->where($where_field)->order('order_id')->select();
		}
	} else {
		$where_field = array();
		$where_field['model'] = $module;
		$where_field['status'] = $status;
		$field_list = M('Fields')->where($where_field)->order('order_id')->select();
	}
	foreach($field_list as $k=>$v){
		if(trim($v['input_tips'])){
			$input_tips = ' &nbsp; <span style="color:#999;float:left;margin-top:5px;">('.L('NOTE_').$v['input_tips'].')</span>';
		}else{
			$input_tips = '';
		}
		//客户添加页同时添加联系人时，处理联系人字段名，防止和客户重复
		if($special == 'contacts'){
			$v['field'] = "con_contacts[{$v['field']}]";
		}

		if('add' == $type){
			$value = $v['default_value'];
		} elseif ('edit' == $type && !empty($d_module)) {
			if($module == 'customer' && $type == 'edit' && $d_module['leads_id']){
				$value = isset($d_module[$v['field']]) ? $d_module[$v['field']] : $v['default_value'];
			}else{
				$value = isset($d_module[$v['field']]) ? $d_module[$v['field']] : '';
			}
		}

		if($d_module['customer_id']){
			$customer_id = intval($d_module['customer_id']);
		}else{
			$customer_id = intval($_GET['customer_id']);
		}

		if($customer_id){
			$customer = M('customer')->where('customer_id = %d', $customer_id)->find();
			if($d_module['contacts_id']){
				$contacts = M('contacts')->where('contacts_id = %d', $d_module['contacts_id'])->find();
			}else{
				$contacts = M('contacts')->where('contacts_id = %d', $customer['contacts_id'])->find();
			}
		}
		if ($v['field'] == 'customer_id') {
			if($customer_id){
				$field_list[$k]['html'] = '<div class="form-inline"><input type="hidden" name="'.$v['field'].'" id="customer_id" value="'.$customer['customer_id'].'"/><input  type="text" class="form-control required pull-left" style="width:100%;cursor:pointer;" readonly="true" title="点击选择" name="customer_name" id="customer_name" value="'.$customer['name'].'"/> <a target="_blank" class="btn btn-primary btn-sm pull-right" style="width:65px;display:none;" href="'.U('customer/add').'">'.L('CREATE NEW CUSTOMER').'</a></div>';
			}else{
				$field_list[$k]['html'] = '<div class="form-inline"><input type="hidden" name="'.$v['field'].'" id="customer_id"/><input  class="form-control required pull-left" style="width:100%;cursor:pointer;" readonly="true" title="点击选择" type="text" name="customer_name" id="customer_name"> <a target="_blank" class="btn btn-primary btn-sm pull-right" style="width:65px;display:none;" href="'.U('customer/add').'">'.L('CREATE NEW CUSTOMER').'</a></div>';
			}
		}elseif($v['field'] == 'contacts_id'){
			if($customer_id){
				$field_list[$k]['html'] = '<input type="hidden" name="contacts_id" id="contacts_id" value="'.$contacts['contacts_id'].'"/><input  type="text" class="form-control" name="contacts_name" id="contacts_name" value="'.$contacts['name'].'"/>';
			}else{
				$field_list[$k]['html'] = '<input type="hidden" name="contacts_id" id="contacts_id"/><input  type="text" class="form-control" name="contacts_name" id="contacts_name"/>';
			}
		}elseif($module == 'customer' && $v['field'] == 'tags'){
			//客户标签
			$tagsStr = substr($d_module['tags'], '1', strlen($d_module['tags'])-2);
			if($tagsStr !=''){
				$tagsName = M('tags')->where('tags_id in ( %s )', $tagsStr)->getField('name',true);
			}
			$field_list[$k]['html'] = '<input type="text" name="tags" id="tags" value="'.implode(',', $tagsName).'" />';
		}else{
			//验证
			$required = '';
			$maxlength = '';
			$tip_start = 0;
			//是否为空
			if($v['is_validate'] == 1 && $v['is_null'] == 1){
				$required = 'required';
				$tip_start = 1;
				$field_list[$k]['tip_start'] = $tip_start;
			}
			//是否验重
			$field_onblur = '';
			if($v['is_validate'] == 1 && $v['is_recheck'] == 1){
				//调用查重check方法的结果展示控制
				$field_name = '';
				$field_name = "'".$v['field']."'";
				if (($module == 'customer' && $v['field'] == 'name') || ($module == 'leads' && $v['field'] == 'name')) {
					$field_onblur = 'onblur="checkinfo('.$field_name.')" is_check="1"';
				} else {
					$field_onblur = 'onblur="checkinfo('.$field_name.')"';
				}
			}

			if($special == 'contacts'){
				$required = '';
			}
			if(!empty($v['maxlength'])){
				$maxlength = 'maxlength='.'"'.$v['maxlength'].'"';
			}
            switch ($v['form_type']) {
                case 'textarea' :
                    $field_list[$k]['html'] = '<textarea rows="5" class="form-control '.$required.'" id="'.$v['field'].'" name="'.$v['field'].'" >'.$value.'</textarea><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
                    break;
                case 'box' :
                    $setting_str = '$setting='.$v['setting'].';';
                    eval($setting_str);

                    $field_list[$k]['setting'] = $setting;
                    if ($setting['type'] == 'select') {
                        $str = '';
                        $str .= "<option value=''>--".L('PLEASE CHOOSE')."--</option>";
                        foreach ($setting['data'] as $v2) {
                            $str .= "<option value='$v2'";
							$str .= $value == $v2 ? ' selected="selected" ':'';
                            $str .= ">$v2</option>";
                        }
                        $field_list[$k]['html'] = '<select class="form-control '.$required.'" id="'.$v['field'].'" name="'.$v['field'].'">'.$str.'</select><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
						break;
                    } elseif ($setting['type'] == 'radio') {
                        $str = '';
                        $i = '';
                        foreach ($setting['data'] as $v2) {
                            $str .= " &nbsp; <div class='radio radio-info radio-inline'><input type='radio' name='".$v['field']."' id='".$v['field'].$i."' value='$v2'";
							$str .= $value == $v2 ? ' checked="checked"':'';
                            $str .= "/><label for='".$v['field'].$i."'>$v2</label></div>";
                            $i++;
                        }
                        $field_list[$k]['html'] = '&nbsp;&nbsp;&nbsp;'.$str.'<span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
                        break;
                    } elseif ($setting['type'] == 'checkbox') {
                        $str = '';
                        $i = '';
                        foreach ($setting['data'] as $v2) {
                            $str .= " &nbsp; <div class='checkbox checkbox-info' style='float:left;'><input type='checkbox' name='".$v['field']."[]' id='".$v['field'].$i."' value='$v2'";
							// if(strstr($value,$v2)){
                            if (in_array($v2, explode(chr(10), $value))) {
								$str .= ' checked="checked"';
							}
                            $str .= '/>&nbsp;<label for="'.$v['field'].$i.'">' .$v2.'</label></div>';
                            $i++;
                        }
                        $field_list[$k]['html'] = $str.' <span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>&nbsp; '.$input_tips;
                        break;
                    }
                    break;
                case 'datetime' :
					if($v['field'] == 'nextstep_time'){
						$time_accuracy = 'yyyy-MM-dd HH:mm';
						if ($value > 0) {
							$temp_value = date('Y-m-d H:i', $value);
						}
					}else{
						$time_accuracy = 'yyyy-MM-dd';
						if ($value > 0) {
							$temp_value = date('Y-m-d', $value);
						}
					}
                    $field_list[$k]['html'] = '<input class="form-control Wdate '.$required.'" input_type="time" onFocus="WdatePicker({dateFmt:\''.$time_accuracy.'\'})" name="'.$v['field'].'" id="'.$v['field'].'" type="text" value="'.$temp_value.'"/><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
                    break;
                case 'number' :
                    $field_list[$k]['html'] = '<input class="form-control digits '.$required.'" type="text" data-type="nummber" onkeyup="num_input(this)" '.$field_onblur.' id="'.$v['field'].'" name="'.$v['field'].'" '.$maxlength.' value="'.$value.'"/><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
                    break;
                case 'floatnumber' :
					$value = $value > 0 ? $value : '';
                    $field_list[$k]['html'] = '<input class="form-control number '.$required.'" type="text" id="'.$v['field'].'" name="'.$v['field'].'" value="'.$value.'" onblur="bu(this)" onkeyup="num_input(this)" '.$field_onblur.' /><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
                    break;
                case 'address':
					if('add' == $type){
						$defaultinfo = unserialize(M('Config')->where('name = "defaultinfo"')->getField('value'));
						$state = $defaultinfo['state'];
						$city = $defaultinfo['city'];
						$area = $defaultinfo['area'];
					}else{
						$address_array = explode(chr(10),$value);
						$state = $address_array[0];
						$city = $address_array[1];
						$area = $address_array[2];
						$street = $address_array[3];
					}
					$field_list[$k]['html'] = '<script type="text/javascript">
					$(function(){
						new PCAS("'.$v['field'].'[state]","'.$v['field'].'[city]","'.$v['field'].'[area]","'.$state.'","'.$city.'","'.$area.'");
					});
					</script><select class="form-control " input_type="address" name="'.$v['field'].'[state]" style="width:32%;float:left;" ></select>
						<select class="form-control " input_type="address" name="'.$v['field'].'[city]" style="width:32%;float:left;margin-left:1%;"></select>
						<select class="form-control " input_type="address" name="'.$v['field'].'[area]" style="width:32%;float:left;margin-left:1%;"></select>
						<input class="form-control" input_type="address" type="text" name="'.$v['field'].'[street]" placeholder="'.L('THE STREET INFORMATION').'" class="input-large" value="'.$street.'" style="float:left;margin-top:5px;">';
					break;
                case 'p_box':
                        $str = '';
                        $category = M('product_category');
                        $category_list = $category->select();
                        $categoryList = getSubCategory(0, $category_list, '');
                        foreach ($categoryList as $v2) {
                            $checked = '';
                            if($v2['category_id'] == $value){
                                $checked = 'selected="selected"';
                            }
                            $str .= "<option $checked value=".$v2['category_id'].">".$v2['name']."</option>";

                        }
                        $field_list[$k]['html'] = '<select class="form-control '.$required.'" id="'.$v['field'].'" name="'.$v['field'].'">'.$str.'</select><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;

                    break;
                case 'b_box':
                        $status = M('BusinessStatus')->order('order_id')->select();
                        $str = '';
                        foreach ($status as $v2) {
							$checked = '';
                            if($v2['status_id'] == $value){
                                $checked = 'selected="selected"';
                            }
                            $str .= "<option $checked value='".$v2['status_id']."'>".$v2['name']."</option>";
                        }
                        $field_list[$k]['html'] = '<select class="form-control '.$required.'" id="'.$v['field'].'" name="'.$v['field'].'">'.$str.'</select><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
                    break;
				case 'email':
						$field_list[$k]['html'] = '<input class="form-control '.$required.'" type="email" id="'.$v['field'].'" name="'.$v['field'].'" '.$maxlength.' '.$field_onblur.' value="'.$value.'" /><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
					break;
				case 'mobile':
					$m_type = ($module == 'contacts') ? 'phone' : 'mobile';	
					$field_list[$k]['html'] = '<input class="form-control '.$required.'" type="'. $m_type .'" id="'.$v['field'].'" name="'.$v['field'].'" '.$maxlength.' '.$field_onblur.' value="'.$value.'" /><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
					break;
                default:
                    if ($v['field'] == 'create_time' || $v['field'] == 'update_time') {
                        break;
                    }else{
                        $customer_id = intval($_GET['customer_id']);
						
                        if($v['field'] == 'name' && $customer_id && $module == 'customer') {
                        	$value=M('customer')->where('customer_id = %d', $customer_id)->getField('name');
                        }
						if($special == 'contacts' && $v['field'] == 'con_contacts[name]'){
							$input_tips = ' &nbsp; <span style="color:#999;float:left;margin-top:5px;">如有联系人信息，则联系人姓名不能为空</span>';
						}
						$field_list[$k]['html'] = '<input class="form-control '.$required.'"  type="text" id="'.$v['field'].'" name="'.$v['field'].'" '.$maxlength.' '.$field_onblur.' value="'.$value.'"/><span id="'.$v['field'].'Tip" style="float: left;line-height: 32px;margin-left: 5%;color:red;"></span>'.$input_tips;
                    }
                    break;
            }
        }
        if($field_list[$k]['is_main'] == 1){
            $fieldlist['main'][] = $field_list[$k];
        }else{
            $fieldlist['data'][] = $field_list[$k];
        }
	}
	return $fieldlist;
}

/**
 * 自定义字段html输出
 * @author JianXin dev team
 * @param string $type
 * @param string $module
 * @param array $d_module
 * @return mixed
 */
function field_list_mobile_html($type="add", $module="", $d_module=array()){
	if ($type == "add") {
		$field_list = M('Fields')->where('model = "'.$module.'" and in_add = 1')->order('order_id')->select();
	} else {
		$field_list = M('Fields')->where('model = "'.$module.'"')->order('order_id')->select();
	}

	foreach($field_list as $k=>$v){
		if(trim($v['input_tips'])){
			//$input_tips = ' &nbsp; <span style="color:#005580;">('.L('NOTE_').$v['input_tips'].')</span>';
			$input_tips = $v['input_tips'];
		}else{
			$input_tips = '';
		}
		if('add' == $type){
			$value = $v['default_value'];
		} elseif ('edit' == $type && !empty($d_module)) {
			$value = $d_module[$v['field']] !== '' ? $d_module[$v['field']] : '';
		}

		if($d_module['customer_id']){
			$customer_id = intval($d_module['customer_id']);
		}else{
			$customer_id = intval($_GET['customer_id']);
		}

		if($customer_id){
			$customer = M('customer')->where('customer_id = %d', $customer_id)->find();
			if($d_module['contacts_id']){
				$contacts = M('contacts')->where('contacts_id = %d', $d_module['contacts_id'])->find();
			}else{
				$contacts = M('contacts')->where('contacts_id = %d', $customer['contacts_id'])->find();
			}
		}
		if ($v['field'] == 'customer_id') {				
			if($customer_id){
				$field_list[$k]['html'] = '<input type="hidden" name="'.$v['field'].'" id="customer_id" value="'.$customer['customer_id'].'"/><input  type="text" name="customer_name" id="customer_name" value="'.$customer['name'].'"/></br><a target="_blank" href="'.U('customer/add').'">'.L('CREATE NEW CUSTOMER').'</a>';
				
			}else{
				$field_list[$k]['html'] = '<input type="hidden" name="'.$v['field'].'" id="customer_id"/><input  type="text" name="customer_name" id="customer_name"></br><a target="_blank" href="add_customer:business">'.L('CREATE NEW CUSTOMER').'</a>';
			}
		}elseif($v['field'] == 'contacts_id'){
			if($customer_id){
				$field_list[$k]['html'] = '<input type="hidden" name="contacts_id" id="contacts_id" value="'.$contacts['contacts_id'].'"/><input  type="text" name="contacts_name" id="contacts_name" value="'.$contacts['name'].'"/>';
			}else{
				$field_list[$k]['html'] = '<input type="hidden" name="contacts_id" id="contacts_id"/><input  type="text" name="contacts_name" id="contacts_name"/>';
			}
		}elseif($module == 'customer' && $v['field'] == 'tags'){
			//客户标签
			$tagsStr = substr($d_module['tags'], '1', strlen($d_module['tags'])-2);
			if($tagsStr !=''){
				$tagsName = M('tags')->where('tags_id in ( %s )', $tagsStr)->getField('name',true);
			}
			$field_list[$k]['html'] = '<input type="text" name="tags" id="tags" value="'.implode(',', $tagsName).'" />';
		}else{
            switch ($v['form_type']) {
                case 'textarea' :
                    $field_list[$k]['html'] = '<textarea  rows="6"  placeholder="'.$input_tips.'" class="span6" id="'.$v['field'].'" name="'.$v['field'].'" >'.$value.'</textarea><span id="'.$v['field'].'Tip" style="color:red;"></span>';
                    break;
                case 'box' :
                    $setting_str = '$setting='.$v['setting'].';';
                    eval($setting_str);

                    $field_list[$k]['setting'] = $setting;
                    if ($setting['type'] == 'select') {
                        $str = '';
                        $str .= "<option value=''>--请选择--</option>";
                        foreach ($setting['data'] as $v2) {
                            $str .= "<option value='$v2'";
                            $str .= $d_module[$v['field']] == $v2 ? ' selected="selected" ':'';
                            $str .= ">$v2</option>";
                        }
                        $field_list[$k]['html'] = '<select style="width:80%" id="'.$v['field'].'" name="'.$v['field'].'">'.$str.'</select><span id="'.$v['field'].'Tip" style="color:red;"></span>'.$input_tips;
						break;
                    } elseif ($setting['type'] == 'radio') {
						$str = '';
                        $str .= "<option value=''>--请选择--</option>";
                        foreach ($setting['data'] as $v2) {
                            $str .= "<option value='$v2'";
                            $str .= $d_module[$v['field']] == $v2 ? ' selected="selected" ':'';
                            $str .= ">$v2</option>";
                        }
                        $field_list[$k]['html'] = '<select style="width:80%" id="'.$v['field'].'" name="'.$v['field'].'">'.$str.'</select><span id="'.$v['field'].'Tip" style="color:red;"></span>'.$input_tips;
						break;
                       
                    } elseif ($setting['type'] == 'checkbox') {
                        $str = '';
                        $i = '';
                        foreach ($setting['data'] as $v2) {
                            $str .= " &nbsp; <input type='checkbox' name='".$v['field']."[]' id='".$v['field'].$i."' value='$v2'";
                            if(strstr($d_module[$v['field']],$v2)){
                                $str .= ' checked="checked"';
                            }
                            $str .= '/>&nbsp;' .$v2;
                            $i++;
                        }
                        $field_list[$k]['html'] = $str.' <span id="'.$v['field'].'Tip" style="color:red;"></span>&nbsp; '.$input_tips;
                        break;
                    }
                    break;
                case 'editor' :
					if($type == 'edit' ){
						$field_list[$k]['html'] = '<input type="text" readonly="true" placeholder="--暂不支持该类型--" />';
						break;
					}else{
						$field_list[$k]['html'] = '<textarea  rows="6"  placeholder="'.$input_tips.'" class="span6" id="'.$v['field'].'" name="'.$v['field'].'" >'.$value.'</textarea><span id="'.$v['field'].'Tip" style="color:red;"></span>';
						break;
					}
                case 'datetime' :
					if($v['field'] == 'nextstep_time'){
						$time_accuracy = 'yyyy-MM-dd HH:mm';
					}else{
						$time_accuracy = 'yyyy-MM-dd';
					}
                    $field_list[$k]['html'] = '<input readonly="true"  onFocus="WdatePicker({dateFmt:\''.$time_accuracy.'\'})" name="'.$v['field'].'" id="'.$v['field'].'" type="text" value="'.pregtime($value).'"/></br><span id="'.$v['field'].'Tip" style="color:red;"></span>';
                    break;
                case 'number' :
                    $field_list[$k]['html'] = '<input type="text"  placeholder="'.$input_tips.'"  id="'.$v['field'].'" name="'.$v['field'].'" maxlength="'.$v['maxlength'].'" value="'.$value.'"/></br><span id="'.$v['field'].'Tip" style="color:red;"></span>';
                    break;
                case 'floatnumber' :
                    $value = $value > 0 ? $value : '';
                    $field_list[$k]['html'] = '<input type="text" placeholder="'.$input_tips.'" id="'.$v['field'].'" name="'.$v['field'].'" value="'.$value.'"/></br>  <span id="'.$v['field'].'Tip" style="color:red;"></span>';
                    break;
                case 'address':
					if('add' == $type){
						$defaultinfo = unserialize(M('Config')->where('name = "defaultinfo"')->getField('value'));
						$state = $defaultinfo['state'];
						$city = $defaultinfo['city'];
						$area = $defaultinfo['area'];
					}else{
						$address_array = explode(chr(10),$value);
						$state = $address_array[0];
						$city = $address_array[1];
						$area = $address_array[2];
						$street = $address_array[3];
					}
					$field_list[$k]['html'] = '<script type="text/javascript">
					$(function(){
						new PCAS("'.$v['field'].'[\'state\']","'.$v['field'].'[\'city\']","'.$v['field'].'[\'area\']","'.$state.'","'.$city.'","'.$area.'");
					});
					</script><select name="'.$v['field'].'[\'state\']" class="input-medium"></select>
						<select name="'.$v['field'].'[\'city\']" class="input-medium"></select>
						<select name="'.$v['field'].'[\'area\']" class="input-medium"></select>
						<input type="text" name="'.$v['field'].'[\'street\']" placeholder="'.L('THE STREET INFORMATION').'" class="input-large" value="'.$street.'">';
					break;
                case 'p_box':
                        $str = '';
                        $category = M('product_category');
                        $category_list = $category->select();
                        $categoryList = getSubCategory(0, $category_list, '');
                        foreach ($categoryList as $v2) {
                            $checked = '';
                            if($v2['category_id'] == $value){
                                $checked = 'selected="selected"';
                            }
                            $str .= "<option $checked value=".$v2['category_id'].">".$v2['name']."</option>";

                        }
                        $field_list[$k]['html'] = '<select style="width:80%" id="'.$v['field'].'" name="'.$v['field'].'">'.$str.'</select><span id="'.$v['field'].'Tip" style="color:red;"></span>'.$input_tips;

                    break;
                case 'b_box':
                        $status = M('BusinessStatus')->order('order_id')->select();
                        $str = '';
                        foreach ($status as $v2) {
							$checked = '';
                            if($v2['status_id'] == $value){
                                $checked = 'selected="selected"';
                            }
                            $str .= "<option $checked value='".$v2['status_id']."'>".$v2['name']."</option>";
                        }
                        $field_list[$k]['html'] = '<select style="width:80%" id="'.$v['field'].'" name="'.$v['field'].'">'.$str.'</select><span id="'.$v['field'].'Tip" style="color:red;"></span>'.$input_tips;
                    break;
                default:
                    if ($v['field'] == 'create_time' || $v['field'] == 'update_time') {
                        break;
                    }else{
                        $customer_id = intval($_GET['customer_id']);
                        if($v['field'] == 'name' && $customer_id && $module == 'customer') $value=M('customer')->where('customer_id = %d', $customer_id)->getField('name');
                        $field_list[$k]['html'] = '<input type="text"  placeholder="'.$input_tips.'" id="'.$v['field'].'" name="'.$v['field'].'" maxlength="'.$v['maxlength'].'" value="'.$value.'"/></br><span id="'.$v['field'].'Tip" style="color:red;"></span>';
                    }
                    break;
            }
        }
        if($field_list[$k]['is_main'] == 1){
            $fieldlist['main'][] = $field_list[$k];
        }else{
            $fieldlist['data'][] = $field_list[$k];
        }
	}
	return $fieldlist;
}

/**
 * 判断目录是否可写
 * @author JianXin dev team
 * @param $dir_path
 * @return int
 */
function check_dir_iswritable($dir_path){
    $dir_path=str_replace('\\','/',$dir_path);
    $is_writale=1;
    if(!is_dir($dir_path)){
        $is_writale=0;
        return $is_writale;
    }else{
        $file_hd=@fopen($dir_path.'/test.txt','w');
        if(!$file_hd){
            @fclose($file_hd);
            @unlink($dir_path.'/test.txt');
            $is_writale=0;
            return $is_writale;
        }
		@fclose($file_hd);
        @unlink($dir_path.'/test.txt');
        $dir_hd=opendir($dir_path);
        while(false!==($file=readdir($dir_hd))){
            if ($file != "." && $file != "..") {
                if(is_file($dir_path.'/'.$file)){
                    //文件不可写，直接返回
                    if(!is_writable($dir_path.'/'.$file)){
                        return 0;
                    }
                }else{
                    $file_hd2=@fopen($dir_path.'/'.$file.'/test.txt','w');
                    if(!$file_hd2){
                        @fclose($file_hd2);
                        @unlink($dir_path.'/'.$file.'/test.txt');
                        $is_writale=0;
                        return $is_writale;
                    }
                    @unlink($dir_path.'/test.txt');
                    //递归
                    $is_writale=check_dir_iswritable($dir_path.'/'.$file);
                }
            }
        }
    }
return $is_writale;
}

/**
 * @author JianXin dev team
 * @param $email
 * @return bool
 */
function is_email($email)
{
	//$pattern = "/^([0-9A-Za-z\\-_\\.]+)@([0-9a-z]+\\.[a-z]{2,3}(\\.[a-z]{2})?)$/i";
	$pattern = "/^[-_+.[:alnum:]]+@((([[:alnum:]]|[[:alnum:]][[:alnum:]-]*[[:alnum:]])\.)+([a-z]{2,4})|(([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5])\.){3}([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5]))$/i";
	return strlen($email) > 7 && preg_match($pattern, $email);
}

/**
 * @author JianXin dev team
 * @param $phone
 * @return bool
 */
function is_phone($phone)
{
	return strlen(trim($phone)) == 11 && preg_match("/^1[3|4|5|6|7|8|9][0-9]{9}$/i", trim($phone));
}

/**
 * @author JianXin dev team
 * @param $timestamp
 * @return false|string
 */
function pregtime($timestamp){
	if($timestamp){
		return date('Y-m-d',$timestamp);
	}else{
		return '';
	}
}


/**
 * @author JianXin dev team
 * @param $uid
 * @param string $text
 * @return bool
 */
function userLog($uid, $text=''){
    $user = M('user')->where(array('user_id'=>$uid))->find();
    $category = $user['category_id'] == 1 ? L('ADMIN') : L('USER');
    $data['user_id'] = $uid;
	$data['module_name'] = strtolower(MODULE_NAME);
    $data['action_name'] = strtolower(ACTION_NAME);
    $data['create_time'] = time();
 //   $data['action_id'] = $id;
    $data['content'] = sprintf('%s%s在%s%s。%s',$category,$user['name'],date('Y-m-d H:i:s'),L(ACTION_NAME),$text);
    $userLog = M('userLog');
    $userLog->create($data);
    if($userLog->add()){return true;}else{return false;}

}

/**
 * @author JianXin dev team
 * @param $m
 * @param $a
 * @return bool
 */
function vali_permission($m, $a){
	$allow = $params['allow'];

	if (session('?admin')) {
		return true;
	}
	if (in_array($a, $allow)) {
		return true;
	} else {
		switch ($a) {
			case "listdialog" : $a = 'index'; break;
			case "adddialog" : $a = 'add'; break;
			case "excelimport" : $a = 'add'; break;
			case "excelexport" : $a = 'view'; break;
			case "cares" :  $a = 'index'; break;
			case "caresview" :  $a = 'view'; break;
			case "caresedit" :  $a = 'edit'; break;
			case "caresdelete" :   $a = 'delete'; break;
			case "caresadd" :  $a = 'add'; break;
			case "receive" : $a = 'add'; break;
			case "role_add" : $a = 'add';break;
		}
		$url = strtolower($m).'/'.strtolower($a);
		$ask_per = M('permission')->where('url = "%s" and position_id = %d', $url, session('position_id'))->find();
		if (is_array($ask_per) && !empty($ask_per)) {
			return true;
		} else {
			return false;
		}
	}
}

/**
 * formmat the print_r to debug the array conveniently
 * @author JianXin dev team
 * @param $data
 * @param bool $offset
 */
function println($data, $offset=true){
	if(empty($data)){
		echo '<pre>返回数据为空！</pre>';
	}else{
		echo '<pre>'; print_r($data); echo '</pre>';
	}
	if($offset){
		die;
	}
}

/**
 * 验证某条数据的权限
 * @author JianXin dev team
 * @param $module_id
 * @param $module
 * @param string $permission_field
 * @return bool
 */
function check_permission($module_id, $module, $permission_field='owner_role_id'){
	$role_id = intval(session('role_id'));
	$owner_role_id = M($module)->where($module.'_id = %d', $module_id)->getField($permission_field);
	$permission_ids = getSubRoleId();
	if(in_array($owner_role_id, $permission_ids) || !$owner_role_id) return true;
	else return false;
}

/**
 * 下载方法
 * @author JianXin dev team
 * @param $file
 * @param string $name
 */
 function download($file,$name=''){
    $fileName = $name ? $name : pathinfo($file,PATHINFO_FILENAME);
    $filePath = realpath($file);

    $fp = fopen($filePath,'rb');
	if (strpos($filePath, 'Uploads') === false && strpos($filePath, 'Public') === false) {
		alert('error','sorry，文件不存在！',$_SERVER['HTTP_REFERER']);
	}
	
    $fileName = $fileName .'.'. pathinfo($filePath,PATHINFO_EXTENSION);
    $encoded_filename = urlencode($fileName);
    $encoded_filename = str_replace("+", "%20", $encoded_filename);

    header('HTTP/1.1 200 OK');
    header( "Pragma: public" );
    header( "Expires: 0" );
    header("Content-type: application/octet-stream");
    header("Content-Length: ".filesize($filePath));
    header("Accept-Ranges: bytes");
    header("Accept-Length: ".filesize($filePath));

    $ua = $_SERVER["HTTP_USER_AGENT"];
    if (preg_match("/MSIE/", $ua)) {
        header('Content-Disposition: attachment; filename="' . $encoded_filename . '"');
    } else if (preg_match("/Firefox/", $ua)) {
        header('Content-Disposition: attachment; filename*="utf8\'\'' . $fileName . '"');
    } else {
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
    }

    // ob_end_clean(); <--有些情况可能需要调用此函数
    // 输出文件内容
    fpassthru($fp);
    exit;
 }

/**
 * 获取表信息
 * @author JianXin dev team
 * @param $table_name 表名(不含表前缀)
 * @return mixed
 */
function getTableInfo($table_name){
	$sql = 'SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = "'.C('DB_NAME').'" and table_name LIKE "'.C('DB_PREFIX').$table_name.'"';
	$result = M('')->query($sql);
	return $result;
}

/**
 * filemanager排序
 * @author JianXin dev team
 * @param $a
 * @param $b
 * @return int
 */
function cmp_func($a, $b) {
	global $order;
	if ($a['is_dir'] && !$b['is_dir']) {
		return -1;
	} else if (!$a['is_dir'] && $b['is_dir']) {
		return 1;
	} else {
		if ($order == 'size') {
			if ($a['filesize'] > $b['filesize']) {
				return 1;
			} else if ($a['filesize'] < $b['filesize']) {
				return -1;
			} else {
				return 0;
			}
		} else if ($order == 'type') {
			return strcmp($a['filetype'], $b['filetype']);
		} else {
			return strcmp($a['filename'], $b['filename']);
		}
	}
}

/**
 * 判断有无具体操作的权限  返回值为权限类型
 * @author JianXin dev team
 * @param $m 对应的模块名 小写
 * @param $a 对应的方法名
 * @return string
 */
function getCheckUrlByAction($m, $a){
	switch (strtolower($a)) {
		case "listdialog" : $a = 'index'; break;
		case "radiolistdialog" : $a = 'index'; break;
		case "checklistdialog" : $a = 'index'; break;
		case "changedialog" : $a = 'index'; break;
		case "adddialog" : $a = 'add'; break;
		case "cares" :  $a = 'index'; break;
		case "excelimportdownload" : $a = 'excelimport'; break;
		case "selectexcelexport" : $a = 'excelexport'; break;
		case "receive" : $a = 'add'; break;
		case "search" : $a = 'index'; break;
		case "role_add" : $a = 'add';break;
		case "remove" : $a = 'edit';break;
		case "changecontent" : $a = 'index';break;
		case "advance" : $a = 'edit';break;
		case "close" : $a = 'edit';break;
		case "revert" : $a = 'delete';break;
		case "getcustomerlist" : $a = 'index';break;
		case "fenpei" : $a = 'add';break;
		case "changetofirstcontact" : $a = 'edit'; break;
		case "addcategory" :
		case "editcategory" :
			if(strtolower($m) == 'supplier'){
				$a = 'category';
			}
			break;
		case "revokecheck" : $a = 'check'; break;
		default: $a = strtolower($a); break;
	}
	return strtolower($m.'/'.$a);
}

/**
 * 判断有无具体操作的权限  返回值为权限类型
 * @author JianXin dev team
 * @param $m 对应的模块名 小写
 * @param $a 对应的方法名
 * @return int
 */
function checkPerByAction($m, $a){
	$m_permission = M('permission');
	$url = getCheckUrlByAction($m, $a);
	if(session('?admin') ){
		//2为所有人
		return 2;
	}elseif($per = $m_permission->where('url = "%s" and position_id = %d', $url, session('position_id'))->find()){
		//有$url操作权限；
		return $per['type'];
	}else{
		//无$url操作权限；
		return 0;
	}
}

/**
 * @author JianXin dev team
 * @param $m 对应的模块名 小写
 * @param $a 对应的方法名
 * @param bool $sub_role  true:下属role_id 范围,false权限内的role_id 范围
 * @return array
 */
function getPerByAction($m, $a, $sub_role=false){
	$m_permission = M('permission');
	$url = getCheckUrlByAction($m, $a);

	$per_type =  M('Permission') -> where('position_id = %d and url = "%s"', session('position_id'), $url)->getField('type');
	if($sub_role){
		if($per_type == 3){
			$below_ids = array();
		}elseif($per_type == 4){
			$departmen_role_ids = array();
			$role_ids = getRoleByDepartmentId(session('department_id'), true);
			foreach($role_ids as $v){
				$departmen_role_ids[] = $v['role_id'];
			}
			$temp_below_ids = getSubRoleId(false);
			$below_ids = array_intersect($departmen_role_ids, $temp_below_ids);
		}else{
			$below_ids = getSubRoleId(false);
		}
		if(empty($below_ids))
			return array(-1);
		else
			return $below_ids;
	}else{
		//管理员拥有所有人的数据权限
		if(session('?admin')) return getSubRoleId(true, 1);
		$role_array = array();
		switch($per_type){
			//权限类型为1 包含自己和下属的数据 返回自己和下属role_id数组
			case 1: $role_array = getSubRoleId(); break;
			//权限类型为2 返回false 不加判断条件即所有人都有的权限。
			case 2: $role_array = getSubRoleId(true, 1); break;
			//权限类型为3 仅自己的数据 返回数组 返回仅包含自己role_id的数组
			case 3: $role_array = array(session('role_id')); break;
			//默认 部门所有人
			case 4:
				$role_ids = getRoleByDepartmentId(session('department_id'), true);
				foreach($role_ids as $v){
					$role_array[] = $v['role_id'];
				}
				break;
		}
		return $role_array;
	}
}

/**
 * 根据操作权限获取roleid
 * @author JianXin dev team
 * @param $per_array $per_array为包含操作的数组 array('leads/add', 'customer/add')
 * @return array|bool
 */
function getRoleByPer($per_array){
	if($per_array){
		$where['url'] = array('in', $per_array);
		if($position_ids = M('Permission') -> where($where)->getField('position_id', true)){
			$role_ids_array = D('RoleView')->where('role.position_id in(%s)', implode(',', $position_ids))->getField('role_id', true);
			return array_unique($role_ids_array);
		}else{
			return false;
		}
	}else{
		return false;
	}
}

/**
 * 根据当前处理程序判断顶部菜单按钮项
 * @author JianXin dev team
 * @param $module_name 为模块名
 * @param $action_name 为方法名
 * @return string 返回顶部的数组
 */
function setSelectedMenu($module_name, $action_name){
	$module_name = strtolower($module_name);
	$action_name = strtolower($action_name);
	if($action_name == 'analytics'){
		return 'menu_analy';
	}
	switch($module_name){
		case 'leads':
		case 'customer':
			return 'menu_customer';
		case 'business':
		case 'contract':
		case 'quote':
			return 'menu_business';
		case 'product':
		case 'contract':
			return 'menu_stock';
		case 'finance':
			return 'menu_finance';
		case 'log':
		case 'event':
		case 'user':
		case 'examine':
		case 'announcement':
			return 'menu_office';
		case 'actionlog':
		case 'setting':
			return 'menu_setting';
		case 'message':
			return 'menu_home';
		default : return 'index';
	}
}

/**
 * @author JianXin dev team
 * @param $category_id
 * @param int $first
 * @return string
 */
function getSubCategoryTreeCode($category_id, $first=0) {
	$string = "";
	$department_list = M('ProductCategory')->where('parent_id = %d', $category_id)->select();
	if ($department_list) {
		if ($first) {
			$string = '<ul id="browser" class="filetree"><li style="list-style-type: none;" class="collapsable"><span rel="0" class="folder ta">全部 &nbsp; <span class="" id="0"> </span></span></li>';
		} else {
			$string = "<ul>";
		}
		foreach($department_list AS $value) {
			if($first){
				$string .= "<li style='list-style-type: none;'><span rel='".$value['category_id']."' class='folder ta'>".$value['name']." &nbsp; <span class='' id='".$value['category_id']."'> </span></span>".getSubCategoryTreeCode($value['category_id'])."</li>";
			} else {
				$string .= "<li style='list-style-type: none;'><span rel='".$value['category_id']."' class='file ta'>".$value['name']." &nbsp; <span class='' id='".$value['category_id']."'> </span></span>".getSubCategoryTreeCode($value['category_id'])."</li>";
			}
		}
		$string .= "</ul>";
	}
	return $string;
}

/**
 * 截取字符长度，如果超过字符长度，后面追加...
 * @author JianXin dev team
 * @param string $str 要截取的字符串
 * @param string $len 要截取的长度
 * @return bool|string
 */
function cutString($str='', $len='15'){
	if(empty($str) || empty($len)) return false;
	$pre_content = strip_tags($str);
	$pre_content_len = mb_strlen($pre_content,'utf-8');
	if($pre_content_len <= $len){
		return $pre_content;
	}else{
		$pre_content = mb_substr($pre_content,0,$len,'utf-8');
		return $pre_content.' . . .';
	}
}

/**
 * 在AuthenticateBehavior中判断是否AJAX请求，如果是AJAx请求且在弹窗页没有权限，直接显示无权限
 * @author JianXin dev team
 * @return bool
 */
function isAjaxRequest() {
	if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) ) {
		if('xmlhttprequest' == strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])){
			return true;
		}
	}
	if(!empty($_POST[C('VAR_AJAX_SUBMIT')]) || !empty($_GET[C('VAR_AJAX_SUBMIT')])){
		// 判断Ajax方式提交
		return true;
	}
	return false;
}

/**
 * 读取标签
 * @author JianXin dev team
 * @param $limit 显示条数。如果没有limit，默认读取所有标签并以热度排序。如果有limit，读取限制条数的标签，并以热度排序
 * @return mixed
 */
function getTags($limit){
	$m_tags = M('tags');
	$m_customer_data = M('CustomerData');
	$where['tags'] = array('neq',',');
	$tags_ids = $m_customer_data ->where($where)->getField('tags',true);
	$tags_all_Str = '';
	foreach($tags_ids as $v){
		$tags_arr = array_filter(explode(',',$v));
		if($tags_arr){
			$tags_str = implode(',',$tags_arr);
		}
		$tags_all_Str .= ','.$tags_str;
	}
	$tags_all_arr = array_flip(array_flip(explode(',',$tags_all_Str)));
	$tag['tags_id'] = array('in',$tags_all_arr);
	if(!empty($limit)){
		$tags = $m_tags->where($tag)->limit($limit)->order('hits desc')->select();
	}else{
		$tags = $m_tags->where($tag)->order('hits desc')->select();
	}
	return $tags;
}


/**
 * @author JianXin dev team
 * @param string $string
 * @param string $url
 */
function redirects($string="", $url=""){
	if($string == ""){
		if($url == ""){
			die("<meta charset='utf-8'><Script charset='UTF-8'  Language='JavaScript'>history.back(-1);</Script>");
		}else{
			die("<meta charset='utf-8'><Script charset='UTF-8'  Language='JavaScript'>window.location.href='".$url."';</Script>");
		}
	}else{
		if($url == ""){
			die("<meta charset='utf-8'><Script charset='UTF-8' Language='JavaScript'>alert('".$string."');history.back(-1);</Script>");
		}else{
			die("<meta charset='utf-8'><Script charset='UTF-8' Language='JavaScript'>alert('".$string."');window.location.href='".$url."';</Script>");
		}
	}
}

/**
 * 自定义字段验重
 * @author JianXin dev team
 * @param $model 需要查询的模块名
 * @param $field 字段名
 * @param $val 值
 * @param $id 排除当前数据验重
 * @return bool
 */
function validate($model, $field, $val, $id) {
	if(!$field || !$val){
		return false;
	}
	$field_info = M('Fields')->where('model = "%s" and field = "%s"',$model,$field)->find();
	if($model == 'contacts'){
		$m_fields = $field_info['is_main'] ? D('contacts') : D('ContactsData');
	}elseif($model == 'customer'){
		$m_fields = $field['is_main'] ? D('Customer') : D('CustomerData');
	}elseif($model == 'product'){
		$m_fields = $field['is_main'] ? D('Product') : D('ProductData');
	}elseif($model == 'leads'){
		$m_fields = $field['is_main'] ? D('Leads') : D('LeadsData');
	}elseif($model == 'contract'){
		$m_fields = $field['is_main'] ? D('Contract') : D('ContractData');
	}elseif($model == 'business'){
		$m_fields = $field['is_main'] ? D('Business') : D('BusinessData');
	}elseif($model == 'examine'){
		$m_fields = $field['is_main'] ? D('Examine') : D('ExamineData');
	}
	$where[$field] = array('eq',$val);
	if($id){
		$where[$m_fields->getpk()] = array('neq',$id);
	}
	if($field){
		if ($m_fields->where($where)->find()) {
			return true;
		} else {
			return false;
		}
	}else{
		return false;
	}
}

/**
 * APP列表添加权限判断接口
 * @author JianXin dev team
 * @param $m
 * @param $a
 * @return array
 */
function apppermission($m, $a){
	if(session('?admin')){
		$permission = array();
		$permission['add'] = 1;
		return $permission;
	}else{
		$m_permission = M('Permission');
		$where['url'] = array('like','%'.$m.'%');
		$where['position_id'] = session('position_id');
		$permission_list = $m_permission->where($where)->select();
		$permission['add'] = 0;
		foreach($permission_list as $k=>$v){
			$permission_info = explode('/',$v['url']);
			if($permission_info[1] == 'add' || ($m == 'Finance' && $permission_info[1] == 'add_'.$a)){
				$permission['add'] = 1;
				break;
			}
		}
		return $permission;
	}
}

/**
 * @author JianXin dev team
 * @param $m
 * @param $role_id
 * @param $type
 * @return array
 */
function permissionlist($m, $role_id, $type){
	if(session('?admin')){
		$permission = array();
		$permission['edit'] = 1;
		$permission['view'] = 1;
		$permission['delete'] = 1;
		return $permission;
	}else{
		if($role_id){
			if ($m == 'Finance') {
				$list = array('view_'.$type,'edit_'.$type,'delete_'.$type);
			} elseif ($m == 'log') {
				$list = array('mylog_view','mylog_edit','log_delete');
			} else {
				$list = array('view','edit','delete');
			}
			$permission = array();
			foreach($list as $k=>$v){
				$all_ids = getPerByAction($m,$v);
				if($v == 'view' || $v == 'view_'.$type || $v == 'mylog_view'){
					if(in_array($role_id, $all_ids)){
						$permission['view'] = 1;
					}
				}elseif($v == 'edit' || $v == 'edit_'.$type || $v == 'mylog_edit'){
					if(in_array($role_id, $all_ids)){
						$permission['edit'] = 1;
					}
				}elseif($v == 'delete' || $v == 'delete_'.$type || $v == 'log_delete'){
					if(in_array($role_id, $all_ids)){
						$permission['delete'] = 1;
					}
				}
			}
		}else{
			//如果没有负责人，则只给看权限
			$permission = array('view'=>1);
		}
		// return (object)$permission;
		return $permission;
	}
}

/**
 * 非role_id权限判断接口(手机端)
 * @author JianXin dev team
 * @param $m
 * @return array|object
 */
function getpermission($m){
	if(session('?admin')){
		$permission = array();
		$permission['edit'] = 1;
		$permission['view'] = 1;
		$permission['delete'] = 1;
		return $permission;
	}else{
		$m_permission = M('Permission');
		$where['url'] = array('like','%'.$m.'%');
		$where['position_id'] = session('position_id');
		$permission_list = $m_permission->where($where)->select();
		$permission = array();
		foreach($permission_list as $k=>$v){
			$permission_info = explode('/',$v['url']);
			if(in_array($permission_info[1], array('edit','view','delete'))){
				$permission[$permission_info[1]] = 1;
			}
		}
		return (object)$permission;
	}
}

/**
 * @author JianXin dev team
 * @param $data
 * @return bool
 */
function doRecord($data){

	if(!$data || !is_array($data)){
		return false;
	}
	//判断cookie类里面是否有浏览记录
	if(cookie('history')){
		$history = unserialize(cookie('history'));
		array_unshift($history, $data); //在浏览记录顶部加入
		/* 去除重复记录 */
		$rows = array();
		foreach ($history as $v){
			if(in_array($v, $rows)){
				continue;
			}
			$rows[] = $v;
		}
		/* 如果记录数量多余5则去除 */
		while (count($rows) > 10){
		  array_pop($rows); //弹出
		}
		cookie('history', serialize($rows),time()+3600*24*30);
	}else{
		$history = serialize(array($data));
		cookie('history', $history,time()+3600*24*30);
	}
}

/**
 * 产品树
 * @author JianXin dev team
 * @param $category_id
 * @param int $first
 * @return string
 */
function getProductTreeCode($category_id, $first=0) {
	$string = "";
	$category_list = M('ProductCategory')->where('parent_id = %d', $category_id)->select();
	if ($category_list) {
		if ($first) {
			$string = '<ul>';
			//$string .= "<li class='jstree-open'><a href = ".U('product/index').">全部</a></li>";
		} else {
			$string = "<ul>";
		}
		foreach($category_list AS $value) {
			$class = '';
			if($_GET['category_id'] == $value['category_id']){
				$class = 'jstree-clicked';
			}
			$string .= "<li class='jstree-open' rel='".$value['category_id']."'><a class='".$class."' href = ".U('product/index','category_id='.$value['category_id']).">".$value['name']."</a>".getProductTreeCode($value['category_id'],0)."</li>";
		}
		$string .= "</ul>";
	}
	return $string;
}

/**
 * 获取产品分类
 * @author JianXin dev team
 * @param $category_id
 * @param $categories
 * @param $selected_category_id
 * @return array
 */
function getCategoryNodes($category_id, $categories, $selected_category_id) {
	$m_product_category = M('ProductCategory');
	$array = array();
	foreach($categories AS $value) {
		if ($category_id == $value['parent_id']) {
			$son_category = array();
			if($m_product_category->where('parent_id = %d', $category_id)->count() > 0){
				//如果有子分类
				$son_category = getCategoryNodes($value['category_id'], $categories, $selected_category_id);
			}

			$selected = array('selected'=>false);
			if($value['category_id'] == $selected_category_id){
				$selected = array('selected'=>true);
			}
			$array[] = array('id' => $value['category_id'], 'text' => $value['name'],'first' => $first,'state'=>$selected,'children'=>$son_category);
		}
	}
	return $array;
}

/**
 * 获取该部门最高岗位
 * @author JianXin dev team
 * @param $department_id
 * @return mixed
 */
function firstDepartment($department_id){
	$dep = M('RoleDepartment')->where('department_id = %d', $department_id)->find();
	$pos = M('position')->where('department_id = %d', $department_id)->count();
	$positions = M('position')->where('department_id = %d', $dep['department_id'])->select();
	$position_ids = M('position')->where('department_id = %d', $dep['department_id'])->getField('position_id',true);
	foreach($positions as $k=>$v){
		if(!in_array($v['parent_id'],$position_ids)){
			$first_position_id = $v['position_id'];
			break;
		}
	}
	return $first_position_id;
}

/**
 * 二维数组排序
 * @author JianXin dev team
 * @param array $select 要进行排序的select结果集
 * @param $field 排序的字段
 * @param int $order 排序方式1降序2升序
 * @return array
 */
function sort_select($select=array(), $field, $order=1){
	$count = count($select);
	if($order == 1){
		for ($i=0; $i < $count; $i++) {
			$k = $i;
			for ($j=$i; $j < $count; $j++) { 
				if ($select[$k][$field] < $select[$j][$field]) {
					$k = $j;
				}
			}
			$temp = $select[$i];
			$select[$i] = $select[$k];
			$select[$k] = $temp;
		}
		return $select;
	}else{
		for ($i=0; $i < $count; $i++) {
			$k = $i;
			for ($j=$i; $j < $count; $j++) { 
				if ($select[$k][$field] > $select[$j][$field]) {
					$k = $j;
				}
			}
			$temp = $select[$i];
			$select[$i] = $select[$k];
			$select[$k] = $temp;
		}
		return $select;
	}
}

/**
 * 根据时间戳获取星期几
 * @author JianXin dev team
 * @param $time 要转换的时间戳
 * @param int $i
 * @return string
 */
function getTimeWeek($time, $i = 0) {
	$weekarray = array("日", "一", "二", "三", "四", "五", "六");
	$oneD = 24 * 60 * 60;
	return "星期" . $weekarray[date("w", $time + $oneD * $i)];
}

/**
 * 查询上级部门中的最高岗位
 * @author JianXin dev team
 * @param $department_id
 * @return mixed
 */
function getTopPositionByDepartment($department_id){
	$m_position = M('Position');
	$top_position_id = $m_position->where(array('department_id'=>$department_id))->order('parent_id asc')->getField('position_id');
	if(!empty($top_position_id)){
		$parent_id = M('RoleDepartment')->where('department_id = %d',$department_id)->getField('parent_id');
		if(empty($parent_id)){
			$top_position_id = getTopPositionByDepartment($parent_id);
		}
	}
	return $top_position_id;
}

/**
 * 将秒数转换为时间（年、天、小时、分、秒）
 * @author JianXin dev team
 * @param $time
 * @return bool|string
 */
function getTimeBySec($time){
    if(is_numeric($time)){
	    $value = array(
	      "years" => 0, "days" => 0, "hours" => 0,
	      "minutes" => 0, "seconds" => 0,
	    );
	    if($time >= 31556926){
			$value["years"] = floor($time/31556926);
			$time = ($time%31556926);
			$t .= $value["years"] ."年";
	    }
	    if($time >= 86400){
			$value["days"] = floor($time/86400);
			$time = ($time%86400);
			$t .= $value["days"] ."天";
	    }
	    if($time >= 3600){
			$value["hours"] = floor($time/3600);
			$time = ($time%3600);
			$t .= $value["hours"] ."小时";
	    }
	    if($time >= 60){
			$value["minutes"] = floor($time/60);
			$time = ($time%60);
			$t .= $value["minutes"] ."分钟";
	    }
	    if ($time < 60) {
	    	$value["seconds"] = floor($time);
	    	$t .= $value["seconds"] ."秒";
	    }
    	Return $t;
    }else{
   		return (bool) FALSE;
    }
}

/**
 * 根据月份计算天数
 * @author JianXin dev team
 * @param $year_month
 * @return string
 */
function getmonthdays($year_month){
 	$month = date('m',$year_month);
 	$year = date('Y',$year_month);
    $allMonth = array('1', '3', '5', '7', '8', '01', '03', '05', '07', '08', '10', '12');
 	if (in_array($month, $allMonth)){
        $days = '31';
	}elseif($month == 2){
        if ($year % 400 == 0 || ($year % 4 == 0 && $year % 100 !== 0)){//判断是否是闰年
            $days = '29';
        }else{
            $days = '28';
        }
    }else{
        $days = '30';
    }
    return $days;
}

/**
 * 生成从开始日期到结束日期的日期数组
 * @author JianXin dev team
 * @param $start
 * @param $end
 * @return array|string
 */
function dateList($start,$end){

	if(!is_numeric($start) || !is_numeric($end) || ($end<=$start)) return '';
	$i = 0;
	//从开始日期到结束日期的每日时间戳数组
	$d = array();
	while($start <= $end){
		$d[$i] = $start;
		$start = $start+86400;
		$i++;
	}
	$list = array();
	foreach($d as $k=>$v){
		$list[$k] = getDateRange($v);
	}
	return $list;
}

/**
 * 获取指定日期开始时间与结束时间
 * @author JianXin dev team
 * @param $timestamp
 * @return array
 */
function getDateRange($timestamp){
	$ret = array();
	$ret['sdate'] = strtotime(date('Y-m-d',$timestamp));
	$ret['edate'] = strtotime(date('Y-m-d',$timestamp))+86400;
	return $ret;
}

/**
 * 人民币转大写
 * @author JianXin dev team
 * @param $ns
 * @return mixed
 */
function cny($ns){
	static $cnums = array("零","壹","贰","叁","肆","伍","陆","柒","捌","玖"), 
	$cnyunits = array("圆","角","分"), 
	$grees = array("拾","佰","仟","万","拾","佰","仟","亿"); 
	list($ns1,$ns2) = explode(".",$ns,2); 
	$ns2 = array_filter(array($ns2[1],$ns2[0])); 
	$ret = array_merge($ns2,array(implode("", _cny_map_unit(str_split($ns1), $grees)), "")); 
	$ret = implode("",array_reverse(_cny_map_unit($ret,$cnyunits))); 
	return str_replace(array_keys($cnums), $cnums,$ret); 
}

/**
 * @author JianXin dev team
 * @param $list
 * @param $units
 * @return array
 */
function _cny_map_unit($list, $units) {
	$ul = count($units); 
	$xs = array(); 
	foreach (array_reverse($list) as $x) { 
		$l = count($xs); 
		if($x!="0" || !($l%4)) {
			$n=($x=='0'?'':$x).($units[($l-1)%$ul]); 
		}else{
			$n=is_numeric($xs[0][0]) ? $x : ''; 
		}
		array_unshift($xs, $n); 
	} 
	return $xs; 
}

/**
 * 将时间戳转化为日期
 * @author JianXin dev team
 * @param $time
 * @return string|void
 */
function newTimeDate($time) {
	if ($time > 0) {
		$d = new DateTime('@'.$time);
	    $d->setTimezone(new DateTimeZone('PRC'));
	    return $d->format('Y-m-d');
	} else {
		return;
	}
}

/**
 * 将年月日转化为一个时间戳
 * @author JianXin dev team
 * @param $date
 * @return string
 */
function newDateTime($date) {
	$d = new DateTime($date);
    return $d->format('U');
}

/**
 * 其他相关数据，写入日程
 * @author JianXin dev team
 * @param $subject
 * @param $start_date
 * @param $module
 * @param $module_id
 * @return mixed
 */
function dataEvent($subject, $start_date, $module, $module_id) {
 	$m_event = M('Event');

 	$data = array();
 	$data['start_date'] = $start_date;
 	$data['end_date'] = strtotime(date('Y-m-d',$start_date))+86399;
 	$data['module'] = $module;
 	$data['module_id'] = $module_id;
 	$data['subject'] = $subject;
 	
 	switch ($module) {
 		case 'leads' : $color = '#57c7d4'; break;
 		case 'contract' : $color = '#f96868'; break;
 		case 'customer' : $color = '#f2a654'; break;
 		default : $color = '#62a8ea'; break;
 	}
 	$data['color'] = $color;
 	//编辑
 	$event_id = $m_event->where(array('module'=>$module,'module_id'=>$module_id,'owner_role_id'=>session('role_id')))->getField('event_id');
 	if ($event_id && $module && $module_id) {
 		$data['update_date'] = time();
		$m_event->where('event_id = %d',$event_id)->save($data);
		return $event_id; 
 	} else {
 		$data['owner_role_id'] = session('role_id');
	 	$data['creator_role_id'] = session('role_id');
	 	$data['create_date'] = time();
	 	$data['update_date'] = time();
 		return $m_event->add($data);
 	}
}

/**
 * 检查该字段若必填，加上"*"
 * @author JianXin dev team
 * @param $is_validate 是否验证 1是  2否
 * @param $is_null 是否为空 0否  1是
 * @param $name 字段名称
 * @return string
 */
function sign_required($is_validate, $is_null, $name){
	if($is_validate == 1 && $is_null == 1){
		return '*'.$name;
	} else {
		return $name;
	}
}

/**
 * 增加详情操作记录
 * @author JianXin dev team
 * @param $type 操作类型
 * @param $duixiang 操作内容
 * @param $model_name 模块名称
 * @param $action_id 操作主键ID
 * @return bool
 */
function add_record($type, $duixiang, $model_name, $action_id){
	$m_action_record = M('action_record');
	$arr['create_time'] = time();
	$arr['create_role_id'] = session('role_id');
	$arr['type'] = $type;
	$arr['duixiang'] = $duixiang;
	$arr['model_name'] = $model_name;
	$arr['action_id'] = $action_id;
	$result = $m_action_record ->add($arr);
	if($result){
		return true;
	}else{
		return false;
	}
}

/**
 * @author JianXin dev team
 * @param $arr
 * @param $id
 * @return array
 */
function findChild (&$arr, $id) {
	$childs=array();
	foreach ($arr as $k => $v){
		if ($v['parent_id']== $id) {
			$childs[]=$v;
		}
	}
	return $childs;
}

/**
 * @author JianXin dev team
 * @param $rows
 * @param $root_id
 * @return array|null
 */
function build_tree ($rows, $root_id) {
	$childs = findChild($rows,$root_id);
	if (empty($childs)) {
		return null;
	}
	foreach ($childs as $k => $v){
		$rescurTree = build_tree($rows,$v['id']);
		if (null != $rescurTree) {
			$childs[$k]['childs'] = $rescurTree;
		}
	}
	return $childs;
}

/**
 * 在日程数据中追加，周期性提醒内容
 * @author JianXin dev team
 * @param $start_time
 * @param $end_time
 * @return array
 */
function cycel_event($start_time,$end_time){
	$list = array();
	$cycel_list = M('Cycel')->where(array('create_role_id'=>session('role_id'),'start_time'=>array('elt',$end_time),'end_time'=>array('egt',$start_time)))->select();
	$date_list = dateList($start_time,$end_time);
	foreach ($cycel_list as $k=>$v) {
		$array_day = array();
		$array_week = array();
		$array_month = array();
		$array_year = array();
		//type 1周 2月 3年 4仅一次
		if ($v['type'] == 1) {
			$array_week[] = '星期'.$v['num'];
		} elseif ($v['type'] == 2) {
			$array_month[] = $v['num'];
		} elseif ($v['type'] == 3) {
			$array_month[] = $v['num'];
		} else {
			$array_day[] = strtotime(date('Y-m-d',$v['num']));
		}
		foreach ($date_list as $key=>$val) {
			$week_name = '';
			$week_name = getTimeWeek($val['sdate']); //星期

			$month_name = '';
			$month_name = date('d',$val['sdate']);

			$year_name = '';
			$year_name = date('m-d',$val['sdate']);
			if ((in_array($week_name,$array_week) || in_array($month_name,$array_month) || in_array($year_name,$array_year) || in_array($val['sdate'],$array_day)) && $v['start_time'] <= $val['sdate']) {
				//追加数据
				$list[] = array(
							'event_id'=>$v['module'],
							'start_date'=>$val['sdate'],
							'end_date'=>$val['edate'],
							'color'=>'#f96868',
							'module'=>$v['module'],
							'module_id'=>$v['module_id']
							);
			}
		}
	}
	return $list;
}

/**
 * 递归查询签约合同(暂不用，有问题)
 * @author JianXin dev team
 * @param $contract_id
 * @param $ids
 * @param $is_first
 * @return array
 */
function contract_history($contract_id,$ids,$is_first){
	$array = array();
	$where = array();
	$m_contract = M('Contract');
	if ($ids) {
		$str_ids = implode(',',$ids);
		$where['_string'] = '`contract_id` = '.$contract_id.' AND `contract_id` NOT IN ('.$str_ids.')';
		$where['renew_contract_id'] = $contract_id;
		$where['_logic'] = 'or';
	} else {
		$where['contract_id'] = $contract_id;
		$where['renew_contract_id'] = $contract_id;
		$where['_logic'] = 'or';
	}
	$contract_list = $m_contract->where($where)->field('contract_id,renew_contract_id')->select();

	foreach ($contract_list as $k=>$v) {
		if (!in_array($v['contract_id'],$ids)) {
			$ids[] = $v['contract_id'];
			$array[] = $v['contract_id'];
		}
		if ($v['renew_contract_id'] && (!in_array($v['renew_contract_id'],$ids) || $is_first == 1)) {
			$array = array_merge($array,contract_history($v['renew_contract_id'],$ids));
		}
	}
	return $array;
}

/**
 * 算两个经纬度之间的距离
 * @author JianXin dev team
 * @param $lat1
 * @param $lng1
 * @param $lat2
 * @param $lng2
 * @return float
 */
function getDistance($lat1, $lng1, $lat2, $lng2){
     $earthRadius = 6367000; // approximate radius of earth in meters
 
     /*
       Convert these degrees to radians
       to work with the formula
     */
 
     $lat1 = ($lat1 * pi() ) / 180;
     $lng1 = ($lng1 * pi() ) / 180;
 
     $lat2 = ($lat2 * pi() ) / 180;
     $lng2 = ($lng2 * pi() ) / 180;
 
     $calcLongitude = $lng2 - $lng1;
     $calcLatitude = $lat2 - $lat1;
     $stepOne = pow(sin($calcLatitude / 2), 2) + cos($lat1) * cos($lat2) * pow(sin($calcLongitude / 2), 2);  $stepTwo = 2 * asin(min(1, sqrt($stepOne)));
     $calculatedDistance = $earthRadius * $stepTwo;
 
     return round($calculatedDistance);
}

/**
 * BD-09(百度)坐标转换成GCJ-02(火星，高德)坐标
 * @author JianXin dev team
 * @param $bd_lon 百度经度
 * @param $bd_lat 百度纬度
 * @return mixed
 */
function bd_decrypt($bd_lon, $bd_lat){
	$data['gg_lon'] = round($bd_lon, 6);
	$data['gg_lat'] = round($bd_lat, 6);
	return $data;
	// 换回百度
	$x_pi = 3.14159265358979324 * 3000.0 / 180.0;
	$x = $bd_lon - 0.0065;
	$y = $bd_lat - 0.006;
	$z = sqrt($x * $x + $y * $y) - 0.00002 * sin($y * $x_pi);
	$theta = atan2($y, $x) - 0.000003 * cos($x * $x_pi);
	// $data['gg_lon'] = $z * cos($theta);
		// $data['gg_lat'] = $z * sin($theta);
	$gg_lon = $z * cos($theta);
	$gg_lat = $z * sin($theta);
    // 保留小数点后六位
	$data['gg_lon'] = round($gg_lon, 6);
	$data['gg_lat'] = round($gg_lat, 6);
	return $data;
}

/**
 * GCJ-02(火星，高德)坐标转换成BD-09(百度)坐标
 * @author JianXin dev team
 * @param $gg_lon 百度经度
 * @param $gg_lat 百度纬度
 * @return mixed
 */
function bd_encrypt($gg_lon, $gg_lat){
    $data['bd_lon'] = round($gg_lon, 6);
    $data['bd_lat'] = round($gg_lat, 6);
    $x_pi = 3.14159265358979324 * 3000.0 / 180.0;
    $x = $gg_lon;
    $y = $gg_lat;
    $z = sqrt($x * $x + $y * $y) - 0.00002 * sin($y * $x_pi);
    $theta = atan2($y, $x) - 0.000003 * cos($x * $x_pi);
    $bd_lon = $z * cos($theta) + 0.0065;
    $bd_lat = $z * sin($theta) + 0.006;
    // 保留小数点后六位
    $data['bd_lon'] = round($bd_lon, 6);
    $data['bd_lat'] = round($bd_lat, 6);
    return $data;
}

/**
 * 字节转换
 * @author JianXin dev team
 * @param $size
 * @return string
 */
function formatBytes($size) { 
	$units = array(' B', ' KB', ' MB', ' GB', ' TB'); 
	for ($i = 0; $size >= 1024 && $i < 4; $i++) $size /= 1024; 
	return round($size, 2).$units[$i]; 
}

/**
 * 输出pdf
 * @author JianXin dev team
 * @param string $content 文档内容
 * @param string $aspect 打印方向，默认 y 纵向，x横向
 * @param bool $download 是否下载
 * @param $pdfname
 */
function pdf($content = '', $aspect = 'y', $download = false, $pdfname){
	$aspect_arr = array('y' => 'A4', 'x' => 'S4');
	$aspect = $aspect_arr[$aspect];
    import("@.ORG.mpdf.mpdf", '', '.php');
    // 实例化对象 中文编码 横/纵向排版 默认字体大小 默认字体 左页边距 右页边距 上页边距 下页边距
    $mpdf = new mPDF('utf-8', $aspect, '', '', 10, 10, 10, 10); 
	$mpdf->autoScriptToLang = true;
	$mpdf->autoLangToFont = true;
    $mpdf->WriteHTML($content);
    if ($download) {
    	if ($pdfname != '') $pdfname = $pdfname.'.pdf';
	    $mpdf->Output($pdfname, true);
	    $mpdf->Output($pdfname, 'd');
    }
    $mpdf->Output();
    exit;
}

/**
 * 打印  dump die;
 * @author JianXin dev team
 * @param	mixed	需要打印的对象，如果是继承Model类的对象会打印最后的sql
 */
function dd()
{
	call_user_func_array('ddd', func_get_args());
	die(1);
}

/**
 * 打印  dump
 * @author JianXin dev team
 * @param	mixed	需要打印的对象，如果是继承Model类的对象会打印最后的sql
 */
function ddd()
{
	// 引入y_dump
	$composer = import('@.ORG.Composer.vendor.autoload', '', '.php');
	// 打印函数
	$dump_func = $composer && function_exists('y_dump') ? 'y_dump' : 'dump';
	header('Content-Disposition: ');		// 文件名
	header("Content-type:text/html; charset=utf-8");
	// 调用位置
	$files = debug_backtrace();
	$file = $files[0];
	if ($files[1]['function'] == 'call_user_func_array') {
		$file = $files[2];
	}
	echo '<p style="font-size: 14px; color: #3D80DA">' . $file['file'] . ':' .$file['line'].'行' . '</p>';
	foreach (func_get_args() as $key => $val) {
		if ($val instanceof Model) {
			sqlFormat($val->getlastsql());
		} else {
			$dump_func($val);
		}
	}
}

/**
 * 接口打印
 * @author JianXin dev team
 */
function vdd()
{
	header('Content-Type:application/json; charset=utf-8');
	$param = func_get_args();
	$arr = array();
	foreach ($param as $val) {
		if ($val instanceof Model) {
			$arr[] = $val->getlastsql();
		} else {
			$arr[] = $val;
		}
	}
	$file = debug_backtrace();
	$file_info = pathinfo($file[0]['file']);
	array_push($arr, $file_info['basename'] . ':' .$file[0]['line'].'行');
	echo json_encode($arr);
	die(1);
}

/**
 * 调试方法
 * @author JianXin dev team
 * @param $data
 * @param bool $offset
 */
function p($data, $offset=true){
	// $trace = (new \Exception())->getTrace()[0];
	$obj = new \Exception();
	$trace = $obj->getTrace();
	$trace = $trace[0];
	echo $trace['file'] . '：' . $trace['line'].'行';
	echo '<pre><meta charset="utf-8">';
	print_r($data);
	//dump($data);
	echo '</pre>';

	if($offset){
		die;
	}
}

/**
 * 模拟GET请求
 * @author JianXin dev team
 * @param $url
 * @return mixed
 */
function curl_get($url){
	//初始化
    $ch = curl_init();
    //设置抓取的url
    curl_setopt($ch, CURLOPT_URL, $url);

    //设置获取的信息以文件流的形式返回，而不是直接输出。
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // https请求 不验证证书
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); // https请求 不验证hosts 

    //执行命令
    $output = curl_exec($ch);

	curl_close($ch); //释放curl句柄

	return $output; 
}

/**
* curl 模拟POST请求
* @author JianXin dev team
***/
function curl_post($url,$post_data=array()){
	$post_data = json_encode($post_data);
	//初始化
    $curl = curl_init();
    //设置抓取的url
    curl_setopt($curl, CURLOPT_URL, $url);
    //设置头文件的信息作为数据流输出
    //curl_setopt($curl, CURLOPT_HEADER, 1);
    //设置获取的信息以文件流的形式返回，而不是直接输出。
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    //设置post方式提交
    curl_setopt($curl, CURLOPT_POST, 1);
    //设置post数据
    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);

    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
	    'Content-Type: application/json',
	    'Content-Length: ' . strlen($post_data)
	));

    //执行命令
    $data = curl_exec($curl);

    //关闭URL请求
    curl_close($curl);
    return $data;
}

/**
* 地址转地理坐标
* @author JianXin dev team
**/
function get_lng_lat($address){
	$map_ak = 'grWGxlWOpGc1D0kVToxUgD6bwwjo35Tr';
	$url = "http://api.map.baidu.com/geocoder/v2/?address=$address&output=json&ak=$map_ak&callback=showLocation";

	$ret_script = curl_get($url);
	preg_match_all("/\{.*?\}}/is", $ret_script, $matches);
	$ret_arr = json_decode($matches[0][0],true);
	if ($ret_arr['status'] == 0) { //成功
		$location['lng'] = $ret_arr['result']['location']['lng'];
		$location['lat'] = $ret_arr['result']['location']['lat'];
		return $location;
	} else {
		return false;
	}
}

/**
* 根据经纬度点和半径，计算经纬度范围
* @param lng 经度 lat 纬度  半径raidus 单位米
* return minLat,minLng,maxLat,maxLng
* @author JianXin dev team
*/
function get_around($lng,$lat,$raidus){	
	$PI = 3.14159265;

	$latitude = $lat;
	$longitude = $lng;

	$degree = (24901*1609)/360.0;
	$raidusMile = $raidus;

	$dpmLat = 1 / $degree;
	$radiusLat = $dpmLat*$raidusMile;
	$minLat = $latitude - $radiusLat;
	$maxLat = $latitude + $radiusLat;

	$mpdLng = $degree*cos($latitude * ($PI/180));
	$dpmLng = 1 / $mpdLng;
	$radiusLng = $dpmLng*$raidusMile;
	$minLng = $longitude - $radiusLng;
	$maxLng = $longitude + $radiusLng;

	$data['min_lng'] = $minLng;
	$data['max_lng'] = $maxLng;
	$data['min_lat'] = $minLat;
	$data['max_lat'] = $maxLat;
	return $data;
}

/**
* 过滤post\get数据html
* @param 
* @author 
*/
function removehtml($str){
	if (!is_array($str)) {
		$str = str_replace("<br>","",$str);
		$str = strip_tags($str);
	} else {
		foreach ($str as $key=>$val) {
			$str[$key] = removehtml($val);
		}
	}
    return $str;
}

/**
 * 二维数组取一列   PHP5.5+ 支持
 * 
 * @param	array	$array		二维数组
 * @param	mixed	$field  	要取的字段
 * @param	mixed	$index_key	取一列作键
 * @return	mixed	$res		成功返回Array，失败返回False
 */
function y_array_column($array,  $field = '', $index_key = null)
{
	if (!is_array($array)) return false;
	$res = array();
	foreach ($array as $arr) {
		if (!is_array($arr)) return false;
		if (is_null($field)) {
			$value = $arr;
		} else {
			$value = $arr[$field];
		}
		if (is_null($index_key)) {
			$res[] = $value;
		} else {
			$key = $arr[$index_key];
			$res[$key] = $value;
		}
	}
	return $res;
}

/**
 * 数据执行修改时，判断数据是否变化
 */
function checkDataDifficult($new_data, $old_data)
{
	foreach ($new_data as $key => $val) {
		if ($val != $old_data[$key]) return true;
	}
	return false;
}

/**
 * html自定义属性
 * 使用场景：方便父页面获取弹窗列表的属性值
 * @author JianXin dev team
 */
function custom_attr($data){
	foreach($data as $k => $v){
		if ($data[$k]) {
			$custom_attr .= $k.'="'.$v.'"';
		}
	}
	return $custom_attr;
}

/**
 * 时间插件
 * @author JianXin dev team
 */
function daterange(){
	//时间插件处理（计算开始、结束时间距今天的天数）
	$daterange = array();
	$daterange[0]['title'] = '上月';
	$daterange[1]['title'] = '本月';
	$daterange[2]['title'] = '上季度';
	$daterange[3]['title'] = '本季度';
	$daterange[4]['title'] = '上一年';
	$daterange[5]['title'] = '本年';
	//上个月
	$daterange[0]['start_day'] = (strtotime(date('Y-m-d',time()))-strtotime(date('Y-m-d', mktime(0,0,0,date('m')-1,1,date('Y')))))/86400;
	$daterange[0]['end_day'] = (strtotime(date('Y-m-d',time()))-strtotime(date('Y-m-01 00:00:00')))/86400 + 1;
	//本月
	$daterange[1]['start_day'] = (strtotime(date('Y-m-d',time()))-strtotime(date('Y-m-01 00:00:00')))/86400;
	$daterange[1]['end_day'] = 0;
	//上季度
	$month = date('m');
	if($month==1 || $month==2 ||$month==3){
		$year = date('Y')-1;
		$daterange_start_time = strtotime(date($year.'-10-01 00:00:00'));
		$daterange_end_time = strtotime(date($year.'-12-31 23:59:59'));
	}elseif($month==4 || $month==5 ||$month==6){
		$daterange_start_time = strtotime(date('Y-01-01 00:00:00'));
		$daterange_end_time = strtotime(date("Y-03-31 23:59:59"));
	}elseif($month==7 || $month==8 ||$month==9){
		$daterange_start_time = strtotime(date('Y-04-01 00:00:00'));
		$daterange_end_time = strtotime(date("Y-06-30 23:59:59"));
	}else{
		$daterange_start_time = strtotime(date('Y-07-01 00:00:00'));
		$daterange_end_time = strtotime(date("Y-09-30 23:59:59"));
	}
	$daterange[2]['start_day'] = (strtotime(date('Y-m-d',time()))-$daterange_start_time)/86400;
	$daterange[2]['end_day'] = (strtotime(date('Y-m-d',time()))-$daterange_end_time-1)/86400 + 1;
	//本季度
	$month=date('m');
	if($month==1 || $month==2 ||$month==3){
		$daterange_start_time = strtotime(date('Y-01-01 00:00:00'));
		$daterange_end_time = strtotime(date("Y-03-31 23:59:59"));
	}elseif($month==4 || $month==5 ||$month==6){
		$daterange_start_time = strtotime(date('Y-04-01 00:00:00'));
		$daterange_end_time = strtotime(date("Y-06-30 23:59:59"));
	}elseif($month==7 || $month==8 ||$month==9){
		$daterange_start_time = strtotime(date('Y-07-01 00:00:00'));
		$daterange_end_time = strtotime(date("Y-09-30 23:59:59"));
	}else{
		$daterange_start_time = strtotime(date('Y-10-01 00:00:00'));
		$daterange_end_time = strtotime(date("Y-12-31 23:59:59"));
	}
	$daterange[3]['start_day'] = (strtotime(date('Y-m-d',time()))-$daterange_start_time)/86400;
	$daterange[3]['end_day'] = 0;
	//上一年
	$year = date('Y')-1;
	$daterange_start_time = strtotime(date($year.'-01-01 00:00:00'));
	$daterange_end_time = strtotime(date('Y-01-01 00:00:00'));
	$daterange[4]['start_day'] = (strtotime(date('Y-m-d',time()))-$daterange_start_time)/86400;
	$daterange[4]['end_day'] = (strtotime(date('Y-m-d',time()))-$daterange_end_time)/86400 + 1;
	//本年度
	$daterange_start_time = strtotime(date('Y-01-01 00:00:00'));
	$daterange[5]['start_day'] = (strtotime(date('Y-m-d',time()))-$daterange_start_time)/86400;
	$daterange[5]['end_day'] = 0;
	return $daterange;
}

/**
 * dialog弹窗，无权操作提示
 * @param
 */
function dialogAlert($msg){
	if (IS_AJAX) {
		if (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') !== false) {
			//$.load
			echo '<div class="alert alert-error">'.$msg.'</div>';
			die();
		} else if (strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false){
			//json
			header('Content-Type:application/json; charset=utf-8');
			exit(json_encode(array('info' => $msg, 'msg' => $msg, 'status' => -1)));
		}
	} else {
		alert('error', $msg, $_SERVER['HTTP_REFERER']);
	}
}





/**
 * 接口请求时，获取完整的服务器路径
 */
function getServerName()
{
	// 获取项目目录，如果没有把'\'替换为空
	$dirname = str_replace('\\','',dirname($_SERVER['SCRIPT_NAME']));
	// is_ssl()是tp的函数在functions.php中
	return (is_ssl()?'https://':'http://').$_SERVER['HTTP_HOST'].$dirname;
}


/**
 * 文件路径处理
 * not_head 默认false 头像，ture 非头像文件
 */
function headPathHandle($file, $not_head = false)
{
	$server_name = getServerName();
	$d_file = D('File');
	if ($file != '') {
        if (!empty($_REQUEST['token'])) {
            // 手机端
            return $server_name . $file;
        } else {
            return $file;
        }
	} else {
		if ($not_head) {
			return '';
		}
		if (!empty($_REQUEST['token'])) {
			// 手机端，需要完整图片地址
			return $server_name . '/Public/img/avatar_default.png';
		} else {
		    if (isAjaxRequest()) {
		        if (C('TMPL_PARSE_STRING.__PUBLIC__')) {
                    return C('TMPL_PARSE_STRING.__PUBLIC__').'/img/avatar_default.png';
                } else {
                    return __ROOT__.'/Public/img/avatar_default.png';
                }
            }
			return '__PUBLIC__/img/avatar_default.png';
		}
	}
	return '';
}


/**
 * 添加操作记录【目前仅支持信息"编辑"时】
 * @author JianXin dev team
 */
function recordAction($new_data, $old_data, $model, $id)
{
	$m_customer = M('Customer');
	$m_contacts = M('Contacts');
	$m_business = M('Business');
	$m_user = M('User');

	if ($model == 'setting') {
		$field_list = D('Setting')->configField();
	} else {
		$custom_field_list = M('Fields')->where('model = "'.$model.'"')->field('field,name,form_type')->order('order_id')->select();
		foreach ($custom_field_list as $k => $v) {
			$field_list[$v['field']] = $v;
		}
	}

	// 合同特殊字段追加
	if ($model == 'contract') {
		$field_list['owner_role_id'] = array('field' => 'owner_role_id', 'name' => '合同签约人', 'form_type' => 'role');
	}

	$diff_data = array_diff_assoc($new_data, $old_data);
// p($field_list,'');
// p($diff_data);
	foreach ($diff_data as $k => $v) {
		$field_info = $field_list[$k];
		if ($field_info) {
			if ($field_info['form_type'] == 'datetime') {
                if ($old_data[$k] == $v) {
                    continue;
                }
				$old_value = $old_data[$k] ? date('Y-m-d', $old_data[$k]) : '';
				$new_value = $v ? date('Y-m-d', $v) : '';
			} elseif ($field_info['form_type'] == 'role') {
				$old_value = $m_user->where('role_id = %d', $old_data[$k])->getField('full_name');
				$new_value = $m_user->where('role_id = %d', $v)->getField('full_name');
			} elseif ($field_info['field'] == 'customer_id') {
				$old_value = $m_customer->where('customer_id = %d', $old_data[$k])->getField('name');
				$new_value = $m_customer->where('customer_id = %d', $v)->getField('name');
			} elseif ($field_info['field'] == 'contacts_id') {
				$old_value = $m_contacts->where('contacts_id = %d', $old_data[$k])->getField('name');
				$new_value = $m_contacts->where('contacts_id = %d', $v)->getField('name');
			} elseif ($field_info['field'] == 'business_id') {
				$old_value = $m_business->where('business_id = %d', $old_data[$k])->getField('code');
				$new_value = $m_business->where('business_id = %d', $v)->getField('code');
			} else {
				$old_value = $old_data[$k];
				$new_value = $v;
			}
			$action_record .= '<div>将 '.$field_info['name'].' 由 <span style="color:#77B0E9">"'.$old_value.'"</span> 修改为 <span style="color:#E7AE6F">"'.$new_value.'"</span> </div>';
		}
	}
	$record['create_time'] = time();
	$record['create_role_id'] = session('role_id');
	$record['type'] = '修改';
	$record['duixiang'] = $action_record;
	$record['model_name'] = $model;
	$record['action_id'] = $id;
	M('ActionRecord')->add($record);
}


/**
 * 查询操作记录
 * @author JianXin dev team
 */
function actionRecord($action_id, $model_name)
{
	$m_action_record = M('ActionRecord');
	$m_user = M('User');

	$r_where['action_id'] = $action_id;
	$r_where['model_name'] = $model_name;
	$group_time = $m_action_record->where($r_where)->group('create_time')->order('id desc')->getField('create_time',true);
	foreach($group_time as $k=>$v){ //转换为时间戳
		$group_date[] = date('Y-m-d',$v);
	}
	$group_date = array_flip(array_flip($group_date));
	$group_list = array();
	foreach($group_date as $key=>$val){
		$start_time = strtotime($val);
		$end_time = strtotime($val)+86399;
		$t_where['create_time'] = array('between',array($start_time,$end_time));
		$t_where['action_id'] = $action_id;
		$t_where['model_name'] = $model_name;
		$action_list = $m_action_record->where($t_where)->order('id desc')->select();
		$group_list[$key]['week_name'] = getTimeWeek(strtotime($val));
		$group_list[$key]['create_date'] = date('m-d',strtotime($val));
		foreach($action_list as $k=>$v){
			$create_role_info = $m_user->where('role_id = %d',$v['create_role_id'])->field('role_id,full_name,thumb_path')->find();
			$create_role_info['thumb_path'] = headPathHandle($create_role_info['thumb_path']);
			$action_list[$k]['create_role_info'] = $create_role_info; //获取修改人信息
			switch($v['type']){
				case '修改' : $i_class = 'fa fa-square-o'; $color_class = 'ai-yellow'; break;
				case '放入客户池' : $i_class = 'fa fa-archive'; $color_class = 'ai-red'; break;
				case '客户分享' : $i_class = 'fa fa-user'; $color_class = 'ai-green'; break;
				case '取消分享' : $i_class = 'fa fa-user'; $color_class = 'ai-red'; break;
				case '提醒' : $i_class = 'fa fa-eye'; $color_class = 'ai-purple'; break;
				case '移除' : $i_class = 'fa fa-eye'; $color_class = 'ai-red'; break;
				case '分配' : $i_class = 'fa fa-check-square'; $color_class = 'ai-green'; break;
				case '领取' : $i_class = 'fa fa-square-o'; $color_class = 'ai-red'; break;
				case '客户转移' : $i_class = 'fa fa-share-square-o'; $color_class = 'ai-orange'; break;
			}
			$action_list[$k]['i_class'] = $i_class;
			$action_list[$k]['color_class'] = $color_class;
		}
		$group_list[$key]['action_list'] = $action_list;
	}
	return $group_list;
}




/**
 * 导出SCV
 * @param	string		$file		文件名
 * @param	array		$head		表头 二维数组 如果指定字段的话
 * @param	int			$count		数据总条数
 * @param	Closure 	$callback	匿名函数，查询需要导出的数据
 * @author JianXin dev team
 */
function csvExport(string $file, array $table_head, int $count, Closure $callback)
{
	// 示例
	if (false) {
		$m_test = M('Test');
		$count = $m_test->count();
		$t_head = array(
			array('jxcrm导出数据'),
			// 键名可不指定,导出所有字段,指定键名则导出指定字段
			// 多维数组用 . 分隔  如果字段名内含有 . ,在匿名函数内进行处理完
			'field' => array('name' => '姓名', 'age' => '年龄', 'sex' => '性别')
		);
		csvExport('file_name', $t_head, $count, function($page) use ($m_test) {
			return $m_test->Page($page)->select();
		});
	}
	
	ini_set('memory_limit', '128M');		// 内存上限
    set_time_limit(0);		//执行超时时间
	header('Content-type: text/csv; charset=UTF-8');
	header('Content-Disposition: attachment;filename="' . $file . '.csv"');		// 文件名
	header('Cache-Control: max-age=0');		// 禁用缓存

	header('Expires: 0');
	header('Cache-control: private');
	header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	header('Content-Description: File Transfer');
	header('Content-Encoding: UTF-8');
	echo "\xEF\xBB\xBF"; 	// UTF-8 BOM

	// global $fp;
	$fp = fopen('php://output', 'a');	//直接输出到浏览器  
	foreach ($table_head as $v) {
		fputcsv($fp, $v);
	}
	$page_size = 10000;
	for ($i = 1; $i <= ceil($count / $page_size); $i++) {
		$data = $callback($i . ',' . $page_size);	// 传入page 分页参数
		foreach ($data as $val) {
			$row = array();
			if (isset($table_head['field'])) {
				foreach ($table_head['field'] as $k => $v) {
					$fields = explode('.', $k);
					if (count($fields) > 1) {
						$temp = $val;
						foreach ($fields as $field) {
							$temp = $temp[$field];
						}
					} else {
						$temp = $val[$fields[0]];
					}
					// if (is_numeric($temp)) {
					// 	$temp = ' ' . $temp;
					// }
					$row[$v] = $temp . "\t";
				}
			} else {
				foreach ($val as $v) {
					// if (is_numeric($temp)) {
					// 	$temp = ' ' . $temp;
					// }
					$row[$v] = $temp . "\t";
				}
			}
			fputcsv($fp, $row);
		}
		unset($data);
		ob_flush();
		flush();
	}
	exit();
}


/**
 * 格式化sql语句
 */
function sqlFormat($sql)
{
	if (import('@.ORG.SqlFormatter', '', '.php')) {
		$dump_func = function_exists('y_dump') ? 'y_dump' : 'dump';
		echo '<div style="padding: 0 20px; border: 1px solid #ccc; border-radius:20px;">' . SqlFormatter::format($sql) . '</div>';
		$dump_func(M()->query($sql));
	} else {
		echo '<div>' . $sql . '</div>';
	}
}


/**
 * 读取csv数据
 */
function csvRead($file = '', $start_line = 0, $end_line = 10, $fields = array(), $callback = null)
{
	setlocale('zh_CN', 'GB2312'); // 中文
    $file = fopen($file,"r");
	ini_set('memory_limit','256M');
    set_time_limit (0);
	$i = $c = 0;
	$data = array();
	$f_count = count($fields);
	$max = 1000;
	while ($line = fgetcsv($file)) { //每次读取CSV里面的一行内容
		$i++;
		if ($i < $start_line) continue;
		if ($i > $end_line && $end_line != 0) break;
		if ($f_count >= $l_count = count($line)) {
			$line = array_pad($line, $f_count, '');		
		}
		$tmp = array();
		foreach ($line as $key => $val) {
			$tmp[$fields[$key]] = iconv('GB2312', 'utf-8', $val);
		}
		$data[] = $tmp;
		if ($callback !== null) {
			if (count($data) > ($c + 1) * $max) {
				$callback(array_slice($data, $c * $max, $max));
				$c++;
			}
		}
	}
	if ($callback !== null) {
		$callback(array_slice($data, $c * $max, $max));
	}
	fclose($file);
	return $data;
}


/**
 * 读取excel数据
 * @param	string		$file
 * @param	int			$start_line		开始行数（包含）
 * @param	int			$end_line		结束行数（包含） 0 表示所有行
 * @param	array		$fields			字段 必填 同列数一致 必须索引数组
 * @param	callback	$callback		回调
 * @param	int			$max			回调函数执行周期
 */
function excelRead($file = '', $start_line = 0, $end_line = 0, $fields = array(), $callback = null, $max = 100)
{
	ini_set('memory_limit','128M');
    set_time_limit (0);
	$fields = array_values($fields);
	$fields_count = count($fields);
	import("ORG.PHPExcel.PHPExcel");
	$PHPExcel = new PHPExcel();
	$PHPReader = new PHPExcel_Reader_Excel2007();
	if(!$PHPReader->canRead($file)){
		$PHPReader = new PHPExcel_Reader_Excel5();
	}
	$PHPExcel = $PHPReader->load($file);
	$currentSheet = $PHPExcel->getSheet(0);
	$allRow = $currentSheet->getHighestRow();
	$data = array();
	if ($end_line == 0) {
		$max_row = $allRow;
	} else {
		$max_row = $end_line > $allRow ? $allRow : $end_line;
	}
	$c = 0;		// 回调函数执行次数
	for ($row = $start_line; $row <= $max_row; $row++) {
		$line = array();
		$null_count = 0;
		foreach ($fields as $k => $v) {
			$col = PHPExcel_Cell::stringFromColumnIndex($k);
			if (null === $temp_val = $currentSheet->getCell($col.$row)->getValue()) {
				$temp_val = '';
				$null_count++;
			}
			$line[$v] = $temp_val;
		}
		if ($null_count == $fields_count) {
			break;
		}
		$data[$row] = $line;
		if ($callback !== null) {
			if (count($data) > ($c + 1) * $max) {
				$callback(array_slice($data, $c * $max, $max, true));
				$c++;
			}
		}
	}
	if ($callback !== null) {
		$callback(array_slice($data, $c * $max, $max, true));
	}
	return $data;
}


/**
 * 内存占用
 * @param	int			$before		使用前占用内存	单位 bit
 * @param	string		$unit		单位 bit,B,K,M,G
 */
function ramUsage($before = null, $unit = '')
{
	if ($before === null) {
		$before = memory_get_usage();
	}
	$ram = memory_get_usage() - $before;
	switch (strtoupper($unit)) {
		case 'BIT':
			return number_format($ram, 2) . 'bit';
			break;
		case 'B':
			return number_format($ram / 8, 2) . 'B';
			break;
		case 'K':
			return number_format($ram / (1024 * 8), 2) . 'K';
			break;
		case 'M':
			return number_format($ram / (pow(1024, 2) * 8), 2) . 'M';
			break;
		case 'G':
			return number_format($ram / (pow(1024, 3) * 8), 2) . 'G';
			break;
		default :
			if ($ram < 8) {
				return number_format($ram, 2) . 'bit';
			} elseif (($ram / 8) < 1024) {
				return number_format($ram / 8, 2) . 'B';
			} elseif (($ram / (1024 * 8)) < 1024) {
				return number_format($ram / (1024 * 8), 2) . 'K';
			} elseif (($ram / (pow(1024, 2) * 8)) < 1024) {
				return number_format($ram / (pow(1024, 2) * 8), 2) . 'M';
			} else{
				return number_format($ram / (pow(1024, 3) * 8), 2) . 'G';
			}
			break;
	}
}

/**
 * 性能测试
 * @param 	callback	$callback	需要测试的函数
 * @param	int			$lop		执行次数
 */
function test($callback = null, $loop = 1)
{
	$s_ram = memory_get_usage();
	$s_time = microtime(true);

	if ($callback !== null) {
		for ($i = 0; $i < $loop; $i++) {
			$callback();
		}
	}

	return array(
		'time' => number_format(microtime(true) - $s_time, 4) . 's',
		'ram' => ramUsage('', $s_ram)
	);
}


/**
 * 导出csv
 * @param $file_name 导出文件名称
 * @param $field_list 导出字段列表 ['create_time' => ['name' => '创建时间', 'form_type' => 'date']]
 * @param $total_export_count 前台设置的单次导出总行数
 * @param Closure $callback 匿名函数，查询需要导出的数据
 * @author JianXin dev team
 **/
function exportCsv($file_name, $field_list, $total_export_count, $already_export_count, Closure $callback)
{
	ini_set('memory_limit','128M');
    set_time_limit (0);

    //调试时，先把下面这个两个header注释即可
    header("Content-type:application/vnd.ms-excel");  
	header("Content-Disposition:filename=" . $file_name . ".csv");

	header('Expires: 0');
	header('Cache-Control: private, must-revalidate, post-check=0, pre-check=0');
	header('Content-Description: File Export');
	header('Content-Encoding: UTF-8');
	// 加上bom头，防止用office打开时乱码
	echo "\xEF\xBB\xBF"; 	// UTF-8 BOM

	// 打开PHP文件句柄，php://output 表示直接输出到浏览器  
	$fp = fopen('php://output', 'a');

	// 将中文标题转换编码，否则乱码  
	foreach ($field_list as $i => $v) {    
	    $title_cell[$i] = $v['name'];    
	}
	// 将标题名称通过fputcsv写到文件句柄    
	fputcsv($fp, $title_cell);

	// 后台设置每次导出条数【后台在前台设置的单次导出条数基础上再次分段导出】
	$each_count = 1000;
	// 计算后台需要导出次数【等于1说明前台设置的每次导出条数小于后台的设置的1000，那么后台单次导出条数按前台的数量导出】
	$export_times = ceil($total_export_count / $each_count);
	if ($export_times == 1) {
		$each_count = $total_export_count;
	}
	for ($i = 0; $i < $export_times; $i++){
		$limit_start = $i * $each_count + $already_export_count;
	    $export_data = $callback($limit_start.','.$each_count);
	    foreach ($export_data as $item) {
	    	$rows = array(); 
	    	foreach ($field_list as $filed_name => $rule) {
	    		$rows[] = formatValue($item[$filed_name], $rule['form_type']);
	    	}
	        fputcsv($fp, $rows);
	    }
	    // 将已经写到csv中的数据存储变量销毁，释放内存占用  
		// $m = memory_get_usage();
		unset($export_data);
        ob_flush();
        flush();
	}
	fclose($fp);
	session('do_export', 1);
	exit();
}

/**
 * 根据form_type处理数据
 * "\t" 间隔字符，解决导出的时间格式变成####和防止数字变成科学计数法
 * @author JianXin dev team
 */
function formatValue($val, $form_type)
{
	if ($form_type == 'datetime') {
		$val = $val > 0 ? date('Y-m-d H:i:s', $val)."\t" : '';
	} elseif ($form_type == 'date'){
		$val = $val > 0 ? date('Y-m-d', $val)."\t" : '';
	} elseif ($form_type == 'address'){
		$val = implode('', explode(chr(10), $val));
	} elseif ($form_type == 'role'){
		$val = M('User')->where('role_id = %d', $val)->getField('full_name');
	} elseif ($form_type == 'mobile'){
		$val = "{$val}\t";
	}
	return $val;
}


/**
 * 判断数组是否是另一个数组的子集
 * @param	array	子集
 * @param	array	父集
 */
function is_subset($sub, $arr)
{
	$res = array_diff($sub, $arr);
	return empty($res);
}


/**
 * 根据url获取部门
 * @param	string	$m	模块
 * @param	string	$a	方法
 */
function getDepartmentByUrl($m = MODULE_NAME, $a = ACTION_NAME)
{
	$url = getCheckUrlByAction($m, $a);
	$per_type =  M('Permission') -> where('position_id = %d and url = "%s"', session('position_id'), $url)->getField('type');
	if($per_type == 2 || session('?admin')){
		$where = '';
	}else{
		$where = array('department_id' => session('department_id'));
	}
	return (array) M('RoleDepartment')->where($where)->select();
}


/**
 * highmaps插件，省份名称和标识的对应
 * @author JianXin dev team
 */
function mapProvince()
{
	return array(
		'cn-sh' => '上海',
		'cn-zj' => '浙江',
		'cn-gs' => '甘肃',
		'cn-nx' => '宁夏',
		'cn-sa' => '陕西',
		'cn-ah' => '安徽',
		'cn-hu' => '湖北',
		'cn-gd' => '广东',
		'cn-fj' => '福建',
		'cn-bj' => '北京',
		'cn-hb' => '河北',
		'cn-sd' => '山东',
		'cn-tj' => '天津',
		'cn-js' => '江苏',
		'cn-ha' => '海南',
		'cn-qh' => '青海',
		'cn-jl' => '吉林',
		'cn-xz' => '西藏',
		'cn-xj' => '新疆',
		'cn-he' => '河南',
		'cn-nm' => '内蒙', // 古
		'cn-hl' => '黑龙', // 江
		'cn-yn' => '云南',
		'cn-gx' => '广西',
		'cn-ln' => '辽宁',
		'cn-sc' => '四川',
		'cn-cq' => '重庆',
		'cn-gz' => '贵州',
		'cn-hn' => '湖南',
		'cn-sx' => '山西',
		'cn-jx' => '江西',
		'tw-tw' => '台湾',
		'cn-6668' => '香港',
		'cn-3681' => '澳门',
		'cn-3664' => '南沙', // 群岛
	);
}


/**
 * 统计计算增长率
 * @param $val 本次值
 * @param $contrast_val 对比值
 * @author JianXin dev team
 */
function growthRate($val, $contrast_val)
{
	if (empty($contrast_val)) {
		return '-';
	} else {
		$rate = round(($val - $contrast_val) / $contrast_val, 4) * 100;
		if ($rate > 0) {
			$rate_str = "{$rate}%".'<i class="fa fa-long-arrow-up" style="font-size: 16px;color: green;"></i>';
		} else if ($rate == 0){
			$rate_str = "{$rate}%";
		} else if ($rate < 0){
			$rate_str = "{$rate}%".'<i class="fa fa-long-arrow-down" style="font-size: 16px;color: red;"></i>';
		}
		return $rate_str;
	}
}


/**
 * 时间范围插件
 * @param	int		$start_date		开始时间	时间戳
 * @param	int		$end_date		结束时间	时间戳
 * @param	string	$value			input框默认值
 * @return	string	$data			JSON 字符串
 */
function dateRangePicker($start_date = null, $end_date = null, $value = null)
{
	$start_date = $start_date === null ? date('Y-m-01') : date('Y-m-d', $start_date);
	$end_date = $end_date === null ? date('Y-m-d') : date('Y-m-d', $end_date);
	$value = $value ?: $start_date .' - ' . $end_date;
	$date = daterange();	// ***
	$data = '{value: "'. $value .'", start_date: "'. $start_date .'", end_date: "'. $end_date .'","ranges":{';
	// $data .= "'今日' : [moment().startOf('day'), moment()],";
	// $data .= "'昨日' : [moment().subtract('days', 1).startOf('day'), moment().subtract('days', 1).endOf('day')],";
	foreach ($date as $val) {
		$data .=  $val['title'] ." : [moment().subtract('days', ". $val['start_day'] ."), moment().subtract('days', ". $val['end_day'] .")],";
	}
	$data .= '}}';
	return $data;
}


/**
 * 判断用户浏览器(内核)类型
 * @author JianXin dev team
 */
function browserType()
{
	$http_user_agent = $_SERVER['HTTP_USER_AGENT'];
	if (strpos($http_user_agent, 'Chrome')) {
		return 'chrome'; // 谷歌
	} else if (strpos($http_user_agent, 'Firefox')){
		return 'firefox'; // 火狐
	} else if (strpos($http_user_agent, 'Trident')){
		return 'ie'; // IE
	}
}

/**
 * 加密算法
 * @author JianXin dev team
 * @param $data
 * @param $key
 * @return string
 */
function encrypt($data, $key)
{
    $key    =    md5($key);
    $x      =    0;
    $len    =    strlen($data);
    $l      =    strlen($key);
    for ($i = 0; $i < $len; $i++){
        if ($x == $l) {
            $x = 0;
        }
        $char .= $key{$x};
        $x++;
    }
    for ($i = 0; $i < $len; $i++){
        $str .= chr(ord($data{$i}) + (ord($char{$i})) % 256);
    }
    return base64_encode($str);
}

/**
 * 解密算法
 * @author JianXin dev team
 * @param $data
 * @param $key
 * @return string
 */
function decrypt($data, $key)
{
    $key = md5($key);
    $x = 0;
    $data = base64_decode($data);
    $len = strlen($data);
    $l = strlen($key);
    for ($i = 0; $i < $len; $i++){
        if ($x == $l) {
            $x = 0;
        }
        $char .= substr($key, $x, 1);
        $x++;
     }
    for ($i = 0; $i < $len; $i++){
        if (ord(substr($data, $i, 1)) < ord(substr($char, $i, 1))){
            $str .= chr((ord(substr($data, $i, 1)) + 256) - ord(substr($char, $i, 1)));
        } else {
            $str .= chr(ord(substr($data, $i, 1)) - ord(substr($char, $i, 1)));
        }
    }
    return $str;
}

/**
 * 去获取字段名称
 */
function getFieldName($model)
{
    return M('fields')->where(array('model' => $model))->order('order_id asc')->getField('field,name');
}


