<?php
return array(
    'VERSION'=>'2.0',
    'RELEASE'=>'20200701',
    'AUTHORIZE_VERSION' => '免费开源版',
    'AUTHORIZE_INFO' => '永久免费',
);