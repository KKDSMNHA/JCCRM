<?php 

 define ('APP_DEBUG', true);