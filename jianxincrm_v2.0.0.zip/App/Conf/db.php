<?php
return array(
'DB_TYPE'=>'mysqli',
'DB_HOST'=>'localhost',
'DB_PORT'=>'3306',
'DB_NAME'=>'',
'DB_USER'=>'',
'DB_PWD'=>'',
'DB_PREFIX'=>'',
);