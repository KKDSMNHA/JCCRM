<?php
	return array(
	'THE MAIN CONTENTS ARE AS FOLLOWS'=>'%s主要内容如下:%s%s',
	'THE MAIN CONTENT'=>'主要评论内容:%s',
	);