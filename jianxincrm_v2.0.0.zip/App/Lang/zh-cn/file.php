<?php
return array(
	'ADD_FAILURE_PARTS_ACCESSORIES'=>'部分附件添加失败',
	'ADD_ATTACHMENTS_FAIL'=>'添加附件失败',
	'ADD_ATTACHMENTS_SUCCESS'=>'添加附件成功！',
	'PARAMETER_ERROR'=>'参数错误',
	'YOU_HAVE_NO_RIGHT_TO_DELETE_THE_ATTACHMENT'=>'您无权删除此附件！',
	'OPERATION_IS_SUCCESSFUL'=>'操作成功！',
	'FILE_NO_MORE_THAN_20MB'=>'文件总大小不能超过20MB',	
	'ALLOWED_FILE_TYPES'	   =>	'允许类型：',
	'ADD_AN_ATTACHMENT'	   =>	'增加一个附件',
	'ILLEGAL_OPERATION'	   =>	'非法操作！',


);

