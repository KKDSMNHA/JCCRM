<?php 

class AppBehavior extends Behavior {
	protected $options = array();
	
	public function run(&$params) {
		// 重新定义多层控制器[TP框架下的Base/Common/common.php中的A方法有对应改动]
		if (defined('APP_TYPE')) {
			if (APP_TYPE == 'Vue') {
				// 手机端多版本情况
				if ($_GET['v']) {
					$layer = APP_TYPE.'/v'.trim($_GET['v']);
				} else {
					$layer = APP_TYPE.'/v11'; // 手机端起始最小版本
				}
			} else {
				$layer = APP_TYPE;
			}
			C('DEFAULT_C_LAYER', $layer);
		}

        // 已安装但没有登录时
        if (!session('role_id') && $this->_isInstall() === true) {
            return;
        }

        // 原CRM系统中自己定义的一个类，作用是过滤一些标签和请求参数等
        import('@.ORG.Scan');

        if ($this->_isInstall() === true) {
            if (session('role_id')) {
                $m_config = M('Config');
                $smtp = $m_config->where('name = "smtp"')->getField('value');
                C('smtp', unserialize($smtp));

                $defaultinfo = $m_config->where('name = "defaultinfo"')->getField('value');
                $defaultinfo = unserialize($defaultinfo);
                C('defaultinfo', $defaultinfo);

            }
        } else {
            if (strtolower(MODULE_NAME) != 'install') {
                redirect(U('install/index'));
            }
        }
	}


	/**
	 * 判断系统是否已安装
	 * @author JianXin dev team
	 */
	private function _isInstall()
	{
		if (file_exists(CONF_PATH.'install.lock')) {
			return true;
		} else {
			return false;
		}
	}

}