<?php 

class AuthenticateBehavior extends Behavior {
	protected $options = array();
	
	public function run(&$params) {
		$m = MODULE_NAME;
		$a = ACTION_NAME;
		$allow = $params['allow'];
		$permission = $params['permission'];
		
		if (session('?admin')) {
			return true;
		}
		if (in_array($a, $permission)) {
			return true;
		} elseif (session('?position_id') && session('?role_id')) {
			if (in_array($a, $allow)) {
				return true;
			} else {
				if($m == 'Finance' && $a !== 'check' && $a != 'revokeCheck'){
					$a = $a.'_'.trim($_REQUEST['t']);
				}
				if($a == 'view_ajax'){
					$a = 'view';
				}
				if(!checkPerByAction($m, $a)){
					if(isAjaxRequest()){
						if($a == 'delete' || $a == 'log_delete' || $a == 'delete_'.trim($_REQUEST['t'])){
							header('Content-Type:application/json; charset=utf-8');
							$error_data['data'] = '';
							$error_data['info'] = '您没有此权利！';
							$error_data['status'] = 0;
                			exit(json_encode($error_data));
						}else{
							echo '<div class="alert alert-error">您没有此权利！</div>';die();
						}
					}else{
						$url = empty($_SERVER['HTTP_REFERER']) ? U('index/index') : $_SERVER['HTTP_REFERER'];
						alert('error', '您没有此权利!', $url);
					}
				}else{
					return true;
				}
			}
		} elseif(!session('?role_id')) {
			if(isAjaxRequest()){
				// $last_url = $_SERVER['HTTP_REFERER'];
				// cookie('last_url', $last_url);
				echo "<script>window.location.reload();</script>";
			}else{
				// $last_url = U($m.'/'.$a);
				// cookie('last_url', $last_url);
				alert('error',  '请先登录...', U('user/login'));
			}
		}
	}
}