<?php

class AnalyticsModel extends Model
{
    public $module_list = array(
        1 => '客户',
        2 => '客户、跟进记录',
        3 => '客户、联系人',
        4 => '客户、商机',
        5 => '客户、商机、产品',
        6 => '客户、合同',
        7 => '客户、合同、产品',
        8 => '客户、回款单'
    );

    
    public $msg = '';

    
}
