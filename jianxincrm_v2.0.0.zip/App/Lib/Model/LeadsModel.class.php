<?php 
    class LeadsModel extends Model{
        protected $_validate = array();
		
		protected function _validationFieldItem($data,$val) {
			switch(strtolower(trim($val[4]))) {
				case 'function':// 使用函数进行验证
				case 'callback':// 调用方法进行验证
					$args = isset($val[6])?(array)$val[6]:array();
					if(is_string($val[0]) && strpos($val[0], ','))
						$val[0] = explode(',', $val[0]);
					if(is_array($val[0])){
						// 支持多个字段验证
						foreach($val[0] as $field)
							$_data[$field] = $data[$field];
						array_unshift($args, $_data);
					}else{
						array_unshift($args, $data[$val[0]]);
					}
					if('function'==$val[4]) {
						return call_user_func_array($val[1], $args);
					}else{
						return call_user_func_array(array(&$this, $val[1]), $args);
					}
				case 'confirm': // 验证两个字段是否相同
					return $data[$val[0]] == $data[$val[1]];
				case 'unique': // 验证某个值是否唯一
					if($data[$val[0]]){
						if(is_string($val[0]) && strpos($val[0],','))
							$val[0]  =  explode(',',$val[0]);
						$map = array();
						if(is_array($val[0])) {
							// 支持多个字段验证
							foreach ($val[0] as $field)
								$map[$field]   =  $data[$field];
						}else{
							$map[$val[0]] = $data[$val[0]];
						}
						if(!empty($data[$this->getPk()])) { // 完善编辑的时候验证唯一
							$map[$this->getPk()] = array('neq',$data[$this->getPk()]);
						}
						if($this->where($map)->find())   return false;
						return true;
					}else{
						return true;
					}
				default:  // 检查附加规则
					return $this->check($data[$val[0]],$val[1],$val[4]);
			}
		}
		
        public function _initialize(){
            $fields = M('fields')->where('(model = \'\' or model = \'leads\') and is_validate=1 and is_main=1')->select();
			foreach($fields as $field){
				$validate = array();
				if($field['is_null']){
					$validate[0] = $field['field'];
					$validate[1] = 'require';
					$validate[2] = L('NOT NULL',array($field['name']));
					$validate[3] = 0;
					$validate[4] = '';
					$validate[5] = 3;
					$this->_validate[] = $validate;
				}
				
				
				$validate[0] = $field['field'];
				$validate[1] = '';
				$validate[2] = L('FORMAT ERROR',array($field['name']));
				$validate[3] = 0;
				$validate[4] = 'regex';
				$validate[5] = 3;
				switch ($field['form_type']){
					case 'email';
						$validate[1] = '/|^(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)?$/';
						$this->_validate[] = $validate;
						break;
					case 'mobile';
						$validate[1] = '/|^1[358][0-9]{9}$/';
						$this->_validate[] = $validate;
						break;
					case 'phone';
						$validate[1] = '/|^((([0+]\d{2,3}-)?(0\d{2,3})-)?(\d{7,8})(-(\d{3,}))?)?$/';
						$this->_validate[] = $validate;
						break;
					case 'number';
						$validate[1] = '/|^\d+$/';
						$this->_validate[] = $validate;
						break;
				}
				
				if($field['is_unique']){
					$validate[0] = $field['field'];
					$validate[1] = '';
					$validate[2] = L('ALREADY EXISTS',array($field['name']));
					$validate[3] = 0;
					$validate[4] = 'unique';
					$validate[5] = 3;
					$this->_validate[] = $validate;
				}
				
			}
		}
		

        /**
	     * 搜索字段list信息
	     * @param form_type类型决定了搜索的表单类型
	     * @author JianXin dev team
	     */
	    public function search_field_list()
	    {
	    	// 自定义字段
	    	$field_list = getMainFields('leads');

			// 其他需搜索字段【负责人字段，如果是线索池需要过滤】
			if ($_GET['by'] == 'public') {
				$search_field_list = array(
					array('field' => 'create_time', 'name' => '创建时间', 'form_type' => 'date'),
					array('field' => 'update_time', 'name' => '修改时间', 'form_type' => 'date'),
				);
			} else {
				$search_field_list = array(
					array('field' => 'owner_role_id', 'name' => '负责人', 'form_type' => 'role'),
					array('field' => 'create_time', 'name' => '创建时间', 'form_type' => 'date'),
					array('field' => 'update_time', 'name' => '修改时间', 'form_type' => 'date'),
				);
			}
	    	return array_merge($field_list, $search_field_list);
	    }


		/**
		 * 返回属于线索或属于线索池的where条件，用于线索信息是联表查询的情况
		 */
		public function where_belong($belong = 'private', $table = '')
		{
        	$m_config = M('Config');
			$outdays = $m_config->where('name="leads_outdays"')->getField('value');
			return empty($outdays) ? 0 : time() - 86400*$outdays;
		}

		

		/**
		 * 不支持转移的字段
		 */
		public $not_support = array(
			'source',			// 来源
			'contacts_name',	// 联系人姓名
			'nextstep',			// 下次联系内容
			'name',				// 公司名
			'saltname',			// 尊称
			'position',			// 职位
			'email',			// 邮箱
			'mobile',			// 手机
			'nextstep_time',	// 下次联系时间
			'description',		// 备注
		);
		

		/**
		 * 需要转化的字段
		 */
		public function supportField()
		{
			$list = M('FLeadsCustomer')->select();
			$res = array('main' => array(), 'data' => array());
			$m_fields = M('Fields');
			foreach ($list as $key => $val) {
				if ($val['customer_field_id'] != 0 && $val['leads_field_id'] != 0) {
					$c = $m_fields->where(array('field_id' => $val['customer_field_id']))->field('field, is_main, name')->find();
					$l = $m_fields->where(array('field_id' => $val['leads_field_id']))->getField('field');
					if ($c && $l) {
						$tmp = array('l' => $l, 'c' => $c);
						if ($c['is_main']) {
							$res['main'][] = $tmp;
						} else {
							$res['data'][] = $tmp;
						}
					}
				}
			}
			return $res;
		}

	}
	