<?php 
class MessageModel extends Model{
    
    public $msg = '';

    /**
     * 获取某个类型的订单需要被审核的ID集合
     * @author JianXin dev team
     */
    public function getCheckedIds($type_id){
        $where['type_id'] = $type_id;
        $where['exam_status'] = array('lt', 2);
        return M('RExam')->where($where)->getField('order_id', true);
    }

    

}