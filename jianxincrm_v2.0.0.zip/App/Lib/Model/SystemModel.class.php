<?php 
class SystemModel extends Model{

	/**
	 * 根据判断设置需要打开的菜单的html id值
	 * @author JianXin dev team
	 */
	public function splicingId($module_name, $action_name, $param)
	{
		$second_str = 'index'; // 默认拼接ID值的变量
		if (($module_name == 'customer' && $action_name == 'nearby') // 附近的客户
			|| ($module_name == 'user' && $action_name == 'contacts')) {
			$second_str = $action_name;
		} else if ($action_name == 'analytics'
			|| ($module_name == 'customer' && $action_name == 'top_10')
			|| ($module_name == 'customer' && $action_name == 'new_add')
			|| ($module_name == 'contract' && $action_name == 'analysis_number')){
			$module_name = 'analytics'; // 数据分析
		} else if ($module_name == 'setting'
			|| ($module_name == 'user' && $action_name == 'department')
			|| ($module_name == 'user' && $action_name == 'index')
			|| ($module_name == 'product' && $action_name == 'category')
			|| ($module_name == 'contract' && $action_name == 'examine')
			|| ($module_name == 'exam' && $action_name == 'index')
			|| ($module_name == 'call' && $action_name == 'setting')
			|| ($module_name == 'system' && $action_name == 'psssetup')){
			$module_name = 'setting'; // 系统设置
		} elseif ($module_name == 'log' && $action_name == 'log_list') {
			$second_str = 'log_list'; // 采购退货
		}
		$menu_html_id = "{$module_name}-{$second_str}";
		if ($param) {
			$menu_html_id .= "-{$param}";
		}
		return $menu_html_id;
	}


	/**
	 * 设置左侧可显示的父级菜单栏，如果没有任何子菜单的权限，则父级菜单也不显示
	 * 举个栗子：如果没有线索、客户等权限，则整个【客户管理】都不显示
	 * @author JianXin dev team
	 */
	public function showModuleList()
	{
		// 客户管理
		if (checkPerByAction('leads','index')
			|| checkPerByAction('customer','index')
			|| checkPerByAction('contacts','index')
			|| checkPerByAction('log','log_list')) {
			$show_module_list[] = 'customer';
		}
		// 商机管理
		if (checkPerByAction('business','index')) {
			$show_module_list[] = 'business';
		}
		// 合同管理
		if (checkPerByAction('contract','index') || checkPerByAction('sales','return_index')) {
			$show_module_list[] = 'contract';
		}
		// 财务管理
		if (checkPerByAction('finance','index_receivables') 
			|| checkPerByAction('finance','index_receivingorder')
			|| checkPerByAction('finance','index_payables')
			|| checkPerByAction('finance','index_paymentorder')
			|| checkPerByAction('invoice','index')) {
			$show_module_list[] = 'finance';
		}

		// 产品管理
		if (checkPerByAction('product','index') 
			|| checkPerByAction('product_info','spec')
			) {
			$show_module_list[] = 'product';
		}
		// 数据分析
		if (checkPerByAction('leads','analytics') 
			|| checkPerByAction('customer','analytics')
			|| checkPerByAction('business','analytics')
			|| checkPerByAction('contract','analytics')
			|| checkPerByAction('finance','analytics')
			|| checkPerByAction('log','analytics')
			) {
			$show_module_list[] = 'analytics';
		}
		// 办公
		if (checkPerByAction('log','index') 
			|| checkPerByAction('examine','index')
			|| checkPerByAction('announcement','index')
			|| checkPerByAction('event','index')
			|| checkPerByAction('user','contacts')) {
			$show_module_list[] = 'office';
		}
		// 系统设置
		if (checkPerByAction('user','index')) {
			$show_module_list[] = 'setting';
		}
		return $show_module_list;
	}


	/**
	 * 客户列表默认场景url
	 * @author JianXin dev team
	 */
	public function customerUrl()
	{
		$m_scene_default = M('SceneDefault');
		$m_scene = M('Scene');
		$customer_default_scene = $m_scene_default->where(array('role_id'=>session('role_id'),'module'=>'customer'))->getField('scene_id');
		if (!$customer_default_scene) {
			$customer_default_info = $m_scene->where(array('module'=>'customer','type'=>1))->order('id asc')->find();
		} else {
			$customer_default_info = $m_scene->where(array('id'=>$customer_default_scene))->find();
		}
		if ($customer_default_info['type'] == 1) {
			$customer_url = U('customer/index','by='.$customer_default_info['by']);
		} else {
			$customer_url = U('customer/index','scene_id='.$customer_default_info['id']);
		}
		return $customer_url ?: '#';
	}


	/**
	 * 根据权限判断【数据分析】默认的url
	 * @author JianXin dev team
	 */
	public function analyticsUrl()
	{
		if (checkPerByAction('leads','analytics')) {
			$analytics_url = U('leads/analytics','content_id=1');
		} elseif (checkPerByAction('customer','analytics')){
			$analytics_url = U('customer/analytics','content_id=1');
		} elseif (checkPerByAction('business','analytics')){
			$analytics_url = U('business/analytics','content_id=1');
		} else {
			$analytics_url = U('customer/analytics','content_id=1');
		}
		return $analytics_url;
	}


	/**
	 * 根据权限判断【系统设置】默认的url
	 * @author JianXin dev team
	 */
	public function settingUrl()
	{
		if (session('?admin')) {
			$setting_url = U('setting/defaultinfo');
		} elseif (checkPerByAction('user','index')){
			$setting_url = U('user/index');
		} elseif (checkPerByAction('template','index')){
			$setting_url = U('template/index');
		} else {
			$setting_url = U('setting/defaultinfo');
		}
		return $setting_url;
	}


}
