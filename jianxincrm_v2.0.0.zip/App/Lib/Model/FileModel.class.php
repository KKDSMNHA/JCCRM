<?php

class FileModel extends Model
{
    // 返回信息
    public $msg = '';

    
    /**
     * 获取最大上传文件大小
     */
    public function getMaxSize()
    {
        $upload_max_filesize = (int) strtoupper(ini_get('upload_max_filesize'));
        return $upload_max_filesize . 'M';
    }


    /**
     * 多文件上传时，格式化$_FILES数组
     * @author JianXin dev team
     */
    public function getFileList($default_files)
    {
        foreach ($default_files as $k => $v) {
            foreach ($v as $ke => $val) {
                $file_list[$ke][$k] = $val;
            }
        }
        return $file_list;
    }

    /**
     *
     *
     */
    public function fileList($model, $id)
    {
        $model_list = array(
            'work_order' => 'RFileWorkOrder',
        );
        if (!$model_list[$model]) {
            return false;
        }
        $file_id_array = M($model_list[$model])->where(array($model.'_id' => $id))->getField('file_id',true);
        $file_list = M('File')->where('file_id in (%s)',implode(',',$file_id_array))->select();          // 附件列表
        foreach ($file_list as $key => $value) {
            $file_list[$key]['size'] = ceil($value['size']/1024);
            $file_list[$key]['pic'] = show_picture($value['name']);
        }
        return $file_list;
    }


    /**
     * 根据file_id 删除文件
     * @param mixed $file_id 数组或数字ID
     */
    public function deleteById($file_id)
    {
        if (is_array($file_id)) {
            $where = array('file_id' => array('IN', $file_id));
        } else {
            $where = array('file_id' => $file_id);
        }
        $list = $this->where($where)->field('file_path')->select();
        $this->where($where)->delete();
        foreach ($list as $key => $val) {
            @unlink($val['file_path']);
        }
    }
    
}
