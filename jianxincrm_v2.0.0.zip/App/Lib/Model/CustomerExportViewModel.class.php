<?php
class CustomerExportViewModel extends ViewModel {
    protected $viewFields;
    public function _initialize(){
        $main_must_field = array('customer_id','owner_role_id','is_locked','creator_role_id','contacts_id','delete_role_id','create_time','delete_time','update_time','get_time','is_deleted');
        $main_field = array_unique(array_merge(M('Fields')->where(array('model'=>'customer','is_main'=>1))->getField('field', true),$main_must_field));
        $main_field['_type'] = "LEFT";

        $data_field = M('Fields')->where(array('model'=>'customer','is_main'=>0))->getField('field', true);
        $data_field['_on'] = 'customer.customer_id = customer_data.customer_id';
        $data_field['_type'] = "LEFT";

        // 置顶逻辑
        $data_top = array('set_top','top_time');
        $data_top['_on'] = "customer.customer_id = top.module_id and top.module = 'customer' and top.create_role_id = ".session('role_id');
        $data_top['_type'] = "LEFT";

        // 客户关联联系人
        $data_r_contacts_customer['_on'] = 'customer.customer_id=r_contacts_customer.customer_id';
        $data_r_contacts_customer['_type'] = "LEFT";


        // 首要联系人（姓名、电话）
        $data_contacts = array('name'=>'contacts_name', 'telephone'=>'contacts_telephone', 'saltname'=>'contacts_saltname');
        $data_contacts['_on'] = "r_contacts_customer.contacts_id=contacts.contacts_id";
        $data_contacts['_type'] = "LEFT";

        // 用户
        $data_user = array('full_name' => 'owner_role_name');
        $data_user['_on'] = "customer.owner_role_id=user.role_id";
        $data_user['_type'] = "LEFT";

        // 商机
        $data_business = array('code', 'business_id');
        $data_business['_on'] = "customer.customer_id=business.customer_id";
        $data_business['_type'] = "LEFT";

        // 商机状态
        $data_business_status = array('order_id', 'is_end', 'name' => 'status');
        $data_business_status['_on'] = "business.status_id = business_status.status_id";


        $this->viewFields = array(
            'customer' => $main_field,
            'customer_data' => $data_field,
            'top' => $data_top,
            'r_contacts_customer' => $data_r_contacts_customer,
            'contacts' => $data_contacts,
            'user' => $data_user,
            'business' => $data_business,
            'business_status' => $data_business_status
        );
    }
}