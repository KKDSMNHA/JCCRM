<?php 

class DashboardWidget extends Widget 
{
	public function render($data)
	{
		/**
		 * @author JianXin dev team
		 * @function	: 获取日程信息
		 * @return		: json格式的今天日程
		 **/
		$role_id = session('role_id');
		
		//日程
		$m_event = M('event');
		$condition['owner_role_id']  = array('eq', $role_id);
		$condition['create_date'] = array('between', array(strtotime("-6 month"), strtotime("+3 month")));//半年前和三个月后
		$condition['is_deleted'] = array('eq', 0);
		$condition['status'] = array('neq', '完成');
		$condition['isclose'] = array('eq', 0);
		$event = $m_event->field('event_id,subject, create_date, "event" as type')->where($condition)->order('create_date desc')->select();
		$event = $event ? $event : array();
		
		$calendarData = $event;
		return $this->renderFile ("index",array('calendarData'=>$calendarData));
	}
}