<?php
class SettingAction extends Action{

    /**
     * 自定义模块
     * @var array
     */
    private $model_array = array('leads','customer');

	public function _initialize(){
		$action = array(
			'permission'=>array('clearcache'),
			'allow'=>array('getbusinessstatuslist','boxfield','mapdialog','customeshow','lockscreen','getreplybystatus','replylist','logreplyadd','logreplyedit','logreplydel','smtp','action_record')
		);
		B('Authenticate',$action);
	}

	public function index(){
		$this->redirect('setting/defaultInfo');
	}

    /**
     * 打开调试模式
     * @author JianXin dev team
     */
	public function openDebug(){
		$file_path =  CONF_PATH.'app_debug.php';
		$result = file_put_contents($file_path, "<?php \n\r define ('APP_DEBUG',true);");
		if($result){
			$this->ajaxReturn(1,'',1);
		}else{
			$this->ajaxReturn(1,'',2);
		}
	}
	
	/**
	*  关闭调试模式
	*
	**/
	public function closeDebug(){
		$file_path = CONF_PATH.'app_debug.php';
		$result = file_put_contents($file_path, "<?php \n\r define ('APP_DEBUG',false);");
		if($result){
			$this->ajaxReturn(1,'',1);
		}else{
			$this->ajaxReturn(1,'',2);
		}
	}
	
	/**
	*  清空缓存文件
	*
	**/
	public function clearCache(){
		if($this->clear_Cache()){
			$this->ajaxReturn(1,'',1);
		}else{
			$this->ajaxReturn(1,'',0);
		}
		
	}
	
	/**
	*  删除缓存文件
	*
	**/
	protected function clear_Cache(){
		deldir(RUNTIME_PATH);
		return true;
	}

	/**
	*  smtp设置
	*
	**/
	public function smtp(){
		if ($this->isAjax()) {
			if (ereg('^([a-zA-Z0-9]+[-|_|_|.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[-|_|_|.]?)*[a-zA-Z0-9]+.[a-zA-Z]{2,3}$',$_POST['address'])){
				if (ereg('^([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+.[a-zA-Z]{2,3}$',$_POST['test_email'])){
                    $smtp = array('MAIL_ADDRESS'=>$_POST['address'],'MAIL_SMTP'=>$_POST['smtp'],'MAIL_LOGINNAME'=>$_POST['loginName'],'MAIL_PASSWORD'=>$_POST['password'],'MAIL_PORT'=>$_POST['port'],'MAIL_SECURE'=>$_POST['secure'],'MAIL_CHARSET'=>'UTF-8','MAIL_AUTH'=>true,'MAIL_HTML'=>true);
//                    C($smtp,'smtp');
                    //C('','smtp');
                    import('@.ORG.Mail');
                    $content = L('EMALI_CONTENT');
                    $message = SendMail($_POST['test_email'],L('EMALI_TITLE'),$content,L('EMALI_AUTOGRAPH'));
                    if($message === true){
                        $message = L('SENT SUCCESSFULLY');
                    } else {
                        $message = $message ? $message : L('SENT FAILED');
                    }
				} else {
					$message = L('TEST YOUR INBOX MALFORMED');
				}
			} else {
				$message = L('EMAIL FORMAT ERROR');
			}
			$this->ajaxReturn("", $message, 1);
		} elseif($this->isPost()) {
			$edit = false;
			$m_config = M('Config');
			if(empty($_POST['address'])){
				$this->error(L('NEED_ADDRESS'));
			}
			if(empty($_POST['smtp'])){
				$this->error(L('NEED_SMTP'));
			}
			if(empty($_POST['port'])){
				$this->error( L('NEED_PORT'));
			}
			if(empty($_POST['loginName'])){
				$this->error(L('NEED_LOGINNAME'));
			}
			if(empty($_POST['password'])){
				$this->error(L('NEED_PASSWORD'));
			}
			if(is_email($_POST['address'])){
				$demosmtp = array('MAIL_ADDRESS'=>$_POST['address'],'MAIL_SMTP'=>$_POST['smtp'],'MAIL_PORT'=>$_POST['port'],'MAIL_LOGINNAME'=>$_POST['loginName'],'MAIL_PASSWORD'=>$_POST['password'],'MAIL_SECURE'=>$_POST['secure'],'MAIL_CHARSET'=>'UTF-8','MAIL_AUTH'=>true,'MAIL_HTML'=>true);
				$smtp['name'] = 'smtp';
				$smtp['value'] =serialize($demosmtp);
				if($m_config->where('name = "smtp"')->find()){
					if($m_config->where('name = "smtp"')->save($smtp)){
						$edit = true;
					}
				} else {
					if($m_config->add($smtp)){
						$edit = true;
					}else{
						$this->error(L('ADD FAILED'));
					}
				}
			}else{
				$this->error(L('EMAIL FORMAT ERROR'));
			}
			if($edit){
				alert('success',L('SUCCESSFULLY SET AND SAVED'),U('setting/smtp'));
			}else{
				$this->error(L('DATA UNCHANGED'));
			}
		} else {
			$smtp = M('Config')->where('name = "smtp"')->getField('value');
			$this->smtp = unserialize($smtp);
			$this->alert = parseAlert();
			$this->display();
		}
	}

	/**
	*  银行账户设置
	*
	**/
	public function category(){
		//判断权限

		$m_bank_account = M('BankAccount');
		$bank_list = $m_bank_account->select();

		$m_receivingorder = M('Receivingorder');
		$m_paymentorder = M('Paymentorder');

		$this->bank_list = $bank_list;
		$this->alert = parseAlert();
		$this->display();
	}

	/**
	*  银行账户(添加)
	*
	**/
	public function category_add(){
		//判断权限

		if ($this->isPost()) {
			$m_bank_account = M('bank_account');
			if(!trim($_POST['open_bank'])){
				alert('error','请填写开户行！',$_SERVER['HTTP_REFERER']);
			}
			if(!trim($_POST['bank_account'])){
				alert('error','请填写银行账户！',$_SERVER['HTTP_REFERER']);
			}
			if(!trim($_POST['company'])){
				alert('error','请填写收款单位！',$_SERVER['HTTP_REFERER']);
			}
			if($m_bank_account->create()){
				if ($m_bank_account->add()) {
					alert('success', '银行账户添加成功！', $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', '银行账户添加失败！', $_SERVER['HTTP_REFERER']);
				}
			}else{
				alert('error', '银行账户添加失败！', $_SERVER['HTTP_REFERER']);
			}
		} else {
			$this->alert=parseAlert();
			$this->display();
		}
	}

	/**
	*  银行账户(编辑)
	*
	**/
	public function category_edit(){
		//判断权限

		$m_bank_account = M('bank_account');
		if ($this->isGet()) {
			$account_id = intval(trim($_GET['id']));
			$this->bank_info = $m_bank_account = M('bank_account')->where('account_id = %d', $account_id)->find();
			$this->display();
		} else {
			if(!trim($_POST['open_bank'])){
				alert('error','请填写开户行！',$_SERVER['HTTP_REFERER']);
			}
			if(!trim($_POST['bank_account'])){
				alert('error','请填写银行账户！',$_SERVER['HTTP_REFERER']);
			}
			if(!trim($_POST['company'])){
				alert('error','请填写收款单位！',$_SERVER['HTTP_REFERER']);
			}
			if ($m_bank_account->create()) {
				if ($m_bank_account->save()) {
					alert('success', '银行账户编辑成功！', $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', '银行账户编辑失败！', $_SERVER['HTTP_REFERER']);
				}
			} else {
				alert('error','银行账户编辑失败！', $_SERVER['HTTP_REFERER']);
			}
		}
	}

	/**
	*  银行账户(删除)
	*
	**/
	public function category_delete(){
		//判断权限

		$m_bank_account = M('bank_account');
		if ($_POST['account_id']) {
			$id_array = $_POST['account_id'];
			if(!is_array($id_array)){
				$id_array = array();
				$id_array[0] = $_POST['account_id'];
			}
			if ($m_bank_account->where('account_id in (%s)', implode(',', $id_array))->delete()){
				$this->ajaxReturn('','删除成功！',1);
			} else {
				$this->ajaxReturn('','删除失败！',0);
			}
		}
	}

	/**
	*  商机状态设置
	*
	**/
	public function businessStatus(){
		$type_id = $_GET['type_id'] ? intval($_GET['type_id']) : 0;
		$type_info = M('BusinessType')->where(array('id'=>$type_id))->find();
		if (!$type_info) {
			alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
		}
		$this->statusList = M('BusinessStatus')->where(array('type_id'=>$type_id))->order('order_id')->select();
		$this->type_info = $type_info;
		$this->alert=parseAlert();
		$this->display();
	}
	
	/**
	*  添加商机状态
	*
	**/
	public function businessStatusAdd(){
		if ($this->isPost()) {
			$type_id = intval($_POST['type_id']);
			$m_status = M('BusinessStatus');
			if(!trim($_POST['name'])){
				alert('error','请填写状态名！',$_SERVER['HTTP_REFERER']);
			}
			if ($m_status->where(array('type_id'=>$type_id,'name'=>trim($_POST['name'])))->find()) {
				alert('error','该状态名已存在！',$_SERVER['HTTP_REFERER']);
			}
			if($m_status->create()){
				$order_id = $m_status->where(array('type_id'=>intval($_POST['type_id']),'order_id'=>array('not in',array('99','100'))))->max('order_id');
				$m_status->order_id = $order_id ? $order_id+1 : 1;
				if ($m_status->add()) {
					alert('success', L('SUCCESSFULLY ADDED'), $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', L('THE STATE NAME ALREADY EXISTS'), $_SERVER['HTTP_REFERER']);
				}
			}else{
				alert('error', L('ADD FAILED'), $_SERVER['HTTP_REFERER']);
			}
		} else {
			$this->alert=parseAlert();
			$this->display();
		}
	}
	
	/**
	*  修改商机状态
	*
	**/
	public function businessStatusEdit(){
		$m_status = M('BusinessStatus');
		if ($this->isGet()) {
			$status_id = intval($_GET['id']);
			$this->status = $m_status->where('status_id = %d', $status_id)->find();
			$this->display();
		} else {
			if(!trim($_POST['name'])){
				alert('error','请填写状态名！',$_SERVER['HTTP_REFERER']);
			}
			$status_id = intval($_POST['status_id']);
			$type_id = $m_status->where(array('status_id'=>$status_id))->getField('type_id');
			if ($m_status->where(array('type_id'=>$type_id,'name'=>trim($_POST['name']),'status_id'=>array('neq',$status_id)))->find()) {
				alert('error','该状态名已存在！',$_SERVER['HTTP_REFERER']);
			}
			if ($m_status->create()) {
				if ($m_status->save()) {
					alert('success', L('SUCCESSFULLY EDIT'), $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', L('DATA UNCHANGED'), $_SERVER['HTTP_REFERER']);
				}
			} else {
				alert('error', L('EDIT FAILED'), $_SERVER['HTTP_REFERER']);
			}
		}
	}
	
	/**
	*  删除商机状态
	*
	**/
	public function businessStatusDelete(){
		if ($_POST['status_id']) {
			$id_array = $_POST['status_id'];
			if(!is_array($id_array)){
				$id_array = array();
				$id_array[0] = $_POST['status_id'];
			}
			if (M('Business')->where('status_id in (%s)', implode(',', $id_array))->select() || M('RBusinessStatus')->where('status_id in (%s)', implode(',', $id_array))->select()) {
				$this->ajaxReturn('','有商机正在使用该阶段，无法删除！',0);
			} else {
				if (M('BusinessStatus')->where('status_id in (%s)', implode(',', $id_array))->delete()){
					$this->ajaxReturn('','删除成功！',1);
				} else {
					$this->ajaxReturn('','删除失败！',0);
				}
			}
		}
	}
	
	/**
	*  商机状态排序
	*
	**/
	public function businessStatusSort(){
		if ($this->isGet()) {
			$status = M('BusinessStatus');
			$a = 0;
			foreach (explode(',', $_GET['postion']) as $v) {
				$a++;
				$status->where('status_id = %d', $v)->setField('order_id',$a);
			}
			$this->ajaxReturn('1', L('SUCCESSFULLY EDIT'), 1);
		} else {
			$this->ajaxReturn('0', L('EDIT FAILED'), 1);
		}
	}

	/**
	*  ajax获取商机状态列表
	*
	**/
	public function getBusinessStatusList(){
		$statusList = M('BusinessStatus')->order('order_id')->select();
		$this->ajaxReturn($statusList, '', 1);
	}
	
	/**
	*  系统默认设置
	*
	**/
	public function defaultinfo(){
		$m_config = M('Config');

		$defaultinfo = $m_config->where('name = "defaultinfo"')->find();
		$defaultinfo = unserialize($defaultinfo['value']);
		if (IS_POST) {

			if (IS_AJAX) {
				// 设置登录页logo
				if (!session('?admin')) {
					$this->ajaxReturn(array('msg' => '您没有此权限！', 'status' => 4));
				}
				if($_FILES['blob']['error'] != 4){
						// 上传本地
						import('@.ORG.UploadFile');
						import('@.ORG.Image');
						$Img = new Image();
						$upload = new UploadFile();
						$upload->maxSize = 20000000;
						$upload->allowExts  = array('jpg', 'gif', 'png', 'jpeg');
						$dirname = UPLOAD_PATH.'/' . date('Ym', time()).'/'.date('d', time()).'/';
						$upload->thumb = true;//生成缩图
						$upload->thumbRemoveOrigin = false;//是否删除原图
						if (!is_dir($dirname) && !mkdir($dirname, 0777, true)) {
							$this->ajaxReturn(array('msg' => '创建文件夹失败！', 'status' => 2));
						}
						$upload->savePath = $dirname;
						if(!$upload->upload()) {
							$this->ajaxReturn(array('msg' => $upload->getErrorMsg(), 'status' => 3));
						}else{
							$info =  $upload->getUploadFileInfo();
						}
						if(is_array($info[0]) && !empty($info[0])){
							$upload = $dirname . $info[0]['savename'];
						}else{
							$this->ajaxReturn(array('msg' => 'Logo提交失败！', 'status' => 4));
						}
						$defaultinfo['logo'] = $upload;
						$defaultinfo['logo_thumb_path'] = $Img->thumb($upload,$dirname.'thumb_'.$info[0]['savename']);
				}
			} else {
				// 设置其他信息
				if (!session('?admin')) {
					alert('error', '您没有此权限！', $_SERVER['HTTP_REFERER']);
				}

				if ($_FILES['logo_min']['size'] > 0) {
						import('@.ORG.UploadFile');
						import('@.ORG.Image');
						$Img = new Image();
						$upload = new UploadFile();
						//设置上传文件大小
						$upload->maxSize = 20000000;
						//设置附件上传目录
						$dirname = UPLOAD_PATH . date('Ym', time()).'/'.date('d', time()).'/';
						$upload->allowExts  = array('jpg','jpeg','png','gif');// 设置附件上传类型
						if (!is_dir($dirname) && !mkdir($dirname, 0777, true)) {
							alert('error','创建文件夹失败！',$_SERVER['HTTP_REFERER']);
						}
						$upload->savePath = $dirname;
						$upload->thumb = true;//生成缩图
						$upload->thumbRemoveOrigin = false;//是否删除原图
						if(!$upload->upload()) {// 上传错误提示错误信息
							alert('error',$upload->getErrorMsg(),$_SERVER['HTTP_REFERER']);
						}else{// 上传成功 获取上传文件信息
							$info =  $upload->getUploadFileInfo();
							$upload = $dirname . $info[0]['savename'];

							$defaultinfo['logo_min'] = $upload;
							$defaultinfo['logo_min_thumb_path'] = $Img->thumb($upload,$dirname.'thumb_'.$info[0]['savename']);
						}
				}
				$defaultinfo['name'] = $this->_post('name','trim');
				$defaultinfo['description'] = $this->_post('description','trim');
				$defaultinfo['watermark'] = $this->_post('watermark','intval', 0);
			}
			$defaultinfo['allow_file_type'] = $defaultinfo['allow_file_type'] ?: 'pdf,doc,jpg,jpeg,png,gif,txt,doc,xls,zip,docx,rar';
			$value_str = serialize($defaultinfo);
			if ($m_config->where('name = "defaultinfo"')->find()) {
				$m = $m_config->where('name = "defaultinfo"')->setField('value', $value_str);
			} else {
				$m = $m_config->add(array('name' => 'defaultinfo', 'value' => $value_str));
			}
			if (IS_AJAX) {
				if ($m) {
					$this->ajaxReturn(array('msg' => '设置成功！', 'status' => 1));
				} else {
					$this->ajaxReturn(array('msg' => '设置失败！', 'status' => 5));
				}
			} else {
				if ($m) {
					alert('success','设置成功！', $_SERVER['HTTP_REFERER']);
				} else {
					alert('error','数据无变化！', $_SERVER['HTTP_REFERER']);
				}
			}
		} else {
			// $defaultinfo['logo'] = headPathHandle($defaultinfo['logo'], 1);
			// $defaultinfo['logo_thumb_path'] = headPathHandle($defaultinfo['logo_thumb_path'], 1);
			// $defaultinfo['logo_min'] = headPathHandle($defaultinfo['logo_min'], 1);
			// $defaultinfo['logo_min_thumb_path'] = headPathHandle($defaultinfo['logo_min_thumb_path'], 1);
			$this->assign('defaultinfo', $defaultinfo);
			$this->alert = parseAlert();
			$this->display('defaultinfo');
		}
	}
	
	/**
	*  业务参数设置
	*
	**/
	public function setup(){
		$m_config = M('Config');
		$defaultinfo = $m_config->where('name = "defaultinfo"')->getField('value');
		$default_info = unserialize($defaultinfo);
		if($this->isGet()){
			$this->defaultinfo = $default_info;
			// 前台非遍历显示，故不此处理进销存设置 2018-07-12
			$config_array = array();
			$config_list = $m_config->select();
			foreach($config_list as $k=>$v){
				$config_array[$v['name']] = $v['value'];
			}
			$this->assign('config_array',$config_array);
			//DEBUG模式是否打开
			if(APP_DEBUG == 1){
				$this->app_debug = 1;
			}else{
				$this->app_debug = 0;
			}
			$this->alert = parseAlert();
			$this->display();
		}elseif($this->isPost()){
			// 获取修改前后的配置信息【操作记录】
			$old_data = D('Setting')->getOldData();
			$new_data = D('Setting')->getNewData($_POST);

			$data['logo'] = $default_info['logo'];
			$data['logo_min'] = $default_info['logo_min'];
			$data['name'] = trim($default_info['name']);
			if ($data['name'] == "") {
				alert('error',L('THE SYSTEM NAME CAN NOT BE EMPTY'),U('setting/setup'));
			}
			$data['description'] = trim($default_info['description']);
			$data['state'] = trim($default_info['state']);
			$data['city'] = trim($default_info['city']);
			$allow_file_type = explode(',',$_POST['allow_file_type']);
			if(!empty($_POST['allow_file_type'])){
				$allow_list = array();
				foreach($allow_file_type as $k=>$v){
					if($v != 'php'){
						$allow_list[] = $v;
					}
				}
				$allow_file_list = implode(',',$allow_list);
			}else{
				$allow_file_list = '';
			}
			$data['allow_file_type'] = !empty($allow_file_list) ? trim($allow_file_list) : 'pdf,doc,ppt,txt,xls,zip,docx,rar,pptx,xlsx,jpg,jpeg,png,gif';
			$data['contract_alert_time'] = intval(trim($_POST['contract_alert_time']));
			$data['is_invoice'] = trim($_POST['is_invoice']);
			$data['state'] = $_POST['state'];
			$data['city'] = $_POST['city'];
			if($defaultinfo){
				$default = unserialize($defaultinfo['value']);					
				if (!isset($data['logo']) || $data['logo'] == "") {
					$data['logo'] = $default['logo'];
				}				
				if($m_config->where('name = "defaultinfo"')->save(array('value'=>serialize($data)))){
					$result_defaultinfo = true;
				} else {
					$result_defaultinfo = false;
				}
			} else {
				if($m_config->add(array('value'=>serialize($data), 'name'=>'defaultinfo'))){
					$result_defaultinfo = true;
				}else{
					$result_defaultinfo = false;
				}
			}
			//是否替换原来的
			$bc_check = $m_config -> where('name="bc_check"') -> setField('value',$_POST['bc_check']);
			$bc_info = $m_config-> where('name="business_custom"')->find();
			$m_business = M('Business');
			if($bc_info['value'] != $_POST['business_custom'] && $_POST['bc_check'] == 1){
				$bus_list = $m_business->where('business_id >0')->select();
				foreach($bus_list as $kk=>$vv){
					$new_num = str_replace($vv['prefixion'],$_POST['business_custom'],$vv['code']);
					$m_business->where('business_id =%d',$vv['business_id'])->setField('code',$new_num);
				}
				$m_business->where('business_id >0')->save(array('prefixion'=>$_POST['business_custom']));
			}

			$cc_check = $m_config -> where('name="cc_check"') -> setField('value',$_POST['cc_check']);
			$cc_info = $m_config-> where('name="contract_custom"')->find();
			$m_contract = M('Contract');
			if($cc_info['value'] != $_POST['contract_custom'] && $_POST['cc_check'] == 1){
				$contract_list = $m_contract->where('contract_id >0')->select();
				foreach($contract_list as $kk=>$vv){
					$new_num = str_replace($vv['prefixion'],$_POST['contract_custom'],$vv['number']);
					$m_contract->where('contract_id =%d',$vv['contract_id'])->setField('number',$new_num);
				}
				$m_contract->where('contract_id >0')->save(array('prefixion'=>$_POST['contract_custom']));
			}

			$fc_check = $m_config -> where('name="fc_check"') -> setField('value',$_POST['fc_check']);
			$fc_info = $m_config-> where('name="receivables_custom"')->find();
			$m_receivables = M('Receivables');
			if($fc_info['value'] != $_POST['receivables_custom'] && $_POST['fc_check'] == 1){
				$receivables_list = $m_receivables->where('receivables_id >0')->select();
				foreach($receivables_list as $kk=>$vv){
					$new_num = str_replace($vv['prefixion'],$_POST['receivables_custom'],$vv['name']);
					$m_receivables->where('receivables_id =%d',$vv['receivables_id'])->setField('name',$new_num);
				}
				$m_receivables->where('receivables_id >0')->save(array('prefixion'=>$_POST['receivables_custom']));
			}

			$uc_check = $m_config -> where('name="uc_check"') -> setField('value',$_POST['uc_check']);
			$uc_info = $m_config-> where('name="user_custom"')->find();
			$m_user = M('User');
			if($uc_info['value'] != $_POST['user_custom'] && $_POST['uc_check'] == 1){
				$role_list = $m_user->where('user_id >0')->select();
				foreach($role_list as $kk=>$vv){
					$new_num = str_replace($vv['prefixion'],$_POST['user_custom'],$vv['number']);
					$m_user->where('user_id =%d',$vv['user_id'])->setField('number',$new_num);
				}
				$m_user->where('user_id >0')->save(array('prefixion'=>$_POST['user_custom']));
			}
			//改变合同前缀名
			if(!$m_config-> where('name="contract_custom"')->find()){
				$contract_custom['name'] = 'contract_custom';
				$contract_custom['value'] = $_POST['contract_custom'];
				$contract_custom = $m_config -> add($contract_custom);    
			}else {
				$contract_custom = $m_config -> where('name="contract_custom"') -> setField('value',$_POST['contract_custom']);
			}
			//应收款编号前缀
			if(!$m_config-> where('name="receivables_custom"')->find()){
				$receivables_custom['name'] = 'receivables_custom';
				$receivables_custom['value'] = $_POST['receivables_custom'];
				$receivables_custom = $m_config -> add($receivables_custom);
			}else {
				$receivables_custom = $m_config -> where('name="receivables_custom"') -> setField('value',$_POST['receivables_custom']);
			}
			//商机编号前缀
			if(!$m_config-> where('name="business_custom"')->find()){
				$business_custom['name'] = 'business_custom';
				$business_custom['value'] = $_POST['business_custom'];
				$business_custom = $m_config -> add($business_custom);
			}else {
				$business_custom = $m_config -> where('name="business_custom"') -> setField('value',$_POST['business_custom']);
			}
			//员工编号前缀
			if(!$m_config-> where('name="user_custom"')->find()){
				$user_custom['name'] = 'user_custom';
				$user_custom['value'] = $_POST['user_custom'];
				$user_custom = $m_config -> add($user_custom);
			}else {
				$user_custom = $m_config -> where('name="user_custom"') -> setField('value',$_POST['user_custom']);
			}
			//客户数量限制
			if(!$m_config-> where('name="opennum"')->find()){
				$cus_num['name'] = 'opennum';
				$cus_num['value'] = $_POST['opennum'];
				$customer_num = $m_config -> add($cus_num);
			}else {
				$customer_num = $m_config -> where('name="opennum"') -> setField('value',$_POST['opennum']);
			}
			// 可搜索已停用用户
			if(!$m_config-> where('name="search_disable_user"')->find()){
				$cus_num['name'] = 'search_disable_user';
				$cus_num['value'] = $_POST['search_disable_user'];
				$search_disable_user = $m_config -> add($cus_num);
			}else {
				$search_disable_user = $m_config -> where('name="search_disable_user"') -> setField('value',$_POST['search_disable_user']);
			}
			//回款到期提醒
			if(!$m_config-> where('name="receivables_time"')->find()){
				$rec_num['name'] = 'receivables_time';
				$rec_num['value'] = $_POST['receivables_time'];
				$rec_date = $m_config -> add($rec_num);
			}else {
				$rec_date = $m_config -> where('name="receivables_time"') -> setField('value',$_POST['receivables_time']);
			}

			//判断如果重新启用则更改客户回收时间
			$old_openrecycle = $m_config ->where('name = "openrecycle"')->getField('value');
			if($old_openrecycle == 1){
				if($_POST['openrecycle'] == 2){
					$c_data['get_time'] = time();
					$c_data['update_time'] = time();

					// 不启用->启用，把原来非客户池中的所有数据更新
					$d_customer = D('Customer');
					$where_customer = $d_customer->where_belong();
					$where_customer['is_deleted'] = 0;
					$d_customer->where($where_customer)->save($c_data);
				}
			} else if ($old_openrecycle == 2) {
				if($_POST['openrecycle'] == 1){
					$c_data['owner_role_id'] = 0;

					// 启用->不启用，把原来客户池中的所有数据负责人更新为0
					$d_customer = D('Customer');
					$where_customer = $d_customer->where_belong('public');
					$where_customer['is_deleted'] = 0;
					$d_customer->where($where_customer)->save($c_data);
				}
			}

			$leads_outdays = $m_config -> where('name="leads_outdays"') -> setField('value',$_POST['leads_outdays']);
			$result_customer_outdays = $m_config->where('name = "customer_outdays"')->setField('value', $_POST['customer_outdays']);
			$result_contract_outdays = $m_config->where('name = "contract_outdays"')->setField('value', $_POST['contract_outdays']);
			
			$m_config->where('name = "openrecycle"')->setField('value', $_POST['openrecycle']);
			$result_openrecycle = $m_config->where('name = "openrecycle"')->setField('value', $_POST['openrecycle']);
			$result_customer_limit_condition = $m_config->where('name = "customer_limit_condition"')->setField('value', $_POST['customer_limit_condition']);
			$result_customer_limit_counts = $m_config->where('name = "customer_limit_counts"')->setField('value', $_POST['customer_limit_counts']);
			$is_invoice = $m_config->where('name = "is_invoice"')->setField('value', $_POST['is_invoice']);
			if($result_defaultinfo || $result_contract_outdays || $contract_custom  || $leads_outdays || $result_customer_outdays || $result_customer_limit_condition || $result_customer_limit_counts || $is_invoice || $result_openrecycle || $bc_check || $cc_check || $fc_check || $business_custom || $receivables_custom || $user_custom || $customer_num ||$rec_date || $search_disable_user){

				// 添加操作记录
				recordAction($new_data, $old_data, 'setting', 1);
				alert('success',L('SUCCESSFULLY SET AND SAVED'),U('setting/setup'));
			} else {
				alert('error',L('DATA UNCHANGED'),U('setting/setup'));
			}
		}
	}

    /**
     * 自定义字段列表
     * @author JianXin dev team
     */
    public function fields(){
        $model = $this->_get('model','trim','customer');
        $model_array = $this->model_array;
        if(!in_array(trim($_GET['model']),$model_array)){
            alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
        }
        $where = array();
        $where['model'] = $model;
        $fields = M('fields')->where($where)->order('order_id ASC')->select();
        foreach($fields as $k=>$v){
            if($v['is_validate'] == 1 && $v['is_null'] == 1){
                $fields[$k]['is_null'] = '是';
            }else{
                $fields[$k]['is_null'] = '否';
            }
        }
        if ($model == 'leads') {
            $this->assign('not_support', D('Leads')->not_support);
            $exchange = M('FLeadsCustomer')->where('customer_field_id != 0 && leads_field_id != 0')->select();
            $tmp = D('Leads')->supportField();
            $this->assign('exchange', y_array_column(array_merge($tmp['main'], $tmp['data']), null, 'l'));
        }
        $this->assign('model',$model);
        $this->assign('fields',$fields);
        $this->alert=parseAlert();
        $this->display();
    }

    /**
     * 自定义字段是否列表显示
     * @author JianXin dev team
     */
    public function indexShow(){
        $field = M('fields');
        $field_id = $this->_request('field_id','intval',0);
        if($this->isAjax()){
            if($field_id == 0){
                $this->ajaxReturn('',L('PARAMETER_ERROR'),0);
            }
            $field_info = $field->where(array('field_id'=>$field_id))->find();
            if($field_info['in_index']) {
                if($field ->where('field_id = %d', $field_id)->setField('in_index', 0)){
                    $this->ajaxReturn('','success',1);
                }else{
                    $this->ajaxReturn('','修改失败，请重试！',0);
                }
            }else{
                if($field ->where('field_id = %d', $field_id)->setField('in_index', 1)){
                    $this->ajaxReturn('','success',1);
                }else{
                    $this->ajaxReturn('','修改失败，请重试！',0);
                }
            }
        }

    }

    /**
     * 添加自定义字段
     * @author JianXin dev team
     */
    public function fieldAdd(){
        $field = M('fields');
        $model = trim($_REQUEST['model']) ? : '';
        $status = intval($_REQUEST['status']) ? : '';

        $model_array = $this->model_array;
        if(!in_array($model,$model_array)){
            echo '<div class="alert alert-error">参数错误！</div>';die();
        }
        if($this->isPost()){
            $field_model = D('Field');
            $field_str = 'jxcrm_';
            for ($i = 1; $i <= 6; $i++) {
                $field_str .= chr(rand(97, 122));
            }

            $data['model']         = $this->_post('model'); //模块名称
            $data['field']         = $field_str; //字段名称
            $data['name']         = $this->_post('name'); //标识名称
            $data['form_type']     = $this->_post('form_type'); //字段类型
            $data['default_value'] = $this->_post('default_value');  //默认值
            $data['max_length']    = $this->_post('max_length');
            $data['is_main']       = $this->_post('is_main');
            $data['status']       = $status;
            if($field->where(array('field'=>$field_str,'model'=>array(array('eq',$data['model']),array('eq',''),'OR'),'status'=>$status))->find()){
                alert('error',L('THE FIELD NAME ALREADY EXISTS'),$_SERVER['HTTP_REFERER']);
            }
            if($field->where(array('name'=>$data['name'],'model'=>array(array('eq',$data['model']),array('eq',''),'OR'),'status'=>$status))->find()){
                alert('error','该标识名已存在',$_SERVER['HTTP_REFERER']);
            }
            if($field_model->add($data) !== false){
                $field->create();
                $field->field = $field_str; //字段名称
                if($this->_post('form_type') == 'box'){
                    $setting = $this->_post('setting');
                    if(!empty($setting['options'])){
                        $field->setting = 'array(';
                        $field->setting .= "'type'=>'$setting[boxtype]','data'=>array(";
                        $i = 0;
                        $options = explode(chr(10),$setting['options']);
                        $s = array();
                        foreach($options as $v){
                            $v = trim(str_replace(chr(13),'',$v));
                            if($v != '' && !in_array($v ,$s)){
                                $i++;
                                $field->setting .= "$i=>'$v',";
                                $s[] = $v;
                            }
                        }
                        $field->setting = substr($field->setting,0,strlen($field->setting) -1 ) .'))';
                    }else{
                        $field->setting = "array('type'=>'$setting[boxtype]')";
                    }
                }
                $field->add();
                $this->clear_Cache();
                alert('success',L('ADD CUSTOM FIELD SUCCESS'),$_SERVER['HTTP_REFERER']);
            }else{
                if($error = $field_model->getError()){
                    alert('error',$error,$_SERVER['HTTP_REFERER']);
                }else{
                    alert('error',L('ADDING CUSTOM FIELDS TO FAIL'),$_SERVER['HTTP_REFERER']);
                }
            }
        }else{
            $this->assign('model',$model);
            $this->assign('status',$status);
            $this->alert = parseAlert();
            $this->display();
        }
    }

    /**
     * 修改自定义字段
     * @author JianXin dev team
     */
    public function fieldEdit(){
        $field = M('fields');
        $field_id = $this->_request('field_id','intval',0);
        if($field_id == 0) alert('error',L('PARAMETER_ERROR'),$_SERVER['HTTP_REFERER']);
        $field_info = $field->where(array('field_id'=>$field_id))->find();
        if($field_info['operating'] == 2)  alert('error',L('SYSTEM FIXED FIELD PROHIBIT MODIFICATION'),$_SERVER['HTTP_REFERER']);;
        if($this->isPost()){
            $field_model = D('Field');
            $data['model']         = $field_info['model']; //模块名称
            $data['field']         = $field_info['operating'] == 0 ? $this->_post('field') : $field_info['field']; //字段名称
            $data['field_old']     = $field_info['field']; //字段名称
            $data['form_type']     = $field_info['form_type']; //字段类型
            $data['default_value'] = $this->_post('default_value');  //默认值
            $data['max_length']    = $this->_post('max_length');
            $data['is_main']       = $field_info['is_main'];
            $data['name']          = $this->_post('name'); //标识名称

            if($field->where(array('field'=>$data['field'],'model'=>array(array('eq',$data['model']),array('eq',''),'OR'),'field_id'=>array('neq',$field_id),'status'=>$field_info['stauts']))->find()){
                alert('error',L('THE FIELD NAME ALREADY EXISTS'),$_SERVER['HTTP_REFERER']);
            }
            if($field_model->save($data) !== false){
                $field->create();
                if($field_info['form_type'] == 'box'){
                    eval('$field_info["setting"] = '.$field_info["setting"].';');
                    $boxtype = $field_info['setting']['type'];
                    $setting = $this->_post('setting');
                    if(!empty($setting['options'])){
                        $field->setting = 'array(';
                        $field->setting .= "'type'=>'$setting[boxtype]','data'=>array(";
                        $i = 0;
                        $options = explode(chr(10),$setting['options']);
                        $s = array();
                        foreach($options as $v){
                            $v = trim(str_replace(chr(13),'',$v));
                            if($v != '' && !in_array($v ,$s)){
                                $i++;
                                $field->setting .= "$i=>'$v',";
                                $s[] = $v;
                            }
                        }
                        $field->setting = substr($field->setting,0,strlen($field->setting) -1 ) .'))';
                    }else{
                        $field->setting = "array('type'=>'$setting[boxtype]')";
                    }
                }

                $field->save();
                $this->clear_Cache();
                alert('success',L('MODIFY CUSTOM FIELD SUCCESS'), $_SERVER['HTTP_REFERER']);
            }else{
                if($error = $field_model->getError()){
                    alert('error',$error,$_SERVER['HTTP_REFERER']);
                }else{
                    alert('error',L('FAILED TO MODIFY CUSTOM FIELDS'),$_SERVER['HTTP_REFERER']);
                }
            }
        }else{
            if($field_info['form_type'] == 'box'){
                $field_info["setting"] = $field_info["setting"] ?: '""';
                eval('$field_info["setting"] = '.$field_info["setting"].' ?: "";');
                $field_info['form_type_name'] = L('OPTIONS');
                $field_info["setting"]['options'] = implode(chr(10),$field_info["setting"]['data']);
            }else if($field_info['form_type'] == 'editor'){
                $field_info['form_type_name'] = L('EDITOR');
            }else if($field_info['form_type'] == 'text'){
                $field_info['form_type_name'] = L('TEXT');
            }else if($field_info['form_type'] == 'textarea'){
                $field_info['form_type_name'] = L('TEXTAREA');
            }else if($field_info['form_type'] == 'datetime'){
                $field_info['form_type_name'] = L('DATETIME');
            }else if($field_info['form_type'] == 'number'){
                $field_info['form_type_name'] = L('NUMBER');
            }else if($field_info['form_type'] == 'floatnumber'){
                $field_info['form_type_name'] = L('FLOATNUMBER');
            }else if($field_info['form_type'] == 'address'){
                $field_info['form_type_name'] = L('ADDRESS');
            }else if($field_info['form_type'] == 'phone'){
                $field_info['form_type_name'] = L('PHONE');
            }else if($field_info['form_type'] == 'mobile'){
                $field_info['form_type_name'] = L('MOBILE');
            }else if($field_info['form_type'] == 'email'){
                $field_info['form_type_name'] = L('EMAIL');
            }
            $this->assign('fields',$field_info);
            $this->assign('models',array('customer'=>L('CUSTOMER'),'business'=>L('BUSINESS'),'contacts'=>L('CONTACTS')));
            $this->alert = parseAlert();
            $this->display();
        }
    }

    /**
     * 删除自定义字段
     * @author JianXin dev team
     */
    public function fieldDelete(){
        $field = M('fields');
        if($this->isPost()){
            $field_id = is_array($_POST['field_id']) ? implode(',', $_POST['field_id']) : '';
            if ('' == $field_id) {
                alert('error', L('NOT CHOOSE ANY'), $_SERVER['HTTP_REFERER']);
                die;
            } else {
                $where['field_id'] = array('in',$field_id);
                $where['operating'] = array('not in', array(3,0));

                $field_info = $field->where($where)->select();
                if($field_info){
                    alert('error', L('SYSTEM FIXED FIELDS DELETE PROHIBITED'), $_SERVER['HTTP_REFERER']);
                }else{
                    $field_infos = $field->where(array('field_id'=>array('in',$field_id)))->select();
                    foreach($field_infos as $field_info){
                        $field_model = D('Field');
                        $data['model']         = $field_info['model']; //模块名称
                        $data['field']         = $field_info['field']; //字段名称
                        $data['is_main']       = $field_info['is_main'];
                        $field_model->delete($data);
                        $field->where(array('field_id'=>$field_info['field_id']))->delete();
                    }
                    $this->clear_Cache();
                    alert('success',L('DELETE CUSTOM FIELD SUCCESS'),$_SERVER['HTTP_REFERER']);
                }
            }
        }else{
            $field_id = $this->_get('field_id','intval',0);
            if($field_id == 0) alert('error',L('PARAMETER_ERROR'),$_SERVER['HTTP_REFERER']);
            $field_info = $field->where(array('field_id'=>$field_id))->find();
            if($field_info['operating'] != 0) alert('error',L('SYSTEM FIXED FIELDS DELETE PROHIBITED'),$_SERVER['HTTP_REFERER']);
            $field_model = D('Field');
            $data['model'] = $field_info['model']; //模块名称
            $data['field'] = $field_info['field']; //字段名称
            $data['is_main'] = $field_info['is_main'];
            if($field_model->delete($data) !== false){
                $field->where(array('field_id'=>$field_id))->delete();
                $this->clear_Cache();
                $this->ajaxReturn($data['model'],L('DELETE CUSTOM FIELD SUCCESS'),1);
            }else{
                $this->ajaxReturn($data['model'],L('FAILED TO DELETE CUSTOM FIELDS'),0);
            }
        }

    }

    /**
     * 自定义字段排序
     * @author JianXin dev team
     */
    public function fieldsort(){
        if(isset($_GET['postion'])){
            $fields = M('fields');
            foreach(explode(',', $_GET['postion']) AS $k=>$v) {
                $data = array('field_id'=> $v, 'order_id'=>$k);
                $fields->save($data);
            }
            $this->ajaxReturn('1', L('SUCCESSFULLY EDIT'), 1);
        } else {
            $this->ajaxReturn('0', L('EDIT FAILED'), 1);
        }
    }

    /**
     * 获得自定义字段选项
     * @author JianXin dev team
     */
    public function boxField(){
        $field_list = M('Fields')->where(array('model'=>$this->_get('model'),'field'=>$this->_get('field')))->getField('setting');
        eval('$field_list = '.$field_list .';');
        $this->ajaxReturn(array('data' => $field_list['data'], 'info' => $field_list['type'], 'status' => 1, 'kv' => $field_list['kv'] ?: false));
    }

	public function customeshow(){
		$m_fields = M('fields');
		$field_id = intval($_GET['field_id']);
		$id = intval($_GET['id']);
		if($field_id){
			if($id == 1){
				$is_show = $id;
			}else{
				$is_show = 0;
			}
			$result = $m_fields ->where('field_id =%d',$field_id)->setField('is_show',$is_show);
			if($result){
				if($id == 1){
					$data = '客户列表页显示开启！';
				}else{
					$data = '客户列表页显示关闭！';
				}
				alert('success',$data,$_SERVER['HTTP_REFERER']);
			}else{
				alert('error','操作失败!',$_SERVER['HTTP_REFERER']);
			}
		}
	}

	//锁屏页面
	// session('is_lock') 1锁屏2正常
	public function lockscreen(){
		$user_info = M('User')->where('role_id = %d',session('role_id'))->field('role_id,name,full_name,img,password,salt')->find();
		if($this->isPost()){
			if ($user_info['password'] == md5(trim($_POST['password']) . $user_info['salt'])) {
				unset($_SESSION['is_lock']);
				$this->ajaxReturn('正在登录','',1);
			}else{
				$this->ajaxReturn('','密码错误，请重新输入！',0);
			}
		}
		session('is_lock',1);
		$this->user_info = $user_info;
		$this->display();
	}

	/**
	 * 审批设置列表
	 **/
	public function examine(){
		$m_examine_status = M('examine_status');
		$examine_status_list = $m_examine_status ->select();
		foreach ($examine_status_list as $k=>$v) {
			$examine_status_list[$k]['description'] = '适用于公司请假审批' ? : $v['description'];
			$examine_status_list[$k]['img_repeat'] = '0px';
		}
		$this->status_list = $examine_status_list;
		$this->alert = parseAlert();
		$this->display();
	}

	/**
	 * 审批流程设置
	 **/
	public function examinetype(){
		$m_examine_status = M('examine_status');
		$m_examine_step = M('ExamineStep');
		$m_position = M('Position');
		$m_user = M('User');
		
		$id = intval($_GET['id']);
		$status_info = $m_examine_status ->where('id=%d',$id)->find();
		$step_list = $m_examine_step->where('process_id=%d',$id)->order('order_id')->select();
		foreach($step_list as $k=>$v){
			//处理order_id排序异常
			$data = array();
			$data = array('step_id'=>$v['step_id'], 'order_id'=>$k);
			$m_examine_step->save($data);

			$role_ids = explode(',',$v['role_id']);
			$step_list[$k]['role_list'] = $m_user->where(array('role_id'=>array('in',$role_ids)))->field('thumb_path,full_name,role_id')->select();
			if (count($role_ids) > 1) {
				if ($v['relation'] == 1) {
					$step_list[$k]['relation_name'] = '并';
				} elseif ($v['relation'] == 2) {
					$step_list[$k]['relation_name'] = '或';
				}
			}
		}
		$this->assign('step_list',$step_list);
		$this->status_info = $status_info;
		$this->status_id = $id;
		$this->alert = parseAlert();
		$this->display();
	}

	/**
	 * 审批流程保存
	 **/
	public function ajaxexamine(){
		$m_examine_status = M('examine_status');
		$type = intval($_POST['openrecycle']);
		$status_id = intval($_POST['status_id']);
		//审批未结束，不能编辑
		if (M('Examine')->where(array('type'=>$status_id,'examine_status'=>1))->find()) {
			$this->ajaxReturn('error','此流程有审批正在使用中，不能编辑！',0);
		}

		if($type== 1){
			$option_id = 0;
		}else{
			$option_id = 1;
		}
		$result = $m_examine_status ->where('id=%d',$status_id)->setField('option',$option_id);
		if($result){
			$this->ajaxReturn('success','编辑成功！',1);
		}else{
			$this->ajaxReturn('error','编辑失败！',0);
		}
	}

	/**
	 * 编辑审批流程
	 **/
	public function edit_process(){
		$m_examine_status = M('ExamineStatus');
		$d_role = D('RoleView');
		$process_id = $_REQUEST['process_id'] ? intval($_REQUEST['process_id']) : '';
		if (!$process_id) {
			if ($this->isPost()) {
				alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
			} else {
				echo '<div class="alert alert-error">参数错误！</div>';die();
			}
		}
		//审批未结束，不能编辑
		if (M('Examine')->where(array('type'=>$process_id,'examine_status'=>1))->find()) {
			if ($this->isPost()) {
				alert('error','此流程有审批正在使用中，不能编辑！',$_SERVER['HTTP_REFERER']);
			} else {
				echo '<div class="alert alert-error">此流程有审批正在使用中，不能编辑！</div>';die();
			}
		}

		if($this->isPost()){
			// $m_examine_process->create();
			// $m_examine_process->save();
			alert('success','修改成功！',$_SERVER['HTTP_REFERER']);
		}else{
			$m_examine_step = M('ExamineStep');
			$m_position = M('Position');
			$m_user = M('User');
			
			//流程信息
			$data = $m_examine_status->where('id = %d',$process_id)->find();
			$data['role_arr'] = array_filter(explode(',',$data['role_id']));
			//该流程下的步骤列表
			$step_list = $m_examine_step->where('process_id = %d',$process_id)->order('order_id')->select();

			$max_step_id = $m_examine_step->where('process_id = %d',$process_id)->max('step_id');
			foreach($step_list as $k=>$v){
				$role_ids = explode(',',$v['role_id']);
				$step_list[$k]['role_list'] = $m_user->where(array('role_id'=>array('in',$role_ids)))->field('full_name,thumb_path,role_id')->select();
				if (!strpos('jx'.$v['role_id'],',')) {
					$step_list[$k]['role_id'] = ','.$v['role_id'].',';	
				} 
				if ($v['relation'] == 1) {
					$step_list[$k]['relation_name'] = '并';
				} elseif ($v['relation'] == 2) {
					$step_list[$k]['relation_name'] = '或';
				}
			}
			$this->assign('step_list',$step_list);
			$this->assign('data',$data);
			$this->max_step_id = $max_step_id;
			$this->alert = parseAlert();
			$this->display();
		}
	}

	/**
	 * 清空审批流程数据
	 **/
	public function cleartype(){
		$status_id = intval($_POST['status_id']);
		if($status_id){
			//审批未结束，不能编辑
			if (M('Examine')->where(array('type'=>$status_id,'examine_status'=>1))->find()) {
				$this->ajaxReturn('error','此流程有审批正在使用中，不能清空！',0);
			}
			$m_examine_step = M('ExamineStep');
			$result = $m_examine_step ->where('process_id=%d',$status_id)->delete();
			if($result){
				$this->ajaxReturn('success','清除成功！',1);
			}else{
				$this->ajaxReturn('error','清空失败数据无变化！',0);
			}
		}else{
			$this->ajaxReturn('error','获取参数失败！',0);
		}
	}

	/**
	 * 审批流程排序
	 **/
	public function examinesort(){	
		if(isset($_GET['postion'])){
			$examine_step = M('examine_step');
			foreach(explode(',', $_GET['postion']) AS $k=>$v) {
				$data = array('step_id'=> $v, 'order_id'=>$k);
				$examine_step->save($data);
			}
			$this->ajaxReturn('1', L('SUCCESSFULLY EDIT'), 1);
		} else {
			$this->ajaxReturn('0', L('EDIT FAILED'), 1);
		}
	}

	/**
	 * 停用和启用数据
	 **/
	public function enable(){	
		if(isset($_POST['type'])){
			$type = intval($_POST['type']);
			$id = intval($_POST['id']);
			$m_examine_status = M('ExamineStatus');
			if($type == 1){
				$type_id = 0;
			}else{
				$type_id = 1;
			}
			$result = $m_examine_status ->where('id= %d',$id)->setField('type',$type_id);
			$this->ajaxReturn('1', L('SUCCESSFULLY EDIT'), 1);
		} else {
			$this->ajaxReturn('0', L('EDIT FAILED'), 0);
		}
	}

	/**
	 * 沟通类型
	 **/
	public function logStatus() {
		//判断权限

		$m_log_status = M('LogStatus');
		$status_list = $m_log_status->select();

		$this->status_list = $status_list;
		$this->alert = parseAlert();
		$this->display();
	}

	/**
	 * 沟通类型(添加)
	 **/
	public function logStatusAdd() {
		if ($this->isPost()) {
			$m_log_status = M('LogStatus');
			if(!trim($_POST['name'])){
				alert('error','请填写名称！',$_SERVER['HTTP_REFERER']);
			}
			if ($m_log_status->where(array('name'=>trim($_POST['name'])))->find()) {
				alert('error','该名称已存在，请修改后重试！',$_SERVER['HTTP_REFERER']);
			}
			if($m_log_status->create()){
				$m_log_status->create_role_id = session('role_id');
				$m_log_status->create_time = time();
				$m_log_status->update_time = time();
				if ($m_log_status->add()) {
					alert('success', '沟通类型添加成功！', $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', '沟通类型添加失败！', $_SERVER['HTTP_REFERER']);
				}
			}else{
				alert('error', '沟通类型添加失败！', $_SERVER['HTTP_REFERER']);
			}
		} else {
			$this->alert=parseAlert();
			$this->display();
		}
	}

	/**
	 * 沟通类型(编辑)
	 **/
	public function logStatusEdit() {
		$id = $_REQUEST['id'] ? intval($_REQUEST['id']) : '';
		if (!$id) {
			alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
		}
		$m_log_status = M('LogStatus');
		$status_info = $m_log_status->where('id = %d',$id)->find();
		if ($this->isPost()) {
			
			if(!trim($_POST['name'])){
				alert('error','请填写名称！',$_SERVER['HTTP_REFERER']);
			}
			if ($m_log_status->where(array('name'=>trim($_POST['name']),'id'=>array('neq',$id)))->find()) {
				alert('error','该名称已存在，请修改后重试！',$_SERVER['HTTP_REFERER']);
			}
			if($m_log_status->create()){
				$m_log_status->update_time = time();
				if ($m_log_status->where('id = %d',$id)->save()) {
					alert('success', '沟通类型修改成功！', $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', '沟通类型修改失败！', $_SERVER['HTTP_REFERER']);
				}
			}else{
				alert('error', '沟通类型修改失败！', $_SERVER['HTTP_REFERER']);
			}
		} else {
			$this->status_info = $status_info;
			$this->alert=parseAlert();
			$this->display();
		}
	}

	/**
	 * 沟通类型(删除)
	 **/
	public function logStatusDel() {
		$m_log_status = M('LogStatus');
		$m_log = M('Log');
		if ($_POST['id']) {
			$id_array = $_POST['id'];
			if(!is_array($id_array)){
				$id_array = array();
				$id_array[0] = $_POST['id'];
			}
			$del_arr = array();
			//判断是否被使用
			foreach ($id_array as $k=>$v) {
				if (!$m_log->where(array('status_id'=>$v,'category_id'=>1))->find()) {
					$del_arr[] = $v;
				}
			}
			if ($del_arr) {
				if ($m_log_status->where('id in (%s)', implode(',', $del_arr))->delete()){
					if (count($id_array) == count($del_arr)) {
						$this->ajaxReturn('','删除成功！',1);
					} else {
						$this->ajaxReturn('','部分类型已被使用，删除失败！',1);
					}
				} else {
					$this->ajaxReturn('','删除失败！',0);
				}
			} else {
				$this->ajaxReturn('','所选类型已被使用，不能删除！',0);
			}
		}
	}

	/**
	 * 沟通日志快捷回复
	 **/
	public function logReply() {
		//判断权限

		$status_id = $_GET['status_id'] ? intval($_GET['status_id']) : '';
		if (!$status_id) {
			alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
		}
		$m_log_reply = M('LogReply');
		$reply_list = $m_log_reply->where(array('type'=>1,'status_id'=>$status_id))->select();
		foreach ($reply_list as $k=>$v) {
			$reply_list[$k]['str_content'] = cutString($v['content'],30);
		}

		$this->reply_list = $reply_list;
		$this->alert = parseAlert();
		$this->display();
	}

	/**
	 * 沟通日志快捷回复(添加)
	 **/
	public function logReplyAdd() {
		$status_id = $_REQUEST['status_id'] ? intval($_REQUEST['status_id']) : '';
		//type 1系统2个人
		$type = $_REQUEST['type'] ? intval($_REQUEST['type']) : '2';
		if (!$status_id || !in_array($type,array('1','2'))) {
			alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
		}
		$m_log_status = M('LogStatus');
		$status_name = $m_log_status->where('id = %d',$status_id)->getField('name');
		if ($this->isPost()) {
			$m_log_reply = M('LogReply');
			if(!trim($_POST['content'])){
				alert('error','请填写内容！',$_SERVER['HTTP_REFERER']);
			}
			if($m_log_reply->create()){
				$m_log_reply->type = $type;
				$m_log_reply->role_id = session('role_id');
				$m_log_reply->create_time = time();
				$m_log_reply->update_time = time();
				if ($reply_id = $m_log_reply->add()) {
					if ($type == 2) {
						$reply_info = $m_log_reply->where('id = %d',$reply_id)->find();
						$reply_info['status_name'] = $m_log_status->where('id = %d',$reply_info['status_id'])->getField('name');
						$this->ajaxReturn($reply_info,'快捷回复添加成功！',1);
					} else {
						alert('success', '快捷回复添加成功！', $_SERVER['HTTP_REFERER']);
					}
				} else {
					if ($type == 2) {
						$this->ajaxReturn('','快捷回复添加失败！',0);
					} else {
						alert('error', '快捷回复添加失败！', $_SERVER['HTTP_REFERER']);
					}
				}
			}else{
				if ($type == 2) {
					$this->ajaxReturn('','快捷回复添加失败！',0);
				} else {
					alert('error', '快捷回复添加失败！', $_SERVER['HTTP_REFERER']);
				}
			}
		} else {
			$this->status_name = $status_name;
			$this->display();
		}
	}

	/**
	 * 沟通日志快捷回复(编辑)
	 **/
	public function logReplyEdit() {
		$id = $_REQUEST['id'] ? intval($_REQUEST['id']) : '';
		$m_log_reply = M('LogReply');
		$reply_info = $m_log_reply->where('id = %d',$id)->find();
		if (!$reply_info) {
			alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
		}
		if (!session('?admin') && $reply_info['type'] == 1) {
			alert('error','您没有此权利！',$_SERVER['HTTP_REFERER']);
		}
		$m_log_status = M('LogStatus');
		$status_name = $m_log_status->where('id = %d',$reply_info['status_id'])->getField('name');
		if ($this->isPost()) {
			$type = intval($_POST['type']);
			if(!trim($_POST['content'])){
				if ($type == 2) {
					$this->ajaxReturn('','请填写内容！',0);
				} else {
					alert('error','请填写内容！',$_SERVER['HTTP_REFERER']);
				}
			}
			if (!session('?admin') && $_POST['type'] == 1) {
				if ($type == 2) {
					$this->ajaxReturn('','参数错误！',0);
				} else {
					alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
				}
			}
			if($m_log_reply->create()){
				$m_log_reply->update_time = time();
				if ($m_log_reply->where('id = %d',$id)->save()) {
					if ($type == 2) {
						$reply_info_new = $m_log_reply->where('id = %d',$id)->find();
						$reply_info_new['status_name'] = $m_log_status->where('id = %d',$reply_info_new['status_id'])->getField('name');
						$this->ajaxReturn($reply_info_new,'快捷回复修改成功！',1);
					} else {
						alert('success', '快捷回复修改成功！', $_SERVER['HTTP_REFERER']);
					}
				} else {
					if ($type == 2) {
						$this->ajaxReturn('','快捷回复修改失败！',0);
					} else {
						alert('error', '快捷回复修改失败！', $_SERVER['HTTP_REFERER']);
					}
				}
			}else{
				if ($type == 2) {
					$this->ajaxReturn('','快捷回复修改失败！',0);
				} else {
					alert('error', '快捷回复修改失败！', $_SERVER['HTTP_REFERER']);
				}
			}
		} else {
			$reply_info['status_name'] = $status_name;
			$this->reply_info = $reply_info;
			$this->display();
		}
	}

	/**
	 * 沟通日志快捷回复(删除)
	 **/
	public function logReplyDel() {
		$m_log_reply = M('LogReply');
		if ($_POST['id']) {
			$id_array = $_POST['id'];
			if(!is_array($id_array)){
				$id_array = array();
				$id_array[0] = $_POST['id'];
			}
			$del_arr = array();
			//判断是否被使用
			foreach ($id_array as $k=>$v) {
				if (!$m_log_reply->where(array('id'=>$v,'role_id'=>array('neq',session('role_id'))))->find()) {
					$del_arr[] = $v;
				}
			}
			if ($del_arr) {
				if ($m_log_reply->where('id in (%s)', implode(',', $del_arr))->delete()){
					if (count($id_array) == count($del_arr)) {
						$this->ajaxReturn('','删除成功！',1);
					} else {
						$this->ajaxReturn('','部分删除失败！',1);
					}
				} else {
					$this->ajaxReturn('','删除失败！',0);
				}
			} else {
				$this->ajaxReturn('','删除失败！',0);
			}
			
		}
	}

	/**
	 * ajax获得快捷回复
	 **/
	public function getReplyByStatus() {
		if ($this->isAjax()) {
			$stauts_id = $_REQUEST['status_id'] ? intval($_REQUEST['status_id']) : '';
			$reply_list = array();
			$where = array();
			$where['type']  = 1;
			$where['role_id']  = session('role_id');
			$where['_logic'] = 'or';
			$map['_complex'] = $where;
			if ($stauts_id) {
				$map['status_id'] = $stauts_id;
			}
			$reply_list = M('LogReply')->where($map)->select();
			foreach ($reply_list as $k=>$v) {
				$reply_list[$k]['str_content'] = cutString($v['content'],'12');
			}
			$this->ajaxReturn($reply_list,'','0');
		}
	}

	/**
	 * dialog管理快捷沟通
	 **/
	public function replyList() {
		$m_log_reply = M('LogReply');
		$m_log_status = M('LogStatus');
		$where = array();
		$where['type']  = 1;
		$where['role_id']  = session('role_id');
		$where['_logic'] = 'or';
		$map['_complex'] = $where;
		$reply_list = M('LogReply')->where($map)->select();
		foreach ($reply_list as $k=>$v) {
			$reply_list[$k]['str_content'] = cutString($v['content'],'12');
			$reply_list[$k]['status_name'] = $m_log_status->where(array('id'=>$v['status_id']))->getField('name');
		}
		$this->status_list = $m_log_status->select();
		$this->reply_list = $reply_list;
		$this->display();
	}

	/**
	 * 商机状态组（列表）
	 * @param 
	 * @author JianXin dev team
	 * @return 
	 */
	public function businessType() {
		//判断权限

		$m_business_type = M('BusinessType');
		$type_list = $m_business_type->select();

		$this->type_list = $type_list;
		$this->alert = parseAlert();
		$this->display();
	}

	/**
	 * 商机状态组（添加）
	 * @param 
	 * @author JianXin dev team
	 * @return 
	 */
	public function businessTypeAdd() {
		if ($this->isPost()) {
			$m_business_type = M('BusinessType');
			if(!trim($_POST['name'])){
				alert('error','请填写名称！',$_SERVER['HTTP_REFERER']);
			}
			if ($m_business_type->where(array('name'=>trim($_POST['name'])))->find()) {
				alert('error','该名称已存在，请修改后重试！',$_SERVER['HTTP_REFERER']);
			}
			if($m_business_type->create()){
				$m_business_type->create_role_id = session('role_id');
				$m_business_type->create_time = time();
				$m_business_type->update_time = time();
				if ($type_id = $m_business_type->add()) {
					//默认追加项目成功、项目失败
					$data = array();
					$data[0]['name'] = '项目失败';
					$data[0]['order_id'] = '99';
					$data[0]['is_end'] = '2';
					$data[0]['description'] = '项目失败';
					$data[0]['type_id'] = $type_id;

					$data[1]['name'] = '项目成功';
					$data[1]['order_id'] = '100';
					$data[1]['is_end'] = '3';
					$data[1]['description'] = '项目成功';
					$data[1]['type_id'] = $type_id;
					$m_business_status = M('BusinessStatus');
					foreach ($data as $k=>$v) {
						$res = $m_business_status->add($v);
					}
					alert('success', '商机状态组添加成功！', $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', '商机状态组添加失败！', $_SERVER['HTTP_REFERER']);
				}
			}else{
				alert('error', '商机状态组添加失败！', $_SERVER['HTTP_REFERER']);
			}
		} else {
			$this->alert=parseAlert();
			$this->display();
		}
	}

	/**
	 * 商机状态组（编辑）
	 * @param 
	 * @author JianXin dev team
	 * @return 
	 */
	public function businessTypeEdit() {
		$id = $_REQUEST['id'] ? intval($_REQUEST['id']) : '';
		if (!$id) {
			alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
		}
		$m_business_type = M('BusinessType');
		$type_info = $m_business_type->where('id = %d',$id)->find();
		if ($this->isPost()) {
			
			if(!trim($_POST['name'])){
				alert('error','请填写名称！',$_SERVER['HTTP_REFERER']);
			}
			if ($m_business_type->where(array('name'=>trim($_POST['name']),'id'=>array('neq',$id)))->find()) {
				alert('error','该名称已存在，请修改后重试！',$_SERVER['HTTP_REFERER']);
			}
			if($m_business_type->create()){
				$m_business_type->update_time = time();
				if ($m_business_type->where('id = %d',$id)->save()) {
					alert('success', '商机状态组修改成功！', $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', '商机状态组修改失败！', $_SERVER['HTTP_REFERER']);
				}
			}else{
				alert('error', '商机状态组修改失败！', $_SERVER['HTTP_REFERER']);
			}
		} else {
			$this->type_info = $type_info;
			$this->alert=parseAlert();
			$this->display();
		}
	}

	/**
	 * 商机状态组（删除）
	 * @param 
	 * @author JianXin dev team
	 * @return 
	 */
	public function businessTypeDel() {
		$m_business_type = M('BusinessType');
		$m_business = M('Business');
		if ($_POST['id']) {
			$id_array = $_POST['id'];
			if(!is_array($id_array)){
				$id_array = array();
				$id_array[0] = $_POST['id'];
			}
			$del_arr = array();
			//判断是否被使用
			foreach ($id_array as $k=>$v) {
				if (!$m_business->where(array('status_type_id'=>$v))->find() && $v !== 1) {
					$del_arr[] = $v;
				}
			}
			if ($del_arr) {
				if ($m_business_type->where('id in (%s)', implode(',', $del_arr))->delete()){
					if (count($id_array) == count($del_arr)) {
						$this->ajaxReturn('','删除成功！',1);
					} else {
						$this->ajaxReturn('','部分组已被使用，删除失败！',1);
					}
				} else {
					$this->ajaxReturn('','删除失败！',0);
				}
			} else {
				$this->ajaxReturn('','所选组已被使用，不能删除！',0);
			}
		}
	}

	/**
	 * 财务相关类型（列表）
	 * @param 
	 * @author JianXin dev team
	 * @return 
	 */
	public function finance() {
		//判断权限
		$field = $_GET['field'] ? trim($_GET['field']) : 'payables';
		switch ($field) {
			case 'payables' : $field_name = '应付款';
				break;
			default : $field_name = '应付款';
				break;
		}
		$m_finance_type = M('FinanceType');
		$type_list = $m_finance_type->where(array('field'=>$field))->select();
		$this->field_name = $field_name;
		$this->type_list = $type_list;
		$this->alert = parseAlert();
		$this->display();
	}

	/**
	 * 财务类型（添加）
	 * @param 
	 * @author JianXin dev team
	 * @return 
	 */
	public function financeAdd() {
		if ($this->isPost()) {
			$m_finance_type = M('FinanceType');
			if (!trim($_POST['field'])) {
				alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
			}
			if(!trim($_POST['name'])){
				alert('error','请填写名称！',$_SERVER['HTTP_REFERER']);
			}
			if ($m_finance_type->where(array('name'=>trim($_POST['name'])))->find()) {
				alert('error','该名称已存在，请修改后重试！',$_SERVER['HTTP_REFERER']);
			}
			if($m_finance_type->create()){
				$m_finance_type->create_role_id = session('role_id');
				$m_finance_type->create_time = time();
				$m_finance_type->update_time = time();
				if ($m_finance_type->add()) {
					alert('success', '类型添加成功！', $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', '类型添加失败！', $_SERVER['HTTP_REFERER']);
				}
			}else{
				alert('error', '类型添加失败！', $_SERVER['HTTP_REFERER']);
			}
		} else {
			$this->alert=parseAlert();
			$this->display();
		}
	}

	/**
	 * 财务类型（编辑）
	 * @param 
	 * @author JianXin dev team
	 * @return 
	 */
	public function financeEdit() {
		$id = $_REQUEST['id'] ? intval($_REQUEST['id']) : '';
		if (!$id) {
			alert('error','参数错误！',$_SERVER['HTTP_REFERER']);
		}
		$m_finance_type = M('FinanceType');
		$type_info = $m_finance_type->where('id = %d',$id)->find();
		if ($this->isPost()) {
			
			if(!trim($_POST['name'])){
				alert('error','请填写名称！',$_SERVER['HTTP_REFERER']);
			}
			if ($m_finance_type->where(array('name'=>trim($_POST['name']),'id'=>array('neq',$id)))->find()) {
				alert('error','该名称已存在，请修改后重试！',$_SERVER['HTTP_REFERER']);
			}
			if($m_finance_type->create()){
				$m_finance_type->update_time = time();
				if ($m_finance_type->where('id = %d',$id)->save()) {
					alert('success', '类型修改成功！', $_SERVER['HTTP_REFERER']);
				} else {
					alert('error', '类型修改失败！', $_SERVER['HTTP_REFERER']);
				}
			}else{
				alert('error', '类型修改失败！', $_SERVER['HTTP_REFERER']);
			}
		} else {
			$this->type_info = $type_info;
			$this->alert = parseAlert();
			$this->display();
		}
	}

	/**
	 * 财务类型（删除）
	 * @param 
	 * @author JianXin dev team
	 * @return 
	 */
	public function financeDel() {
		$m_finance_type = M('FinanceType');
		$m_payables = M('Payables');
		if ($_POST['id']) {
			$id_array = $_POST['id'];
			if(!is_array($id_array)){
				$id_array = array();
				$id_array[0] = $_POST['id'];
			}
			$del_arr = array();
			//判断是否被使用
			foreach ($id_array as $k=>$v) {
				if (!$m_payables->where(array('type_id'=>$v))->find()) {
					$del_arr[] = $v;
				}
			}
			if ($del_arr) {
				if ($m_finance_type->where('id in (%s)', implode(',', $del_arr))->delete()){
					if (count($id_array) == count($del_arr)) {
						$this->ajaxReturn('','删除成功！',1);
					} else {
						$this->ajaxReturn('','部分类型已被使用，删除失败！',1);
					}
				} else {
					$this->ajaxReturn('','删除失败！',0);
				}
			} else {
				$this->ajaxReturn('','所选类型已被使用，不能删除！',0);
			}
		}
	}


	/**
	 * 查看操作记录
	 * @author JianXin dev team
	 */
	public function action_record()
	{
		//联系人操作记录
		$action_record = actionRecord(1, 'setting'); 
		$this->assign('group_list', $action_record);
		$this->display();
	}

    /**
     * 线索转客户字段转移
     * @author JianXin dev team
     */
    public function leads_exchange()
    {
        $m_fields = M('Fields');
        if (IS_POST) {
            $leads_field_id = (int) $_POST['leads_field_id'];
            $customer_field_id = (int) $_POST['customer_field_id'];
            if (!$leads_field_id) {
                $this->ajaxReturn(array('status' => '0', 'msg' => '参数错误，刷新后重试。'));
            }
            // 是否已被设置
            $old_data = M('FLeadsCustomer')->where(array('customer_field_id' => $customer_field_id))->find();
            if ($old_data) {
                if ($old_data['customer_field_id'] == $customer_field_id) {
                    $this->ajaxReturn(array('status' => '0', 'msg' => '数据无变化。'));
                } else {
                    $this->ajaxReturn(array('status' => '0', 'msg' => '该客户字段已关联线索字段，请重新先择。'));
                }
            }
            $relation = M('FLeadsCustomer')->where(array('leads_field_id' => $leads_field_id))->find();
            if ($relation) {
                $res = M('FLeadsCustomer')->where(array('leads_field_id' => $leads_field_id))->setField('customer_field_id', $customer_field_id);
            } else {
                $res = M('FLeadsCustomer')->add(array('leads_field_id' => $leads_field_id, 'customer_field_id' => $customer_field_id));
            }
            if ($res) {
                $this->ajaxReturn(array('status' => 1, 'msg' => '保存成功'));
            } else {
                $this->ajaxReturn(array('status' => 0, 'msg' => '保存失败'));
            }
        } else {
            $leads_field_id = (int) $_GET['field_id'];
            $this->leads_field_id = $leads_field_id;
            $customer_field_id = (int) M('FLeadsCustomer')->where(array('leads_field_id' => $leads_field_id))->getField('customer_field_id');
            $this->customer_field_id = $customer_field_id;
            $leads_field = $m_fields->find($leads_field_id);
            if (!$leads_field_id || in_array($leads_field['field'], D('Leads')->not_support)) {
                echo '<div class="text text-danger">参数错误，请刷新后重试</div>'; die;
            }

            $where = array('model' => 'customer', 'form_type' => $leads_field['form_type']);
            $where['field'] = array('NOT IN', D('Customer')->not_exchange);
            // 已经设置了的客户字段 并排除当前关联的字段
            $customer_field_id_list = (array) M('FLeadsCustomer')->where(array('leads_field_id' => array('NEQ', $leads_field_id)))->getField('customer_field_id', true);
            $customer_field_id_list[] = 0;

            $where['field_id'] = array('NOT IN', $customer_field_id_list);
            $this->customer_fields_list = (array) $m_fields->where($where)->order('order_id ASC')->field('name, field_id')->select();

            $this->field_id = $field_id;
            $this->display();
        }
    }
}
