<?php
class CallAction extends Action{
	/**
	*  用于判断权限
	*  @permission 无限制
	*  @allow 登录用户可访问
	*  @other 其他根据系统设置
	**/
	public function _initialize(){
		$action = array(
			'permission'=>array(),
			'allow'=>array('setting')
		);
		B('Authenticate', $action);
	}

	/**
	 * 呼叫中心(设置开关)
	 * @param 
	 * @author JianXin dev team
	 * @return 
	 */
	public function setting(){
		$this->display();
	}

}